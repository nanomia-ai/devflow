---
title: Iteration 03 change note
status: frozen
purpose: Explain the final inversion review and why the final plan keeps nine skills while removing premature machinery.
read_when: Read when comparing iteration 02 with the final plan.
canonical_for: Design-history explanation only.
tags: [devflow-vnext, iteration-03, inversion]
---

# 03 — 전체 체계 역발상 검증 후 최종안

## 검증 방식

`02-reconciled`의 모든 파일을 동결한 뒤 같은 페이블 세션에 방어가 아니라 대체 체계를 만들도록 했다.
No lifecycle, no Land, Sketch/Resume 통합, team context colocation, no frontmatter, no hook, one generic skill,
`.devflow` 정본 등 반대 가정을 각각 실제 시나리오와 고정 의도에 대입했다. 별도 아키텍처 에이전트도
02를 읽고 내부 모순과 과잉 장치를 독립 검토했다.

## 페이블 대안

페이블은 lifecycle, Land, Sketch, Resume, team handoff tree, frontmatter, hook을 제거한 7-skill 체계를
제안했다. 이 대안은 선언 상태와 closing ceremony를 줄이고 하나의 transient shape를 사용하는 점에서
02보다 단순했다.

## 최종 채택·거부

채택:

- 선언형 lifecycle 제거
- 증거 전 추가한 Land skill 제거
- marker에서 verify channel 제거
- Quick lane owner를 Direct → Work로 명시
- Git/state의 관할 분리
- 장기 가치가 있는 cross-domain use-case만 조건부 `docs/specs/`로 승격
- 임의의 Skill Rails 숫자 제한 제거
- exact read set이 아닌 owner/무관 문서/비용/next action으로 fixture 평가
- target을 하나씩 build·fresh-use하는 phase 순서

거부:

- Sketch와 Resume 제거: 사용자가 명시한 독립 탐구와 중단 복구 진입을 잃는다.
- 팀원별 namespace 제거: 개인 자료만이 아니라 팀원별 폴더라는 명시 요구가 있다.
- header 제거: 사용자가 최소 설명과 조건부 읽기 header를 명시했다.
- hook 지원 완전 제거: correctness 의존성은 없애되 공식 설치 지원은 요청 범위다.
- Skill Rails release-only source: 현재 skill 계약의 단계별 build·bounded inspection을 유지한다.

## 02에서 교정한 모순

- 공개 skill은 10개가 아니라 9개이며 Land는 반복 누락 관찰 전 추가하지 않는다.
- Resume은 Domain orientation을 하지 않고 status/resume만 맡는다.
- Product의 cross-domain 구도와 Domain README의 고유 경계를 분리했다.
- Verify의 failure owner와 target document를 분리했다.
- marker는 정적 설정만 가지며 준비 상태는 파일에서 파생한다.
- `state.md`가 intent, Git이 bytes/revision을 소유한다.
- member context 이동은 매 turn이 아니라 실제 checkpoint에서 수행한다.
- 영구 personal `notes.md`를 제거했다.
- adoption scratch는 모든 source가 landed/resolved/unresolved-owner일 때만 삭제한다.

## 최종 구조 요약

```text
bootstrap: Sketch | Product | Adopt
foundation: Product → Architecture → [Design]
quick:      Direct → Work
tracked:    Direct → Work → Verify → owner landing → Work closure
resume:     Resume → next owner one
```

정본은 `docs/`, 진행 상태는 `.devflow/`, 공유 작업 사실은 work state, 개인 맥락은 team member work file이
소유한다. Skill Rails는 저작·배포 계층이며 build 증거와 fresh-use 증거를 분리한다.

## 남은 것은 구현 증거

이 반복 이후 더 많은 기획 규칙을 추가하지 않는다. 잔여 unknown은 keyed fixture와 한 target씩의
fresh-use 관찰로만 줄인다. 관찰이 현재 결정을 뒤집을 때 새 iteration을 만든다.
