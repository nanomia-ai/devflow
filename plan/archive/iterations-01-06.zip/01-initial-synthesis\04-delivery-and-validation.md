---
title: Incremental delivery and validation plan
status: draft-for-owner-review
purpose: Sequence implementation so each step exposes the cheapest useful failure before complexity grows.
read_when: Read before implementing, approving a phase, adding automation, or claiming a phase complete.
canonical_for: Proposed implementation order, phase gates, rollback points, and evidence classes.
tags: [devflow-vnext, delivery, validation, skill-rails, pilots]
---

# 점진 구현·검증 계획

## 1. 실행 원칙

각 phase는 하나의 중요한 주장만 검증한다. 파일 수, 테스트 수, build 성공을 제품 효과와 혼동하지
않는다. 다음 phase는 현재 phase의 관찰이 실제 결정을 바꿀 때만 연다.

```text
지원됨   → 정한 최소 구조를 유지하고 다음 한 단위로 이동
반증됨   → 구현/구조/전달/목적 중 실제 owner로 복귀
혼합됨   → 성립 조건을 분리하고 나머지는 보류
미결정   → 결정을 확정하지 않고 필요한 관찰과 재개 조건만 기록
```

## 2. 완료를 주장하는 세 증거

| 증거 | 답하는 질문 | 답하지 못하는 질문 |
|---|---|---|
| 전달 증거 | source에서 standalone artifact가 결정적으로 빌드되고 current한가 | AI가 이해했는가 |
| 행동 증거 | fresh AI가 의도한 문서를 고르고 올바른 다음 행동을 했는가 | 실제 사용자 비용이 장기적으로 줄었는가 |
| 효과 증거 | 실제 프로젝트/팀에서 재개·지식 승격·실패 환류가 문제를 줄였는가 | 다른 모든 환경에서도 같은가 |

모든 결과는 `proven`, `failed`, `unproven`을 분리한다. 실행하지 못한 검사는 pass가 아니다.

## 3. Phase 0 — 계획 승인과 레거시 격리 준비

### 걸린 결정

새 체계가 레거시의 후속 호환 버전인지, 독립적인 vNext인지 확정한다.

### 권고

독립 vNext로 진행한다. 사용자 승인 후 현재 루트 자산을 `legacy/v0.25.1/`로 원형 이동하고 새
runtime이 legacy를 import, fallback 또는 compatibility layer로 사용하지 못하게 한다.

### 실행 전 확인

- 이동할 정확한 tracked/untracked 경로
- plugin cache나 사용자 설치물과 source repository의 구분
- Git history와 recovery path
- LICENSE, repository metadata, plan의 새 root 유지 여부
- 이동 전 tree hash와 이동 후 파일 목록 대조

이번 기획 단계에서는 이동하지 않는다. 승인 뒤 별도 변경으로 수행한다.

### 완료 신호

- legacy가 읽기 가능한 참고 영역에 보존됨
- 새 authoring/build/test 경로가 legacy를 소비하지 않음
- root에는 새 source package, plan, 배포에 실제 필요한 최소 파일만 남음

## 4. Phase 1 — 문서 시스템 수직 pilot

### 공격할 주장

작은 manifest, index, 관할별 정본, domain tree, active work/handoff만으로 fresh AI가 전체를 읽지 않고
다음 행동을 결정할 수 있다.

### 가장 작은 fixture

```text
.devflow/
  manifest.json
  index.md
  product.md
  architecture.md
  domains/customer/index.md
  domains/customer/validation.md
  decisions/0001-customer-identity.md
  work/W001/spec.md
  work/W001/state.md
  work/W001/verification.md
  team/alice/handoffs/W001.md
```

처음에는 사람이 읽을 수 있는 수작업 fixture로 의미와 routing을 검증한다. 이 단계에서 범용 schema,
state engine, journal, renderer를 만들지 않는다.

### 첫 Skill Rails target

읽기 전용 `resume` prose target 하나를 먼저 만든다. 이유는 문서를 생성하는 skill보다 작은 위험으로
manifest gate, index routing, work/member handoff의 충분성을 검증할 수 있기 때문이다.

Skill Rails 절차:

1. user burden, 보존할 의미 판단, observable result, 범위 밖을 target source에 명시한다.
2. exact target owner와 consumer를 inspect한다.
3. standalone `resume` target만 build한다.
4. receipt와 generated diff를 검토한다.
5. 같은 source를 두 번 build해 tree hash를 비교한다.
6. integrity와 source currentness를 별도로 check한다.
7. standalone copy의 fresh AI에게 실제 resume 질문을 주고 읽은 파일과 다음 행동을 관찰한다.

### 통과 관찰

- AI가 `index → W001 state → alice handoff → spec`처럼 필요한 파일만 연다.
- Product/Architecture/다른 domain을 이유 없이 전부 읽지 않는다.
- base revision 충돌 또는 blocker를 발견하면 구현을 시작하지 않는다.
- 다음 owner와 한 행동을 반환하며 다른 skill 판단을 대신하지 않는다.

### 반증 시 복귀

- 문서가 부족함 → document ownership/header/index 질문으로 복귀
- target entry가 부족함 → Resume source owner로 복귀
- AI가 과잉 읽음 → read condition과 index projection을 수정
- 효과 차이가 없음 → 추가 renderer를 만들지 않고 더 단순한 baseline과 비교

## 5. Phase 2 — Bootstrap 스킬의 최소 chaining

### 대상

`sketch`, `product`, `architecture`, `design`, `adopt`의 최소 entry를 한 target씩 만든다. 각 target은
상세 기능보다 다음 계약만 완성한다.

```text
purpose
trigger and project gate
required current inputs
one owned output
completion evidence
next optional routes
explicit non-responsibilities
```

### pilot 순서

1. 명확한 brief → `product` → `architecture`
2. 모호한 idea → `sketch(project)` → `product`
3. backend-only brief → design 없이 active
4. 작은 brownfield 한 domain → `adopt` disposition → product/architecture

각 pilot에서 다음 target을 만들기 전에 standalone fresh-use를 한 번 관찰한다. 모든 target source를
한 번에 완성하지 않는다. 최소 purpose/chaining descriptor는 미리 설계할 수 있지만 build·고도화는
한 target씩 한다.

## 6. Phase 3 — Index와 header의 최소 기계화

수작업 pilot에서 다음 중 하나가 실제로 관찰된 경우에만 연다.

- 새 문서가 index에 누락된다.
- 사라진 파일을 index가 가리킨다.
- header의 `id`, `kind`, `read_when`이 반복적으로 틀린다.
- AI가 같은 routing 정보를 여러 문서에서 다르게 읽는다.

그때 추가할 수 있는 최소 기계:

- header 필수 필드와 unique id 검사
- index가 가리키는 파일 존재 검사
- manifest lifecycle 값과 root pointer 검사
- header에서 deterministic한 routing view 생성

semantic owner, 좋은 summary, 적절한 read condition, domain 경계는 script가 판정하지 않는다. 이
기계화가 한 선언된 index output을 안정적으로 만드는 경우에만 Skill Rails `record-only`/renderer
후보로 검토한다.

## 7. Phase 4 — Direct → Work → Verify 루프

### 첫 범위

한 표준 work item과 한 번의 의도된 실패만 구현한다.

1. Direct가 목표·비범위·acceptance가 있는 `spec.md`를 만든다.
2. Work가 구현하고 `state.md`에 다음 행동과 verify 입력을 남긴다.
3. Verify가 실제 명령/관찰로 한 criterion을 실패시킨다.
4. failure owner가 Work인지 Direct인지 판정한다.
5. 올바른 owner에서 수정한 뒤 같은 criterion을 재검증한다.

### 별도 pilot

- code defect → Work로 복귀
- impossible/contradictory spec → Direct로 복귀
- verification channel 부재 → `unproven`으로 종료
- quick lane → durable work folder 없이 같은 세션에서 완료

### 통과 관찰

- Work가 spec 의미를 조용히 바꾸지 않는다.
- Verify가 파일을 고치지 않고 증거와 owner를 반환한다.
- retry가 직전 실패와 다른 판별 행동을 가진다.
- 완료 후 durable domain 사실만 정본으로 승격되고 작업 로그는 남지 않는다.

## 8. Phase 5 — 팀 handoff와 실제 재개

하나의 work item을 Agent A가 중단하고 Agent B가 transcript 없이 이어서 완료한다.

관찰 항목:

- spec, base revision, write scope, last verification, next action을 정확히 찾는가
- 개인 handoff와 프로젝트 정본을 혼동하지 않는가
- 다른 branch의 변경을 자기 작업으로 오인하지 않는가
- 새 domain 사실을 개인 문서가 아니라 canonical owner로 승격하는가

그 다음에만 두 개의 독립 work ID를 병렬 실행한다. 같은 canonical owner를 수정하는 병렬 승격은
owner가 순차 통합한다. Devflow 자체 lock/task database는 만들지 않는다.

## 9. Phase 6 — Adopt 확장

작은 brownfield fixture에서 대표 domain 하나를 끝낸 뒤에만 source group과 domain 수를 늘린다.

완료를 “모든 파일 읽음”으로 정의하지 않는다. 다음을 본다.

- maintained source의 disposition과 unknown이 거짓 완결성 없이 드러남
- Product/Architecture/Domain owner가 겹치지 않음
- 기존 구현의 현재 동작과 기획 의도가 구분됨
- 관리 전 source가 새 정본의 영구 runtime 의존성이 되지 않음
- 새 AI가 adopted vertical slice에서 실제 변경을 안전하게 수행함

중개노트에는 원본을 수정하지 않는 복사본/dry-run으로만 적용하고, 실제 adopt는 별도 사용자 승인 후
진행한다.

## 10. Phase 7 — npm 배포와 host adapter

### 목표 구조

```text
plugin.json                         # portable identity + OpenAI extension
.claude-plugin/plugin.json         # Claude 공식 adapter
skills/                             # 공통 standalone targets
hooks/hooks.json                    # 필요한 host가 소비하는 얇은 hook 선언
scripts/session-start.*             # cheap eligibility + short pointer only
```

`.codex-plugin/plugin.json`은 실제 대상 버전 호환 실험이 필요할 때만 fallback으로 둔다.

### 최소 설치 실험

1. local package/tarball을 npm source와 같은 구조로 만든다.
2. Claude marketplace에서 새 사용자/project scope 설치 후 clean session을 시작한다.
3. Codex marketplace에서 설치 후 clean session을 시작한다.
4. skill 목록, 명시 호출, 암시 호출, SessionStart pointer를 각각 관찰한다.
5. hook이 없는 package와 있는 package를 같은 fixture/질문으로 비교한다.
6. uninstall/update 후 stale skill/hook이 남지 않는지 본다.

Hook의 결과가 무엇이든 core skill은 명시 호출로 작동해야 한다. Hook이 효과를 보이지 않으면 제거해도
correctness가 유지되어야 한다.

## 11. 첫 fresh-agent 관찰 다섯 개

초기 결정을 가르기에는 다음 다섯 개면 충분하다.

1. unmanaged repo에서 `work`가 쓰기 전에 거부하는가
2. backend-only project가 design artifact를 만들지 않는가
3. domain 질문이 index → domain index → 관련 child만 읽는가
4. 중단된 작업을 transcript 없이 member handoff와 spec으로 재개하는가
5. verify의 spec 결함이 Work 반복이 아니라 Direct로 돌아가는가

이 결과로 현재 결정을 바꾸지 않는 시나리오를 더 추가하지 않는다.

## 12. 과잉설계 금지선

- 공개 `principles` 스킬
- 모든 요청에 sketch/spec/ADR/handoff 생성
- manifest 기반 전역 단계 상태 기계
- Resume가 모든 스킬을 대행하는 구조
- 모든 판단·행동을 event trace로 기록
- stage마다 runtime/CLI/vendor 복제
- 전역 capability/glossary catalog 선제 설계
- 완료된 sketch/research/execution log의 영구 working-tree 보존
- SessionStart hook이 없으면 작동하지 않는 설계
- 한 AI의 한 번의 혼동을 새 전역 필드·검사·예외로 일반화
- 미래 가능성만으로 architecture/design/domain child를 미리 생성

## 13. 첫 구현 승인 조건

다음이 소유자에게 승인되기 전에는 레거시 이동이나 runtime 구현을 시작하지 않는다.

- 9개 스킬과 공개 `principles` 제거
- domain 중심 문서 tree와 별도 domain skill 미도입
- manifest lifecycle/gate
- active sketch/work/member 기록의 수명과 승격 규칙
- Phase 1 fixture와 read-only Resume를 첫 수직 pilot으로 삼는 순서
- 공통 npm package + 얇은 Claude/OpenAI adapter 방향

