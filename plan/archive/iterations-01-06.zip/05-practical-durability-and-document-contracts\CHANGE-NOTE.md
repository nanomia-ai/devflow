---
title: Iteration 05 change note
status: frozen
purpose: Explain why the final practical-durability plan differs from iteration 04.
read_when: Read when comparing the final plan with the pre-review internal-canon baseline.
canonical_for: The 04 to 05 planning transition only.
tags: [devflow-vnext, planning, iteration, review]
---

# 04에서 05로 바뀐 이유

## 고정한 것

- 아홉 공개 skill, `.devflow/` 내부 정본, Domain 지식 tree, current-only project 문서
- Sketch·Adopt·Work의 서로 다른 수명과 완료 뒤 삭제
- phase enum 없는 국소 state, 읽기 전용 Resume, 별도 Land/Principles/Domain skill 부재
- `summary/read_when` 최소 header와 수동 index 우선

## 최종 보완

1. 구버전 Devflow 운영 프로젝트가 없음을 확인해 migration·compatibility를 명시적으로 배제했다.
2. Owner는 canonical home만 뜻하고 진행 필드는 `next_route`로 분리했다.
3. 병렬 작업은 코드 경계 중첩을 금지하지 않고 artifact state의 동시 writer만 금지한다. Git/PR이 통합한다.
4. 어느 stage든 관리권이 바뀌기 전에 현재 행동을 끝내지 못하면 state snapshot을 남긴다는 한 원칙을 적용했다.
5. Spec·state·verification·team·Adopt source/conflict의 정보 소유권을 분리해 중복 필드를 제거했다.
6. Resume의 범위를 현재 checkout으로 한정하고 dirty unowned work, 불완전 sibling, Design applicability를 다룬다.
7. Adopt가 열려 있는 동안 일반 Direct/Work를 막는 안전한 v1 gate를 선택했다.
8. 문서별 질문·본문 정보 계약과 PR/commit review evidence를 `08-document-contracts.md`에 구체화했다.
9. Skill Rails는 한 source graph에서 gate·route·bootstrap·target을 만들고, project document law는
   `.devflow/index.md`에 심어 plugin 없는 actor도 같은 계약을 읽게 했다.

## 독립 검증과 조정

같은 Claude Fable high 세션은 현재안 전체를 반대 전제에서 다시 설계한 뒤 비교했고, 기존 Architecture
agent는 병렬 Git 작업·중단 복구·문서 소유권을 별도로 감사했다. 두 검토가 함께 찾은 state 중복,
index hot spot, 과도한 write-scope 배타성, Direct/Verify partial publication, Resume checkout 경계,
review evidence 공백을 반영했다.

Fable의 one-file transient artifact 대안은 더 단순할 가능성이 있으나, 현재 `spec/state/verification`은
각기 다른 독자 질문을 가지므로 pilot 전 강제 통합하지 않았다. 실제 read·merge·중단 비용이 분리 이점보다
크면 뒤집는다. Artifact folder 통합, optional unit, Adopt coverage 비용, Sketch/Resume 존속도 같은 방식으로
관찰 후 결정한다.

## 이번에도 추가하지 않은 것

- 전역 lifecycle, lock, room, claim, 중앙 ID/agent registry
- 레거시 adapter·migration·fallback
- 모든 상황을 열거한 interruption protocol
- 별도 Land·Index·Domain·Principles skill
- 의미를 대신 판단하는 schema/checker

