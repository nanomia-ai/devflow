---
title: Skill graph and document architecture
status: reconciled-working-copy
purpose: Define the minimal skill set, routing, document ownership, gates, and knowledge lifecycle.
read_when: Read when deciding which skill owns a judgment or where a durable fact belongs.
canonical_for: Proposed Devflow vNext structure.
tags: [devflow-vnext, skills, documents, domains, routing]
---

# 스킬 관계와 문서 시스템

## 1. 시스템 경계

Devflow는 전역 workflow engine이 아니다. 세 가지 얇은 층만 제공한다.

1. `docs/`: 사람과 AI가 함께 유지하는 프로젝트 정본.
2. `.devflow/`: 설치 표식과 진행 중인 탐구·작업·검증·팀 맥락.
3. skills: 현재 질문을 소유할 문서와 다음 행동으로 연결하는 짧은 진입문.

Git이 이력과 동시성을 소유하고, 실제 orchestrator가 agent 배치를 소유한다. Devflow는 lock, claim,
room, 전역 queue, retry counter, agent session database를 만들지 않는다.

## 2. 공개 스킬 열 개

각 스킬은 `목적 / 입력 / 소유 출력 / 완료 증거 / 다음 경로 / 하지 않는 일`만 가진다.

| 스킬 | 하나의 책임 | 소유 출력 | 다음 경로 |
|---|---|---|---|
| `sketch` | 아직 spec이나 Product로 고정할 수 없는 문제·아이디어·리서치를 결정 가능한 지점까지 좁힌다 | active sketch와 finding의 `destination`, `landed|unresolved` | project → product, change → direct, 정본 변경 → 해당 owner |
| `product` | 목적, 사용자, 가치, 경계, 제품 언어와 domain 후보를 결정한다 | `<project-knowledge>/PRODUCT.md`, domain 목적·경계 | architecture, 필요 시 design |
| `architecture` | 기술 경계, 배치, 의존 방향, runtime/data/검증 방식을 결정한다 | `<project-knowledge>/ARCHITECTURE.md`, 조건부 상세, ADR | design 또는 direct |
| `design` | UI가 있는 프로젝트의 시각·상호작용 원칙과 조건부 상세를 결정한다 | `docs/DESIGN.md`와 domain design | direct |
| `adopt` | 유지되는 기존 코드·문서를 분류하고 처음부터 Devflow를 썼다면 존재했을 정본을 점진 재구성한다 | source coverage/conflict, reconstructed canon | product → architecture → optional design |
| `direct` | 현재 요청을 실행 가능한 계약과 작업 단위로 만든다 | `spec.md`, 초기 `state.md` | sketch 또는 work |
| `work` | 승인된 한 작업 단위를 구현하고 재개 가능한 현재 상태를 남긴다 | 코드·테스트·`state.md` | verify 또는 direct |
| `verify` | acceptance를 실제 실행으로 판정하고 실패의 owner를 정한다 | `verification.md`, return packet | work/direct/정본 owner/land |
| `land` | 검증된 사실만 정본 owner에 승격하고 작업·팀 임시 자료를 닫는다 | 정본 수정, ADR, 임시 폴더 삭제 | resume |
| `resume` | 현재 상태·다음 owner·domain 읽기 방향을 최소 read set으로 알려 준다 | 읽기 전용 status와 하나의 next route | 해당 스킬 또는 없음 |

`principles`는 공개 진입문으로 만들지 않는다. 공통 불변식이 실제로 세 target 이상에서 중복될 때만
Skill Rails의 조건부 module 후보가 되며, 모든 target이 매번 읽는 module은 금지한다.

`domain`도 별도 스킬로 만들지 않는다. Domain은 지식 소유 축이다. Product는 업무 의미를,
Architecture는 기술 경계를, Design은 UI 원칙을, Direct는 현재 변경 계약을 판단한다. 같은 domain
수정 owner를 반복해서 잘못 선택하는 관찰이 생길 때만 별도 스킬을 재검토한다.

## 3. 전체 chaining

```text
모호한 신규 아이디어 → sketch(project) → product → architecture → [design] → active
명확한 신규 brief   → product → architecture → [design] → active
기존 프로젝트       → adopt → product → architecture → [design] → active

active 요청 → direct
  불확실성이 spec을 막음       → sketch(change) → direct
  제품/domain 경계가 바뀜      → product/architecture/[design] → direct
  실행 계약이 준비됨           → work → verify
  verify: implementation 결함 → work
  verify: spec 결함            → direct
  verify: 정본 결함            → 해당 owner → direct
  verify: 관찰 불가             → unproven으로 닫고 재개 조건 기록
  verify: pass                 → land → resume
```

화살표는 권고 경로이며 기계적 stage transition이 아니다. 각 skill은 자신의 출력과 다음 선택지만
기재하고 다른 skill의 내부 절차를 복제하지 않는다.

## 4. 관리 상태와 gate

`.devflow/devflow.md`가 관리 표식이다. 사람이 읽을 수 있는 짧은 파일이며 다음만 가진다.

```yaml
---
lifecycle: planning | adopting | active
knowledge_root: docs
working_language: ko
verify:
  - <project command or observation channel>
---
```

`lifecycle` 외에 current stage, queue, retry, session, current agent는 넣지 않는다.

| 상태 | 허용되는 진입 |
|---|---|
| 표식 없음 | `sketch`, `product`, `adopt`만 쓸 수 있음 |
| `planning` | bootstrap owner와 `resume`; Direct는 Product·Architecture가 없으면 거절 |
| `adopting` | adopt와 정본 owner, `resume`; reconstructed 사실은 가설로 취급 |
| `active` | 모든 skill. `work`/`verify`/`land`는 유효한 work item이 있어야 함 |

호스트 설명에서 관리 경계를 먼저 밝히고 skill 본문이 다시 확인한다. SessionStart hook은 표식이 있을
때 짧은 포인터를 주는 보조 장치일 뿐이며 hook이 없어도 명시 호출과 gate가 동일하게 작동해야 한다.

## 5. 목표 파일 트리

```text
docs/
  README.md                         # 질문 → owner 문서의 유일한 수동 routing view
  PRODUCT.md
  ARCHITECTURE.md
  architecture/                    # 실제 조건부 질문이 생길 때만
  DESIGN.md                        # UI가 있을 때만
  design/                          # 실제 조건부 질문이 생길 때만
  domains/
    <domain>/
      README.md                     # 목적·경계·언어·불변식·상세 문서 지도
      <concern>.md                  # read_when이 일치할 때만
  adr/
    NNNN-<slug>.md                  # 결정 이유·기각 대안·재검토 조건

.devflow/
  devflow.md                        # 관리 표식과 lifecycle
  sketches/
    <id>/                           # 진행 중 탐구만
  adoption/
    sources.md                      # maintained source coverage/disposition
    conflicts.md                    # 아직 owner 결정을 기다리는 충돌
  work/
    W001-<slug>/
      spec.md                       # Direct: 목표·비범위·acceptance·read-first·작업 단위
      state.md                      # Work: 유일한 공유 상태
      verification.md              # Verify: criterion별 proven/failed/unproven
  team/
    <git-user-name>/
      W001.md                       # 해당 사람만의 중간 맥락; 공유 사실은 금지
      notes.md                      # 선택적 개인 메모; 정본이 아니며 Resume은 읽지 않음
```

모든 디렉터리를 미리 만들지 않는다. Domain README는 domain이 실제로 발견될 때, 상세 문서는 현재
질문을 안전하게 건너뛸 수 있을 때만 만든다. 전역 glossary와 capability catalogue는 기본 구조에서
제외한다. 여러 domain의 동일 단어가 실제로 충돌할 때만 Product owner가 cross-domain language
문서를 만든다.

## 6. 문서 header와 indexing

정본 문서는 H1 아래의 내용을 읽기 전에 relevance를 판단할 수 있어야 한다.

```yaml
---
summary: 계약 정산의 상태·수수료 마감·외부 쓰기 경계를 설명한다.
read_when:
  - 계약 정산 상태나 fee closure를 변경할 때
status: reconstructed              # current일 때는 생략
---
```

- `summary`와 `read_when`만 필수다. summary는 H1을 되풀이하지 않는 한 줄이다.
- `status`는 `reconstructed` 또는 `superseded-by: <path>`처럼 현재가 아닐 때만 쓴다.
- `id`, `kind`, `tags`, 날짜, owner는 v1에서 금지한다. 경로·H1·Git에서 얻을 수 있거나 행동을
  바꾸지 않는 필드는 drift 지점일 뿐이다.
- `docs/README.md`는 질문 → 문서의 판단이 담긴 하나의 수동 index다.
- missing doc, dangling link, 반복되는 잘못된 `read_when` 중 하나가 관찰되기 전에는 generator를
  만들지 않는다. 그 뒤에도 header를 수집하는 작은 결정적 script만 허용한다.

## 7. 정본 소유권

| 현재 사실 | canonical owner |
|---|---|
| 목적·사용자·제품 가치·제품 언어·경계 | `<project-knowledge>/PRODUCT.md` |
| 프로젝트 기술 구조·배치·의존·검증 채널 | `<project-knowledge>/ARCHITECTURE.md`와 조건부 상세 |
| UI·상호작용 원칙 | `docs/DESIGN.md`와 조건부 상세 |
| domain 목적·개념·불변식·계약·함정 | `docs/domains/<domain>/` |
| 오래 남을 결정의 이유·기각 대안 | `docs/adr/` |
| 현재 변경의 목표·비범위·acceptance | work `spec.md` |
| 현재 revision·write scope·다음 행동·blocker | work `state.md` |
| criterion별 실제 판정과 증거 | work `verification.md` |
| 한 사람의 환경·중간 추론·시도 직전 맥락 | team member file |

ADR은 현재 규칙의 유일한 사본이 아니다. 현재 규칙은 Product/Architecture/Design/Domain에 반영하고
ADR은 그 이유와 재검토 조건을 보존한다.

## 8. 작업 상태와 팀 맥락의 분리

`state.md`만 공유 사실을 소유한다. 최소 내용은 base revision, 현재 unit, write scope,
uncommitted changes, last verification, next action, blocker, promotion pending, 현재 handoff pointer다.

`team/<member>/<work-id>.md`는 worktree/branch/machine, 방금 시도하려던 것, 환경 특이점, 확정하지 못한
추론과 질문만 가진다. 공유 사실이 발견되면 turn 종료 전 `state.md`로 옮긴다. Resume은 member file을
사실의 근거로 사용하지 않는다. Land는 work folder와 해당 member work files를 함께 삭제한다.
`notes.md`만 선택적으로 남을 수 있으나 정본에서 인용하지 않는다.

이 구조는 사용자가 요구한 팀원별 공간을 유지하면서 legacy의 identity protocol, room, claim,
join/leave transition을 되살리지 않는다.

## 9. Verify 실패와 loop 방지

```text
criterion:
observed:
expected:
evidence:
failure_owner: work | direct | product | architecture | design
what_must_change_before_retry:
unproven:
```

같은 criterion을 다시 시도하려면 직전과 다른 가설, 입력, 구현 또는 검증 방법을 명시해야 한다.
숫자 기반 retry limit은 두지 않지만, 달라진 것이 없는 재시도는 금지하고 Direct 또는 상위 owner로
돌려보낸다. 검증 채널이 없으면 pass가 아니라 `unproven`으로 닫고 재개 조건을 남긴다.

## 10. 지식 승격과 Land

승격 기준은 다음 네 가지를 모두 만족하는가다.

1. 다음 작업자의 판단을 실제로 바꾼다.
2. 현재 코드·실행 증거와 모순되지 않는다.
3. 하나의 정본 owner를 지정할 수 있다.
4. 진행 로그가 아니라 현재 유효한 사실·결정·함정이다.

Land는 verification과 spec에서 후보를 제안하고, owner별로 적용한 뒤 work와 관련 member file을
삭제한다. Product/Architecture/Design 의미를 새로 판단하지 않으며, 판단이 필요한 후보는 해당 owner에
돌려보낸다. Adopt가 만든 `reconstructed` 상태는 실제 변경에서 확인된 문서만 해제한다.
`.devflow/adoption/`은 active 전환 때 삭제하고 Git 이력으로 보존한다.

Land를 별도 skill로 유지할지는 첫 다섯 개 pilot 변화에서 승격 누락을 관찰해 재결정한다. 하나라도
누락되면 유지하고, Verify pass 경로만으로 항상 정확히 닫히면 그때 Verify에 합칠 수 있다.

## 11. Skill Rails 저작 경계

- source package 하나에 열 개의 prose target을 둔다.
- v1 target은 `imports: []`이며 판단을 실행하는 runtime Decision engine을 포함하지 않는다.
- entry source는 약 40줄을 목표로 하며 target별 목적·gate·입력·출력·완료 증거·다음 경로만 담는다.
- build 결과, diff, receipt는 delivery evidence다. fresh-agent 행동 관찰은 effect evidence이며 서로
  대체하지 않는다.
- 편집 시 build → generated diff 검토 → receipt 기록을 수행한다. double-build와 currentness/integrity
  check는 phase gate와 CI에서 수행한다.
- 세 target 이상에서 같은 문장이 복제되기 전에는 shared module을 만들지 않는다. 모든 target이 매번
  여는 unconditional module은 금지한다.
- target의 imports가 1개를 넘거나, 모든 target이 같은 module을 열거나, 현재 prose target 출력보다
  파일 수가 늘면 legacy regrowth 신호로 보고 다음 구현을 중단해 근거를 재검토한다.
- `record-only`, `prepare-record`, project runtime tool은 v1 범위 밖이다.
