---
title: Skill graph and internal document architecture
status: owner-corrected-current-plan
purpose: Define skill responsibilities, internal canonical storage, gates, state ownership, and knowledge landing.
read_when: Read when deciding which skill owns a judgment, where a fact belongs, or how an artifact changes state.
canonical_for: Proposed Devflow vNext structure.
tags: [devflow-vnext, skills, documents, domains, routing, ownership]
---

# 스킬 관계와 내부 문서 시스템

## 1. 바로잡은 시스템 경계

대상 프로젝트의 Devflow 지식과 Devflow가 만드는 모든 문서는 `.devflow/` 하나에 산다. `docs/`나
사용자가 유지하던 외부 문서는 Adopt의 입력일 수 있지만, 흡수 뒤 현재 지식의 두 번째 집이나 필수
의존성이 될 수 없다.

시스템은 세 층뿐이다.

1. `.devflow/`: 프로젝트 정본, 진행 중 탐구, 작업 계약·상태·검증, 팀 맥락을 수명별로 나눈 유일한 루트.
2. skills: 현재 질문을 판단할 의미 소유자와 정확한 내부 문서로 연결하는 짧은 진입문.
3. Git·코드·테스트·실행 환경: 문서의 이력과 현재 구현을 증명하는 현실. 문서 정본의 병렬 저장소는 아니다.

프로젝트 루트의 `AGENTS.md`, `CLAUDE.md`, plugin manifest, SessionStart hook처럼 host가 정해진 위치에서만
찾는 파일은 **연결부**다. `.devflow/index.md`를 가리키는 최소 포인터만 허용하고 프로젝트 지식·상태·
규칙을 독립적으로 소유하지 않는다. 연결부가 지워져도 발견성이 낮아질 뿐 `.devflow/`의 지식은 손상되지
않아야 한다.

## 2. “소유자(owner)”의 정확한 뜻

이 계획에서 owner는 사람, 현재 agent, 파일 잠금, Git 작성 권한이 아니다. **한 종류의 질문에 최종
의미 판단을 내리고 그 현재 진실을 한 canonical home에 유지하는 역할**이다.

| 구분 | 뜻 | 예 |
|---|---|---|
| 의미 소유자 | 어떤 질문을 판단하는가 | Product는 제품 경계, Architecture는 기술 경계 |
| canonical home | 판단된 현재 진실이 사는 한 경로 | `.devflow/project/product.md` |
| 현재 actor | 지금 그 일을 수행하는 사람·AI | 사용자, Codex, Claude, subagent |
| 작업 coordinator | 여러 actor의 순서·병렬성을 정하는 주체 | 단일 agent 또는 외부 orchestrator |

“owner가 옮겨간다”는 표현은 엄밀히 말하면 owner 자체의 이동이 아니다. 한 단계가 발견한 질문이나
결과를 **그 질문의 소유자에게 routing**하고, 소유자가 자기 정본에 흡수하는 것이다. 원래 단계는 자기
산출물만 계속 소유한다.

- Sketch는 탐구의 현재 질문과 미해결을 소유하지만 제품 결론은 Product로 보낸다.
- Direct는 요청·비범위·acceptance를 소유하지만 제품 경계를 바꾸지 않는다.
- Work는 구현과 실행 상태를 소유하지만 spec 의미를 바꾸지 않는다.
- Verify는 판정과 증거를 소유하지만 코드나 spec을 조용히 고치지 않는다.
- Resume은 아무 진실도 소유하지 않고 기존 owner를 찾아 읽기 전용으로 안내한다.
- Domain은 별도 actor나 skill이 아니라 현재 지식을 나누는 canonical home 축이다.

## 3. 공개 스킬 아홉 개

각 skill은 `목적 / 진입 gate / 읽을 것 / 소유 출력 / 완료 증거 / 다음 경로 / 하지 않는 일`만 가진다.

| 스킬 | 하나의 책임 | 직접 쓰는 내부 경로 | 다음 경로 |
|---|---|---|---|
| `sketch` | 아직 Product나 spec으로 고정할 수 없는 문제·리서치를 결정 가능한 지점까지 좁힌다 | `.devflow/sketches/<id>/` | project→product, change→direct, owner question→해당 owner |
| `product` | 목적, 사용자, 가치, 제품 경계·언어와 cross-domain 구도를 결정한다 | `.devflow/project/product.md`, domain의 업무 의미 | architecture, 필요 시 design |
| `architecture` | 기술 경계, 배치, 의존, runtime/data/검증 방식을 결정한다 | `.devflow/project/architecture.md`와 하위 tree, decision | design 또는 direct |
| `design` | UI가 있는 프로젝트의 시각·상호작용 원칙을 결정한다 | `.devflow/project/design.md`와 하위 tree | direct |
| `adopt` | 기존 코드·문서·운영 증거를 회계하고 자기완결 내부 정본으로 흡수한다 | 일시 `.devflow/adoption/`, 최종 `.devflow/project/` | product→architecture→optional design |
| `direct` | 현재 요청을 실행 가능한 변경 계약으로 만든다 | `.devflow/work/<id>/spec.md`, 초기 `state.md` | sketch, owner decision 또는 work |
| `work` | 준비된 한 작업 계약을 구현하고 재개 가능한 현재 상태를 남긴다 | 코드·테스트와 work `state.md` | verify 또는 direct |
| `verify` | acceptance를 실제 실행으로 판정하고 실패 route와 승격 후보를 정한다 | work `verification.md`, `state.md`의 route | work/direct/semantic owner/closure |
| `resume` | 디스크의 현재 상태에서 active item과 다음 owner를 최소 읽기로 찾는다 | 없음(읽기 전용) | 해당 skill 또는 없음 |

`principles`는 공개 stage로 만들지 않는다. 공통 규칙은 하나의 내부 저작 원본에서 필요한 target으로만
투영한다. `domain`, `land`, `lifecycle`도 처음부터 별도 skill로 만들지 않는다. 실제 반복 실패가
독립 책임을 입증할 때만 다시 검토한다.

## 4. 전체 상호작용

```mermaid
flowchart TD
    U[사용자 의도] --> Q{이미 결정 가능한가?}
    Q -- 아니오 --> S[Sketch]
    S -->|project 결론| P[Product]
    S -->|change 결론| D[Direct]
    Q -- 신규 프로젝트 brief --> P
    Q -- 기존 프로젝트 --> A0[Adopt]
    A0 --> P
    P --> A[Architecture]
    A --> UI{UI 판단이 필요한가?}
    UI -- 예 --> G[Design]
    UI -- 아니오 --> D
    G --> D
    D -->|탐구 필요| S
    D -->|상위 판단 필요| P
    D -->|ready| W[Work]
    W --> V[Verify]
    V -->|구현 결함| W
    V -->|spec 결함| D
    V -->|제품·기술·디자인 결함| O[해당 의미 소유자]
    O --> D
    V -->|proven| L[정본 흡수와 closure]
    R[Resume] -. 읽기·routing만 .-> S
    R -.-> D
    R -.-> W
    R -.-> V
    R -.-> O
```

화살표는 전역 상태 기계가 아니라 결과의 질문 유형에 따른 routing이다. 각 skill은 다음 skill의 내부
절차를 복제하지 않는다.

## 5. 유일한 프로젝트 파일 트리

```text
.devflow/
  index.md                          # 관리 표식 + 질문별 최상위 routing; 상세 지식 복제 금지
  project/                          # 장기 현재 지식
    product.md
    architecture.md
    architecture/                  # 독립 독자·변경 이유가 있을 때만
      <concern>.md
    design.md                       # UI가 있을 때만
    design/                         # 독립 독자·변경 이유가 있을 때만
      <concern>.md
    domains/
      <domain>/
        index.md                    # 목적·경계·언어·불변식·하위 지도
        <concern>.md                # read_when이 맞을 때만
    decisions/
      NNNN-<slug>.md                # 현재 결정 이유·기각 대안·재검토 조건
    specs/
      <topic>.md                    # 작업 뒤에도 계속 참조할 장기 계약만

  sketches/                         # 결정 전 임시 지식
    S001-<slug>/
      brief.md                      # 질문·scope·배경·목적지 후보
      state.md                      # 현재 phase·next action·미해결
      findings/                     # 한 문서가 비대해질 때만; transcript 금지
        01-<concern>.md

  work/                             # 실행 중 임시 지식
    W001-<slug>/
      spec.md                       # Direct가 소유하는 실행 계약
      state.md                      # work 전체의 유일한 현재 상태
      verification.md              # Verify의 최신 판정과 유계 실패 기억

  team/                             # 개인별 임시 맥락
    <member>/
      W001.md

  adoption/                         # Adopt가 진행 중일 때만 존재
    state.md
    sources.md                      # 입력 회계와 내부 landing target
    conflicts.md                    # source로 풀 수 없는 모순·결정만
```

모든 디렉터리를 미리 만들지 않는다. `index.md`와 현재 필요한 경로만 만든다. 완료된 sketch, work,
adoption 과정은 현재 트리에 묘비나 archive로 남기지 않고 Git이 이력을 보존한다.

## 6. gate: 폴더 존재와 준비 상태를 분리한다

Sketch만 시작해도 `.devflow/`가 생기므로 폴더 존재만으로 managed-ready를 판정하면 안 된다.

| 디스크 상태 | 허용 진입 |
|---|---|
| `.devflow/index.md` 없음 | `sketch`, `product`, `adopt`만 쓰기 가능 |
| index + active sketch만 있음 | `sketch`, `product`, `adopt`, 읽기 전용 `resume`; direct/work/verify 거절 |
| `project/product.md`만 있음 | product, architecture, optional design, sketch, adopt, resume |
| Product + Architecture가 현재이고 conflict가 blocking 아님 | 모든 skill; work/verify는 유효 work 계약도 필요 |
| active adoption conflict가 제품·기술 경계를 막음 | 해당 owner와 adopt만 진행; direct는 이유와 target을 보고하고 거절 |

host description과 skill 본문이 이 gate를 각각 짧게 확인한다. SessionStart hook은 index pointer를 줄 수
있지만 gate의 진실을 소유하지 않는다.

## 7. Header와 선택적 읽기

프로젝트 정본과 조건부 detail은 같은 최소 header를 쓴다.

```yaml
---
summary: 계약 정산의 상태·수수료 마감·외부 쓰기 경계를 설명한다.
read_when:
  - 계약 정산 상태나 fee closure를 변경할 때
---
```

- 현재 정본에는 `status: current`를 쓰지 않는다. 경로에 존재하는 문서가 현재다.
- 폐기·교체된 문서는 남겨 `superseded`로 표시하지 않고 현재 자리에서 고치거나 삭제한다. Git이 과거다.
- `id`, `kind`, `owner`, 날짜, tags처럼 행동을 바꾸지 않는 필드는 v1에서 만들지 않는다.
- `.devflow/index.md`는 최상위 질문→문서만 소유한다. domain·architecture·design 하위 지도는 각
  `index.md` 또는 부모 문서가 소유하며 루트에 복사하지 않는다.
- 누락·죽은 링크·반복 misroute가 관찰되기 전에는 generator를 만들지 않는다.

## 8. 정본 소유권 표

| 현재 사실 | 의미 소유자 | canonical home |
|---|---|---|
| 목적·사용자·가치·제품 언어·프로젝트 경계·cross-domain 구도 | Product | `.devflow/project/product.md` |
| 기술 구조·배치·의존·runtime/data·검증 채널 | Architecture | `.devflow/project/architecture*` |
| UI·상호작용 원칙 | Design | `.devflow/project/design*` |
| domain 고유 개념·상태·규칙·계약·함정 | 질문에 맞는 Product/Architecture/Design | `.devflow/project/domains/<domain>/`의 한 자리 |
| 현재 결정의 이유·기각 대안·재검토 조건 | 그 결정을 내린 의미 소유자 | `.devflow/project/decisions/` |
| 현재 변경의 목표·비범위·acceptance | Direct | work `spec.md` |
| 현재 phase·next action·blocker·promotion pending | Work item | work `state.md` |
| criterion별 판정·증거·실패 route | Verify | work `verification.md` |
| 한 사람의 환경·아직 공유되지 않은 중간 맥락 | 해당 member | team member work file |

Decision 문서는 현재 규칙의 사본이 아니다. 현재 규칙은 Product/Architecture/Design/Domain에 반영하고,
decision은 왜 그 방향이 현재 유효한지와 무엇이 생기면 다시 여는지만 소유한다.

## 9. artifact별 상태의 단일 소유자

전역 lifecycle은 없다. 각 임시 artifact만 자기 `state.md` 한 곳에서 상태를 가진다.

| artifact | 허용 phase | “완료”의 의미 |
|---|---|---|
| Sketch | `exploring`, `decision-ready`, `landing`, `blocked` | 모든 finding이 내부 owner에 흡수되거나 명시적으로 버려져 폴더 삭제 |
| Adopt | `inventory`, `reconstructing`, `review`, `landing`, `blocked` | 모든 유지 source가 내부 정본·명시 conflict·사용자 소유 외부 산출물 중 하나로 처분되고 폴더 삭제 |
| Work | `directing`, `ready`, `working`, `verifying`, `repairing`, `promotion-pending`, `blocked` | acceptance가 proven이고 승격 대기가 비어 work/team 파일 삭제 |
| Verification | `pending`, `proven`, `failed`, `unproven` | 최신 검증 입력에 대한 판정이 기록됨; work 완료와는 별개 |

`spec.md`에는 별도 `complete`를 두지 않는다. 실행 가능한지는 `state.phase: ready`, 진행 중인지는
`working|verifying|repairing`, 끝났는지는 active work 폴더의 부재와 정본 착지로 판정한다. 같은 상태를
spec·index·handoff에 반복하지 않는다.

## 10. Sketch 산출물과 흡수

대화가 시작됐다고 바로 문서를 만들지 않는다. 중단 뒤 보존해야 할 질문·결정·조사 단위가 처음 생길
때 `SNNN`을 만든다.

- `brief.md`: project/change scope, 지배 질문, 현재 배경, 비범위, 예상 destination.
- `state.md`: 현재 phase, 다음 질문/행동 하나, blocking unknown, finding→destination/landing 현황.
- `findings/*.md`: 한 finding이 brief를 흐릴 만큼 커질 때만 만든다. 사실/추론/사용자 결정 필요,
  증거, 현재 결론, destination만 두고 대화 transcript를 저장하지 않는다.

Project sketch의 landing destination은 주로 Product이고, 기술·UI finding은 Architecture/Design이
해당 단계를 시작할 때 흡수한다. Change sketch는 Direct spec으로 필요한 결정만 돌려주되, 프로젝트
전체에 계속 참인 사실은 먼저 해당 project owner에 착지시킨다. landing이 끝나면 sketch 폴더를
삭제한다. 따라서 조사 원문과 현재 정본이 장기 공존하지 않는다.

## 11. Direct → Work → Verify의 파일 계약

`spec.md`는 다음만 가진다.

- origin과 해결할 문제
- goal / non-goal
- acceptance criteria
- affected domains와 반드시 읽을 내부 정본
- 실행 단위와 허용 write scope
- blocking decision과 위험

`state.md`는 base revision, phase, current unit, next action 하나, blocker, handoff pointer,
verification summary, promotion pending만 가진다. 진행 일지는 만들지 않는다. checkpoint는 인계,
session 종료, unit 완료, verify 결과, route 변경 때뿐이다.

`verification.md`는 최신 판정과 같은 실패를 되풀이하지 않을 최소 기억을 가진다.

```text
criterion:
status: proven | failed | unproven
observed:
expected:
evidence:
failure_owner: work | direct | product | architecture | design
target_doc:
what_must_change_before_retry:
```

Verify 실패 시 owner 이름만 적지 않고 `target_doc`과 재시도 전 달라져야 할 것을 함께 적는다. 같은
criterion을 다시 시도하려면 가설·입력·구현·검증법 중 하나가 실제로 달라져야 한다. 관찰 수단이
없으면 pass가 아니라 `unproven`이다.

## 12. 지식 상승과 closure

다음 네 조건을 모두 만족한 결과만 장기 정본으로 올린다.

1. 다음 작업자의 판단을 실제로 바꾼다.
2. 현재 코드·실행 증거와 모순되지 않는다.
3. 하나의 semantic owner와 canonical home을 지정할 수 있다.
4. 진행 서사가 아니라 현재 유효한 사실·결정·함정이다.

Verify가 후보를 `state.md`의 `promotion pending`에 적고, 해당 의미 소유자가 자기 문서를 현재형으로
고친다. Product/Architecture/Design 판단이 필요 없는 확정 구현 사실은 Work가 owner 계약 아래 반영할
수 있다. 장기 cross-domain 계약만 `project/specs/`로 옮긴다. 모든 pending이 비면 work와 연결된 member
파일을 삭제한다. 별도 Land skill은 같은 누락이 반복 관찰되기 전에는 만들지 않는다.

## 13. Adopt의 완전 흡수 계약

Adopt는 원자료를 영구 참조하는 migration이 아니라 지식 소유권을 이전한다.

1. 코드·주석·문서·테스트·설정·운영 증거를 `sources.md`에서 빠짐없이 회계한다.
2. 각 지식 단위를 `observed fact / interpretation / conflict / unknown`으로 분리하고 정확한 내부
   canonical target을 정한다.
3. Product·Architecture·Design·Domain tree를 자기완결 문장으로 작성한다. 외부 문서를 다시 열어야
   이해되는 요약이나 링크 포인터는 불완전한 landing이다.
4. 코드나 live 운영 자산은 현재 증거로 계속 존재할 수 있지만, 기존 문서 경로는 정본 권위를 잃는다.
   삭제 여부는 사용자 소유권과 별도 보존 목적에 따라 정하며 Devflow correctness와 결합하지 않는다.
5. source로 풀 수 없는 모순만 `conflicts.md`에 남기고 semantic owner에게 보낸다.
6. 모든 source group이 내부 landing, 명시 conflict, 또는 “사용자가 별도 목적으로 유지하는 비정본
   산출물”로 처분되면 adoption 폴더를 삭제한다.

이후 외부 입력이 삭제·이동되어도 `.devflow/project/`만으로 프로젝트의 목적·경계·결정 이유를 이해할
수 있어야 한다. 과거 내용이 현재에 남아야 할 유일한 경우는 기각 이유가 현재 결정을 지키는 때이며,
그때도 외부 원문이 아니라 현재 decision 문서에 자기완결적으로 흡수한다.

## 14. 팀 맥락과 Resume

공유 사실은 work `state.md`, 개인의 환경·시도 직전 맥락은 `team/<member>/<work>.md`에 둔다. member
문서는 공용 정본이 아니며 다른 actor는 state의 handoff pointer가 있을 때만 보조로 읽는다. 병렬 작업은
각자 work ID를 가져 같은 state 파일의 동시 쓰기를 피한다.

Resume은 다음 순서만 읽는다.

1. `.devflow/index.md`
2. immediate child인 active sketch/adoption/work의 `state.md`
3. 사용자가 선택한 item의 spec/brief와 pointer로 지목된 member file
4. next owner가 요구하는 project 문서

Resume 결과는 `active items / 불일치·blocker / 다음 owner와 행동 하나 / 최소 read set`이다. 여러 active
item이 있으면 목록을 보여 선택을 받고 임의로 모두 진행하지 않는다. Resume은 파일을 만들거나 상태를
고쳐 정합성을 꾸미지 않는다.

## 15. Skill Rails 저작 경계

- source package 하나에서 아홉 prose target과 필요한 조건부 공통 module을 결정적으로 만든다.
- runtime project decision engine, 전역 lifecycle, journal DB를 넣지 않는다.
- build·diff·receipt는 delivery evidence이고 fresh-agent 행동은 behavior/effect evidence다.
- 연결부와 target은 내부 경로 계약을 가리킬 뿐 프로젝트 지식을 복제하지 않는다.
- module·script·field가 반복 사용 실패를 해결하지 않고 ceremony만 늘리면 다음 확장을 멈춘다.
