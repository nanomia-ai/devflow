---
title: Final planning decision ledger
status: owner-corrected-current-plan
purpose: Preserve decided, provisional, rejected, and corrected claims after independent design, debate, and inversion.
read_when: Read when challenging the architecture or deciding whether new evidence justifies a change.
canonical_for: Planning decisions and their falsifiers, not runtime state.
tags: [devflow-vnext, decisions, evidence, inversion]
---

# 최종 기획 결정 원장

## 1. 검증 과정

1. 레거시 실패, 중개노트 성공 사례, 새 Skill Rails, 공식 Claude/Codex 배포 근거를 독립 조사했다.
2. Coordinator가 최초 종합안을 만들고 `01-initial-synthesis`로 동결했다.
3. 페이블은 그 안을 보지 않고 독립 구조를 먼저 만들었다.
4. 두 안의 전제·사람 사용·AI 사용·지식 결과·가장 값싼 반증을 비교했다.
5. Skill Rails, 팀 폴더, fixture 순서를 두고 상호 반론한 뒤 `02-reconciled`로 동결했다.
6. 02의 모든 전제를 제거하는 역발상 검증과 별도 아키텍처 검토를 다시 수행했다.
7. 더 단순하다는 이유만으로 사용자의 명시 요구를 제거하지 않고, 증거 전 추가된 장치만 걷어냈다.
8. 사용자가 외부 정본 의존과 산출물 수명 공백을 지적한 뒤, 유효 결정 DD-77·98·103·104·108을
   원문 대조하고 이전 최종안을 보존한 채 내부 정본·owner·artifact lifecycle을 다시 수렴했다.

페이블 세션은 독립안부터 최종 역발상까지 같은 세션을 사용했고 마지막에도 컨텍스트가 약 27%였다.
따라서 사용자가 요구한 초기 이해 비용 재사용과 70% 교체 기준을 지켰다.

## 2. 최종 채택한 결정

1. 프로젝트 정본과 Devflow가 만드는 모든 문서는 `.devflow/` 한 루트가 소유한다.
2. `.devflow/index.md`가 관리 표식과 최상위 routing을 겸한다. 전역 lifecycle·queue·current agent는
   넣지 않고 readiness는 Product·Architecture와 active state에서 파생한다.
3. 공개 skill은 아홉 개다: `sketch`, `product`, `architecture`, `design`, `adopt`, `direct`, `work`,
   `verify`, `resume`.
4. 공개 `principles`, `domain`, `land` skill은 만들지 않는다.
5. Resume은 status/resume 전용이다. Domain 설명은 내부 project routing, 배치는 Architecture가 맡는다.
6. Sketch는 project/change 탐구를 함께 다루되 특정 사고법을 강제하지 않는다.
7. Product는 프로젝트 목적·사용자·cross-domain 구도, Domain README는 domain 고유 의미·경계·불변식,
   Architecture/Design은 각 기술·UI 관점을 소유한다.
8. Quick lane은 `Direct quick contract → Work 구현·비례 검증`이며 durable work와 독립 Verify가 없다.
9. Tracked lane은 `Direct → Work → Verify → owner landing → Work closure`다.
10. Verify는 code를 고치지 않고 failure owner, target document, retry 전 달라져야 할 조건을 분리한다.
11. 같은 criterion 재시도에는 다른 가설·입력·구현·검증법이 필요하다.
12. `state.md`가 공유 의도·acceptance·next action을, Git이 실제 bytes·revision을 소유한다.
13. team member work file은 개인 맥락만 가지며 공유 사실은 checkpoint에서 state로 이동한다.
14. 현재 project 문서 header는 `summary`, `read_when`만 필수다. 폐기 문서는 남겨 status를 붙이지 않고
    현재 자리에서 고치거나 삭제하며 Git이 과거를 맡는다.
15. `.devflow/index.md`가 유일한 최상위 수동 routing index이고 하위 index는 자기 subtree만 소유한다.
16. cross-domain/current use-case 계약이 계속 필요할 때만 `.devflow/project/specs/`를 만든다.
17. Skill Rails는 canonical source와 standalone target을 만드는 저작·배포 경계다. Runtime project
   decision/state engine으로 사용하지 않는다.
18. 공유되는 안정 규칙은 Skill Rails의 한 canonical module owner만 가지되, 모든 target이 무조건 읽는
   공개 principles 진입문으로 만들지 않는다.
19. Project AGENTS/CLAUDE pointer가 정적 routing을 맡고 SessionStart hook은 동적 보조일 뿐이다.
20. npm package는 portable root `plugin.json`, Claude adapter, 공통 skill artifacts를 담는다.
21. `.codex-plugin` fallback은 실제 요구 host version이 확인되기 전에는 배포하지 않는다.
22. 레거시 이동은 승인 후 housekeeping이며 구현 검증 gate가 아니다.
23. owner는 사람·agent·lock이 아니라 한 질문을 판단하고 한 canonical home을 유지하는 의미 역할이다.
24. owner 자체는 이동하지 않는다. finding·결함·결론이 질문 유형에 따라 owner로 route되고 흡수된다.
25. Sketch/Adopt/Work만 각자의 `state.md`에서 국소 phase를 가진다. 전역 lifecycle은 만들지 않는다.
26. spec의 진행·완료 상태는 work `state.md` 한 곳이 소유하며 완료 뒤 임시 work와 member 파일을 삭제한다.
27. Adopt 원자료 좌표는 일시 coverage 증거다. 최종 내부 정본은 자기완결적이고 외부 문서 삭제에
    영향을 받지 않아야 한다.
28. 루트 AGENTS/CLAUDE 및 hook은 `.devflow/index.md` 발견을 위한 연결부이며 지식을 소유하지 않는다.

## 3. 구현 관찰로만 바꿀 잠정 결정

| 현재 기본안 | 뒤집을 관찰 |
|---|---|
| 별도 Land 없이 owner landing/Work closure | 서로 다른 작업에서 같은 이유로 durable fact 승격이 반복 누락됨 |
| 독립 Sketch skill | Direct/Product decision work만으로 project/change checkpoint가 항상 자연스럽게 생성·소비됨 |
| 독립 Resume skill | plugin 없이 project pointer만으로 중단 작업 상태·next owner를 항상 정확히 복구함 |
| member namespace `team/<member>/<work>.md` | colocated per-work member file이 사용자의 팀원별 공간 의도를 더 잘 만족하고 찾기 비용도 낮음 |
| YAML `summary/read_when` header | prose lede가 두 host에서 같은 relevance 선택률을 보임 |
| 별도 work `spec/state/verification` | 실제 읽기·merge 비용이 분리 이점보다 큼 |
| `.devflow/project/domains/` | 단일-folder project에서 다른 내부 분할이 반복 misread를 줄임 |
| 수동 README | missing doc, dangling link, 반복 misroute가 실제로 발생함 |
| SessionStart adapter 지원 | project pointer만으로 충분하고 hook on/off가 effect 차이를 만들지 않음 |

잠정은 더 많은 기능을 미리 구현한다는 뜻이 아니다. 현재 더 작은 기본안을 사용하고 관찰이 그것을
뒤집을 때만 구조를 늘린다.

## 4. 거부한 구조

- 레거시 baseline·fallback·compatibility layer
- 선언형 lifecycle, global currentStage, queue, retry count, agent session DB
- 별도 Land skill을 증거 전에 추가하는 것
- generic one-skill entry와 Resume super-router
- per-skill vendored runtime과 runtime Decision engine
- 모든 target이 매번 읽는 장문의 shared principles
- capability 번호, 전역 glossary, capsule, coordinate grammar
- journal, freshness hash, claim, room, join/leave protocol
- team index나 handoff에 shared state를 복제하는 것
- 영구 personal notes 저장소에 승격·폐기 경로 없이 지식을 쌓는 것
- fixed retry count만으로 loop를 끊는 것
- 모든 spec에 사용자 승인을 요구하는 것
- exact read set 차이를 곧바로 실패로 판정하는 것
- Sketch에 Socratic/Dewey 같은 사고 절차를 강제하는 것
- 임의의 줄 수, import 수, 파일 수, 시간 비율을 보편 규칙으로 만드는 것
- 첫날부터 index generator·schema framework를 만드는 것
- build receipt로 AI behavior/effect를 증명했다고 간주하는 것
- hook이 없으면 작동하지 않는 구조
- 모든 transient spec을 무조건 삭제하거나 모두 영구 보존하는 것
- 외부 `docs/`를 Devflow 정본으로 두거나 Adopt 입력 경로를 영구 provenance로 요구하는 것
- 완료된 sketch/work/adoption을 현재 트리의 archive·묘비로 누적하는 것

## 5. 중요한 교정

- 02는 `land`를 확정 skill인 동시에 잠정이라고 적었다. 최종안은 별도 skill을 제거하고 반복 누락이
  관찰될 때만 재도입한다.
- 02의 marker는 lifecycle과 verify channel을 중복 소유했다. 최종안은 상태를 파일에서 파생하고
  verify channel은 Architecture 한 곳에 둔다.
- 02의 Product와 Domain이 경계를 중복 소유했다. 최종안은 cross-domain 구도와 domain 고유 경계를
  분리했다.
- 02는 Git을 state보다 항상 우선시했다. 최종안은 bytes/revision과 intent/next action의 관할을 나눴다.
- 02는 completion에서 모든 work를 삭제했다. 최종안은 장기 가치가 있는 cross-domain/current use-case
  계약만 조건부 `.devflow/project/specs/`로 승격한다.
- 02의 Skill Rails 숫자 제한은 관찰 근거가 없었다. 최종안은 current Skill Rails 계약과 질적 regrowth
  신호를 사용한다.
- 페이블의 최종 7-skill 대안은 lifecycle/Land 제거와 단일 transient shape에서 유익했지만, 사용자가
  명시한 Sketch·Resume과 팀원별 namespace까지 제거하므로 채택하지 않았다.
- 03은 중개노트의 성공 원리와 물리 경로를 혼동해 `docs/`를 정본으로 두었다. 이는 삭제 가능한 외부
  입력 의존성과 현재/과거 혼재를 만들고 DD-98·108에도 어긋났다. 04는 성공 원리만 가져와 전부
  `.devflow/` 내부로 흡수한다.
- 03의 “owner landing”은 owner를 사람·stage·파일 중 무엇으로 쓰는지 모호했다. 04는 의미 소유자,
  canonical home, 현재 actor, coordinator를 분리하고 owner가 아니라 질문/결과가 route된다고 고쳤다.

## 6. 잔여 미검증

- 실제 Skill Rails authoring 비용과 generated support files의 AI noise
- project pointer와 SessionStart hook의 effect 차이
- 팀원별 namespace가 장기적으로 stale room이 되지 않는지
- owner landing이 별도 Land 없이 반복 누락되지 않는지
- `summary/read_when`이 수개월 수동 편집 뒤에도 정확한지
- Adopt가 큰 brownfield에서도 질문 수와 invention을 억제하는지
- 약한 모델과 비설치 팀원도 같은 internal project/work 계약으로 안전하게 축소 동작하는지
- 완료된 Adopt 뒤 외부 입력 문서가 삭제되어도 같은 이해와 routing이 유지되는지

이 항목은 문서로 더 서술해 해결하지 않는다. [04-delivery-and-validation.md](04-delivery-and-validation.md)의
가장 작은 관찰에서 측정한다.
