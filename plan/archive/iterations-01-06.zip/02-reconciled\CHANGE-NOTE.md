---
title: Iteration 02 change note
status: frozen
purpose: Explain how the reconciled plan differs from the initial synthesis and which decisions remain empirical.
read_when: Read when comparing iteration 01 with iteration 02.
canonical_for: Design-history explanation only.
tags: [devflow-vnext, iteration-02, reconciliation]
---

# 02 — 독립안과 상호 반론을 거친 수렴안

## 검증 방식

페이블은 `01-initial-synthesis`를 보지 않은 상태에서 레거시, 중개노트, 공식 호스트 근거로 독립안을
먼저 만들었다. 이후 두 안을 비교하고 Coordinator의 반론을 다시 받아 같은 세션에서 수렴했다.
단순 검수나 평균안이 아니라 서로 다른 전제와 실제 사용 결과를 대립시켰다.

## 01에서 바뀐 핵심

- 프로젝트 정본 위치를 `.devflow/`에서 사람이 볼 수 있는 `docs/`로 옮겼다.
- `.devflow/`는 marker, sketch, adoption scratch, work, team context만 소유한다.
- 검증 뒤 지식 승격 누락을 막는 `land`를 추가해 공개 skill을 열 개로 만들었다.
- generic entry 대신 이름은 `resume`을 유지하되 status·continue·domain orientation까지 읽기 전용으로 맡겼다.
- 전역 JSON manifest 대신 짧은 Markdown marker와 lifecycle을 사용한다.
- header 다섯 필드를 `summary`, `read_when`, 의미 있을 때만 `status`로 줄였다.
- 팀원별 폴더는 유지하되 shared fact는 work `state.md`, 개인 context만 member file이 소유하게 했다.
- 첫 구현 순서를 bootstrap 전체보다 document routing → Resume → Direct/Work/Verify/Land로 바꿨다.
- synthetic/real fixture 두 개 대신 중개노트에서 파생한 작은 두-domain fixture와 answer key를 사용한다.
- Skill Rails를 새 계약에 맞춰 저작·배포 계층으로 제한하고 runtime decision/state engine을 금지했다.
- index generator는 초기 기능이 아니라 drift가 관찰된 뒤의 조건부 대응으로 내렸다.

## 유지한 핵심

- Domain 중심 조건부 문서 트리
- 공개 principles와 domain skill 제거
- Sketch의 project/change scope 통합
- Product → Architecture → optional Design chaining
- Direct/Work/Verify owner 분리와 failure-owner routing
- quick lane, Git 중심 이력, orchestrator 중립성
- 얇고 선택적인 SessionStart hook
- legacy를 실패 증거로만 쓰고 중개노트를 읽기 전용 성공 사례로 쓰는 원칙

## 아직 관찰로 정할 것

- Land를 별도 skill로 유지할지
- planning/adopting lifecycle을 실제로 구분할지
- member fact/context partition이 staleness를 막는지
- 수동 README가 언제 generator를 필요로 하는지
- Skill Rails authoring 비용과 emitted runtime의 AI noise
- project Sketch 폴더가 실제 중단 복구에 필요한지

## 명시적으로 거부한 것

- per-skill vendored runtime과 runtime Decision engine
- unconditional shared principles module
- capability/glossary/capsule/journal/room/claim 체계
- team member index에 공유 상태를 복제하는 구조
- 모든 사고법과 예외를 skill prose에 서술하는 구조
- build receipt를 AI behavior/effect 증거로 대신하는 구조

다음 `03-inversion-review`는 이 수렴안 자체를 기준으로 더 적은 skill·문서·상태가 가능한지 다시
뒤집어 본다. 02 파일은 그 과정에서 수정하지 않는다.
