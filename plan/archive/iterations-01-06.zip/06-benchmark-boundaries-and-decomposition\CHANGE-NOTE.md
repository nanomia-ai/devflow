---
title: Iteration 06 change note
status: frozen-history
purpose: Record why the benchmark boundary and conditional document-decomposition plan changed after iteration 05.
read_when: Read when comparing iteration 06 with iteration 05 or challenging the provenance and split/fold decisions.
canonical_for: Changes that closed iteration 06 only; the root plan remains the current planning surface.
tags: [devflow-vnext, iteration, benchmark, decomposition, frozen]
---

# 06 변경 기록

## 닫힌 결정

1. 중개노트는 질문별 정본 소유, 얕은 route, 조건부 읽기, 현재 정본과 임시 추론의 분리만 benchmark한다.
   물리 경로, 특정 기술 taxonomy, registry schema와 대형 handoff 형식은 복제하지 않는다.
2. 레거시 K에서는 “함께 읽고 같은 이유로 바뀌는 지식 단위”와 부모의 조건부 route만 보존한다.
   K 번호, capsule, capability 축, 줄·개봉 예산과 projection runtime은 폐기한다.
3. `.devflow/` 단일 root는 레거시의 유효 결정을 유지하되 모든 정본·임시 산출물의 수명 체계와 Adopt의
   자기완결 흡수까지 포함하도록 강화했다.
4. 문서 분리 전 owner와 수명을 먼저 바로잡는다. 이후 사전 선택 가능성, 의미 응집성, 실제 총비용
   이익을 모두 확인한다. 길이는 split/fold 어느 쪽의 판정도 아니다.
5. Parent는 공통 불변식과 route, child는 concern 계약을 소유한다. Child 직접 진입도 가장 가까운
   parent를 먼저 read bundle에 포함하고, 늘 함께 읽히고 바뀌는 child는 다시 합친다.
6. Architecture의 frontend/backend/validation 같은 이름은 사례일 뿐 고정 taxonomy가 아니다. 형제가
   같은 명목상 축을 가질 필요는 없고 route 판별 가능성과 한 canonical home이 기준이다.
7. v1은 범용 Spec child tree를 만들지 않는다. 다른 단위의 성공·취소·순서와 공유 rollout·rollback·
   요청 전체 완료 조건에서 독립적인 단위만 별도 Work artifact로 나눈다.
8. `.devflow/index.md`는 최상위 route와 bounded Resume orientation만 소유한다. 공통 작성 규칙은 Skill
   Rails source graph의 entry/module이 소유하며 index에 project document law를 복제하지 않는다.

## 독립 검토로 바뀐 것

- 최초 3-gate 앞에 owner·수명 admission을 추가했다.
- 반복 빈도뿐 아니라 드물어도 큰 판단 오류·context 손실을 총비용에 포함했다.
- “하나의 지배적인 분해 축”을 제거해 cross-cut concern을 억지 중간 taxonomy에 숨기지 않게 했다.
- Parent+child 자기완결을 실제 parent-first routing 계약으로 바꿨다.
- Spec 단위별 acceptance가 있어도 request-level rollout·rollback·closure가 남는 반례를 추가했다.
- 근거 문서 09, 실행 정본 08, 검증 계획 04를 분리해 두 번째 매뉴얼을 만들지 않았다.
- Index가 공통 document law의 operational owner라는 iteration 05 결정을 철회했다.

## 검증 상태

- 구조적 결정과 문서 간 소유 정합성: independent architecture review 통과.
- repository invariant suites와 Markdown 상대 링크: 통과.
- Claude/Codex의 실제 child 선택, parent-first read, fold와 Spec artifact 분리 효과: 아직 unproven이며
  Phase 1 fresh-agent fixture에서 검증한다.

## iteration 05에서 보존한 것

- 아홉 공개 skill과 decision route
- `.devflow/` 내부 정본과 transient artifact의 수명 분리
- `summary/read_when` 최소 header
- owner=canonical home, Git=과거, state=현재 작업 좌표
- Skill Rails를 runtime engine이 아닌 저작·배포 계층으로 쓰는 경계
