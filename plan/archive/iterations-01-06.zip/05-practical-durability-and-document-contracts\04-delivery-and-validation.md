---
title: Incremental delivery and validation plan
status: final-reviewed-current-plan
purpose: Sequence implementation so the cheapest discriminating observation precedes each new layer of complexity.
read_when: Read before implementing, approving a phase, or claiming a phase complete.
canonical_for: Proposed phase order, gates, falsifiers, and stop rules.
tags: [devflow-vnext, delivery, validation, skill-rails]
---

# 점진 구현·검증 계획

## 1. 실행 계약

각 phase는 하나의 중요한 주장을 공격한다. 파일 생성, build 성공, schema 통과는 delivery evidence일
뿐이다.

| 증거 | 답하는 질문 |
|---|---|
| delivery | canonical source에서 같은 artifact를 결정적으로 만들 수 있는가 |
| behavior | fresh AI가 필요한 canonical home과 decision route를 찾고 안전한 다음 행동을 하는가 |
| effect | 실제 변경·인계·검증·지식 승격에서 사람의 부담과 실패가 줄었는가 |

결과는 `proven`, `failed`, `unproven`으로 기록한다. 실행하지 못한 검증을 pass로 쓰지 않는다.
Target 하나를 build하고 fresh-use로 관찰하기 전 다음 target을 구현하지 않는다.

## 2. Phase 0 — 승인 후 housekeeping

레거시를 `legacy/v0.25.1/`로 이동하는 일은 필요하지만 설계 검증의 gate나 migration이 아니다. 실제
구버전 운영 프로젝트가 없으므로 compatibility path는 만들지 않는다. 소유자 승인 뒤
tracked/untracked, cache와 source 차이, 이동 전후 파일 목록·hash, Git recovery path를 확인해 별도
변경으로 수행한다. 새 source/build/test 경로는 legacy를 import하거나 fallback으로 사용하지 않는다.
이 계획 단계에서는 이동하지 않는다.

## 3. Phase 1 — keyed document-system pilot

### 공격할 주장

수동 `.devflow/index.md`, 내부 Product, Architecture, 두 domain tree, decision, 작은 work state만으로 fresh AI가
전체를 읽지 않고 canonical 문서와 다음 행동을 고를 수 있다.

### fixture와 answer key

중개노트 원본은 수정하지 않는다. 별도 fixture에 두 domain과 실제 경계 난점을 대표하는 10~12개
문서만 재구성한다. 작성 전에 질문별로 다음 answer key를 만든다.

- 반드시 읽어야 할 canonical 문서
- 읽지 않아야 할 무관 문서
- 허용 가능한 읽기 비용
- 올바른 next action

[08-document-contracts.md](08-document-contracts.md)의 Product·Architecture·Domain·Decision·Spec·State·
Verification 표본을 실제로 작성한다. 각 문서가 자기 질문, 필수 배경과 의도, 현재 결론, 다음 route를
전달하는지 확인하고 빈 template 절이나 복제 요약이 생기면 형식을 먼저 줄인다.

추가 read는 자동 실패가 아니라 원인 분석 신호다. 정답에 도달한 다른 유효 경로를 exact-set 차이만으로
실패 처리하지 않는다. 한 시간 이내 syntax pre-check로 `summary/read_when`과 Domain README 우선 읽기만
확인하며, 범용 schema·renderer는 만들지 않는다.

Fixture의 Devflow 문서는 전부 `.devflow/` 아래에만 둔다. 루트에는 다음 한 줄 성격의 host pointer만
허용한다: “프로젝트 작업 전 `.devflow/index.md`를 읽어라.” 같은 내용을 `docs/`에도 두는 대조군은
만들지 않는다. 외부 참고 문서를 제거한 뒤에도 answer key가 유지되는지를 이 phase에서 바로 검사한다.

### 통과 신호

- canonical 문서와 next action이 맞다.
- 조건부 depth는 relevance가 있을 때만 열린다.
- 무관한 Product/Architecture/domain 전체를 관성적으로 읽지 않는다.
- 문서 구조, header, entry 중 failure source를 분리할 수 있다.
- 외부 참고 경로 없이 내부 project tree만으로 질문의 배경과 현재 결정을 설명한다.
- 최초 Sketch/Product/Adopt가 index를 만들고, 질문→문서 route가 실제로 바뀔 때만 부모 route를 같은
  변경에서 갱신한다. Active artifact는 index에 나열하지 않고 glob으로 발견한다.
- foundation readiness는 index의 저장 상태가 아니라 파일과 Architecture의 Design applicability에서 파생된다.

## 4. Phase 2 — Resume target 하나

새 Skill Rails source package와 `resume` prose target 하나만 만든다. 가장 작은 완전한 entry source를
build하고 generated diff·receipt를 검토한다. Phase gate에서 deterministic delivery, integrity,
currentness를 확인한다.

Standalone target을 fresh Claude/Codex session에 주고 status·continue 질문을 관찰한다. Resume은
Domain 설명이나 배치 결정을 대신하지 않고 active state와 다음 route 하나만 반환해야 한다. Build
receipt는 behavior pass가 아니다.

Active item이 0인 두 bootstrap fixture도 포함한다: Product만 완결된 경우에는 Architecture를, Product
작성 중 끊긴 경우에는 반쪽 canonical file을 current로 취급하지 않고 checkpoint 복구를 반환해야 한다.

## 5. Phase 3 — Direct target

Direct만 추가해 같은 요청을 두 경로로 분류한다.

```text
quick   → current-turn quick contract
tracked → work/<id>/spec.md + 초기 state.md
```

Spec은 goal, non-goal, acceptance, affected domains/canonical homes, read-first, units를 담는다. 사용자 승인은 모든 spec이
아니라 제품 의미, 불가역 변경, 권한 밖 결정처럼 실제 binding choice에만 요구한다. Blocking unknown은
아직 Sketch target 없이 “exploration needed”로 안전하게 멈추는지만 본다.

## 6. Phase 4 — Work target과 중단 복구

Work의 유효 입력은 `durable spec | current-turn quick contract`다. Quick은 같은 turn에서 구현하고
비례 검증한 뒤 durable folder 없이 끝낸다. Tracked work는 한 unit을 구현하고 `state.md`를 갱신한다.

Work 전, commit 후 Verify 전, verification 준비 중에 session을 끊고 Resume으로 재개한다. Git은 실제
bytes·revision, spec은 intent·acceptance·write boundary, state는 last safe point·next action을 소유한다.
base나 contract를 바꾸는 충돌만 구현을 막고 다른 불일치는 관할별로 조정한다.

## 7. Phase 5 — Verify와 knowledge landing closure

Verify target을 별도로 build하고 독립 fresh-use를 본다. Verify는 code를 수정하지 않고 criterion별
`proven|failed|unproven`, evidence, failure route, retry 전에 달라져야 할 조건을 남긴다.

Direct가 최소 state를 쓴 뒤 spec 완결 전에 중단되는 fixture와 Verify snapshot의 atomic replace 전후에
중단되는 fixture를 둔다. Resume은 임시 파일을 current로 읽지 않고, 필수 sibling이 없는 artifact를
정확한 복구 route와 함께 보고해야 한다.

Pass 경로:

```text
Verify → verification에 증거 기반 knowledge candidates 기록
       → Work closure가 후보를 채택·기각
       → 열린 판단은 blocker + decision route로 전달
       → 확인된 fact → canonical path만 pending_landings에 기록
       → Work가 landing을 확인해 pending이 비면 artifact와 member files 삭제
       → PR/commit review가 있으면 goal·acceptance·verification 요약을 남김
```

같은 실패 재시도에는 달라진 가설·입력·구현·검증법이 필요하다. 서로 다른 작업에서 같은 이유로
promotion 누락이 반복될 때만 별도 closure skill을 제안한다. 한 번의 누락으로 전역 skill을 만들지
않는다. Cross-domain 계약은 Product/Domain/Architecture/decision의 현재 질문별 home으로 분해되는지 시험한다.
완료된 change spec 자체를 장기 canon으로 승격하지 않는다.

## 8. Phase 6 — Product → Architecture → optional Design

각 target을 순서대로 하나씩 build·관찰한다.

1. 명확한 brief → Product
2. Product를 입력으로 Architecture
3. backend-only brief → Design 생략
4. UI project → Design

Product는 프로젝트 목적·사용자·cross-domain 구도와 domain 업무 의미를 소유한다. Domain tree는
그 지식의 canonical home이고, Architecture는 기술·검증 채널을, Design은 UI 원칙을 소유한다. 같은 사실이 두 문서에
복제되면 phase를 멈춘다.

## 9. Phase 7 — Sketch target

`sketch`는 project/change scope를 함께 다루고 checkpoint와 finding destination만 보존한다. 특정 질문법,
시장 분석 절차, 사고 순서를 강제하지 않는다.

관찰:

- 모호한 신규 idea가 Product로 이어지는가
- uncertain change가 Direct로 필요한 결정만 반환하는가
- 중단된 sketch가 transcript 없이 재개되는가
- project sketch를 일반 work shape로 합치는 편이 더 단순한지

Sketch가 독립 skill 없이 Direct/Product 안에서 동일하게 checkpoint된다면 통합을 재검토하되, 사용자가
명시한 독립 탐구 경험을 잃지 않는지 먼저 본다.

## 10. Phase 8 — Adopt vertical slice와 target

Adopt 문서 prototype을 먼저 작은 brownfield fixture에서 시험한 뒤 target 하나를 build한다.

성공 조건:

- maintained source의 의미가 disposition 없이 사라지지 않는다.
- observed fact, interpretation, unknown, conflict가 구분된다.
- Product/Architecture decision route와 Domain canonical home이 겹치지 않는다.
- 모르는 내용을 문서 완성을 위해 발명하지 않는다.
- 외부 문서를 다시 열지 않아도 내부 Product/Architecture/Domain 문서가 자기완결적으로 이해된다.
- 사람에게는 source로 결정할 수 없는 경계·모순만 묻는다.
- source group의 include/exclude가 입력을 완전히 partition하고 uncovered path가 0이다.
- 보존 외부 문서는 검색면 밖 이동·최소 pointer·명시적 비정본 경계 중 하나를 만족한다.
- 흡수 source를 삭제·이동한 fixture에서도 내부 지식 질문과 다음 변경 routing이 동일하게 성공한다.
- 고의로 모순된 retained 문서가 남은 fixture에서도 fresh AI가 내부 정본을 우선하고 충돌을 보고한다.

원본 중개노트에는 어떤 변경도 하지 않는다.

## 11. Phase 9 — 팀 handoff와 병렬 branch

Sketch·Adopt·Work fixture에서 Agent A가 공유 사실을 artifact `state.md`, 개인 환경·중간 추론을
`team/A/<artifact-id>.md`에 둔다. “관리권이 바뀌기 전에 현재 행동을 끝내지 못하면 snapshot을 갱신한다”는
한 원칙이 session 중단, branch 전환, 다른 agent 인계에서 같은 결과를 만드는지 본다. 매 turn마다
기록하지 않는다.

서로 다른 충돌 저항 artifact ID와 안정적인 seam으로 두 branch를 진행해 정상 merge하고,
같은 package manifest를 함께 고치는 비상충 대조군도 사전 금지 없이 통합되는지 본다. 이어서
의도적으로 같은 canonical home을 상충 변경한 대조군은 명시적 merge·decision으로 멈추는지 본다.
공유 사실 하나를 member file에만 남겼을 때 Agent B가 이를 정본으로 실행하지 않아야 한다. Closure 뒤
artifact와 member file이 삭제되고, 중앙 번호·identity protocol·room·claim 없이 재개되어야 한다.
Member 경로는 repository team identifier를 쓰고 기본값은 `git config user.name`의 안정된 slug이며,
동일 사용자의 여러 agent가 실제로 구분돼야 할 때만 짧은 label을 덧붙인다. Active artifact가 없는 dirty
checkout은 “진행 중 없음”이 아니라 unowned work로 보고되어야 한다.

## 12. Phase 10 — index 기계화의 조건부 도입

다음 중 하나가 관찰될 때만 작은 checker/generator를 검토한다.

- maintained doc이 README에서 빠짐
- dangling link가 남음
- 동일 질문에서 잘못된 `read_when`이 반복됨
- 같은 routing 정보를 둘 이상의 index에 중복 작성함

도입하더라도 title, summary, read_when과 파일 존재만 결정적으로 검사한다. canonical home 선택,
Domain 경계, 좋은 summary를 script가 판단하지 않는다.

## 13. Phase 11 — npm·host adapter와 SessionStart

핵심 behavior가 명시 호출과 프로젝트 문서만으로 통과한 뒤 설치를 검증한다.

```text
plugin.json                         # portable identity + extensions.com.openai
.claude-plugin/plugin.json         # Claude 공식 adapter
skills/                             # Skill Rails built targets
hooks/hooks.json                    # host adapter가 실제 지원할 때
scripts/session-start.*             # marker check + 짧은 Resume pointer
```

프로젝트 AGENTS/CLAUDE pointer는 `.devflow/index.md` 발견만 맡고, hook은 marker 존재와 Resume 진입만 알리는
동적 보조다. 같은 규칙을 두 곳에 복제하지 않는다. Hook을 제거해도 skill gate와 문서 routing이
작동해야 한다. `.codex-plugin`은 실제 요구 host version이 확인될 때만 fallback으로 추가한다.

같은 npm artifact를 두 marketplace source로 설치하고 clean session, update, uninstall, hook on/off를
비교한다. Hook이 effect를 개선하지 않으면 v1 package에서 빼되 공식 지원 경로는 문서화한다.

## 14. Skill Rails regrowth guard

Skill Rails의 현재 계약을 그대로 따르되 숫자 자체를 새 규칙으로 만들지 않는다.

- 판단 중심 skill은 prose target을 우선한다.
- 각 entry는 배경·의도, 목적, trigger/비범위, gate, 입력, 소유 출력, 완료 증거, 다음 route, 금지 책임을
  가진 가장 작은 독립 계약이다.
- Bootstrap template이 `.devflow/index.md`에 project document law를 심고, 각 skill은 그 operational law를
  가리킨다. 한 writer만 쓰는 계약은 entry에 두고 여러 writer가 공유하는 계약만 conditional module로 둔다.
- module open condition은 현재 입력으로 판별 가능해야 한다.
- authoring CLI와 build runtime을 project workflow에 복제하지 않는다.
- receipt는 delivery evidence이며 behavior/effect pass criterion이 아니다.
- checker는 header·경로·state 값·dangling route만 검사하고 문서 의미를 판정하지 않는다.
- eligibility/gate와 route vocabulary는 한 authored source에서 description/entry로 투영한다. 충돌 저항
  artifact ID와 atomic snapshot publication은 작은 deterministic mechanism으로 검증한다.
- module·script·field가 반복 사용 실패를 해결하지 않고 ceremony만 늘리면 확장을 멈춘다.

첫 targets에서 authoring과 build 비용을 측정하되 임의 비율을 자동 gate로 쓰지 않는다. 비용이 문서·
행동 실험을 잠식하면 evidence와 함께 사용자에게 완화 결정을 요청한다.

## 15. 최초 fresh-agent 관찰

1. unmanaged repo에서 Work가 쓰기 전에 거절하는가
2. backend-only project가 Design을 만들지 않는가
3. Domain 질문에서 README → 관련 depth만 읽는가
4. 중단된 work를 transcript 없이 재개하는가
5. spec 결함을 Work 반복이 아니라 Direct로 돌리는가
6. 관찰 불가 criterion을 pass가 아니라 unproven으로 닫는가
7. member context의 공유 사실을 state보다 우선하지 않는가
8. closure가 progress narrative를 정본에 넣지 않는가
9. plugin과 hook이 없어도 AGENTS/CLAUDE pointer와 `.devflow/`로 안전하게 축소 동작하는가
10. Adopt 입력 문서를 제거한 뒤에도 내부 정본만으로 동일한 질문에 답하고 변경을 시작하는가
11. Product/Architecture 판단이 중단됐을 때 반쪽 정본 대신 Sketch checkpoint로 이어지는가
12. 병렬 branch가 별도 artifact/write scope로 merge되고 같은 정본 충돌은 판단 사건으로 드러나는가
13. Spec만으로 배경·의도·비범위·acceptance를 이해하고 worker가 구현 방법을 자율 판단하는가

관찰을 통과했다고 시나리오를 무한히 추가하지 않는다. 새 시나리오는 기존 결정을 실제로 바꾸는
실패가 있을 때만 추가한다.
