---
title: Iteration 04 change note
status: frozen
purpose: Explain why the former final plan was replaced and what this baseline changed before external re-review.
read_when: Read when comparing iteration 03 with the internal-canon correction.
canonical_for: The transition from iteration 03 to 04 only.
tags: [devflow-vnext, planning, iteration-04, correction]
---

# 04 — 내부 정본과 산출물 수명 교정

## 교정 계기

Iteration 03은 중개노트의 성공 사례에서 질문별 routing과 문서 소유권뿐 아니라 `docs/`라는 물리 위치까지
일반화했다. 그 결과 Devflow 정본은 `docs/`, 진행 상태는 `.devflow/`라는 두 루트가 생겼다. 사용자는
이 구조가 Adopt 입력 삭제, 과거/현재 혼재, 아래에서 올라오는 지식 승격에서 모순을 만든다고 지적했다.

원문 결정을 다시 확인한 결과 이 지적은 다음 유효 결정과도 일치했다.

- DD-98: 대상 프로젝트 정본 루트는 `.devflow/` 하나다.
- DD-108: Adopt는 지식 소유권을 이전하며 흡수 입력은 영구 의존성이 아니다.
- DD-77: 문서는 현재만 말하고 과거 판본은 Git이 맡는다.
- DD-103·104: 지식 단위와 의미 소유자별 현재 위치를 보존한다.

## 바뀐 결정

1. Product, Architecture, Design, Domain, decision, 장기 spec까지 전부 `.devflow/project/` 안으로 옮겼다.
2. `.devflow/index.md`가 관리 표식과 최상위 routing을 겸하고 외부 AGENTS/CLAUDE/hook은 포인터 연결부로만 남겼다.
3. Adopt는 외부 문서를 가리키는 대신 자기완결 내부 문장으로 완전 흡수하며 완료 뒤 scratch를 삭제한다.
4. owner를 의미 소유자, canonical home, 현재 actor, coordinator로 분리했다. owner 자체는 이동하지 않고
   질문·finding·결함이 owner로 route된다.
5. Sketch/Adopt/Work/Verification이 만드는 파일과 국소 phase, 완료·삭제 조건을 명시했다.
6. spec 진행 상태는 spec과 index에 복제하지 않고 work `state.md` 한 곳이 소유한다.
7. 완료된 sketch/work/adoption은 archive나 묘비로 현재 트리에 남기지 않고 Git이 이력을 보존한다.
8. 산출물 흐름을 별도 `07-artifact-lifecycle-and-owner-model.md`의 diagram과 상태표로 펼쳤다.

## 유지한 결정

- 공개 skill 아홉 개와 no public principles/domain/land/lifecycle
- Sketch의 project/change 두 scope
- Direct → Work → Verify와 failure-owner routing
- Resume의 읽기 전용 성격
- work shared state와 member-specific transient context 분리
- Skill Rails의 authoring/delivery 전용 경계
- 문서 시스템을 첫 수직 조각으로 검증하는 구현 순서

## 이 기준선의 상태

이 폴더는 사용자 교정을 반영한 뒤, 재사용 Fable 세션과 독립 아키텍처 검토 결과를 적용하기 **전**의
완전한 기준선이다. 이후 검토가 상태 수, 문서 모양, skill 경계를 바꾸더라도 이 파일들은 수정하지 않는다.
