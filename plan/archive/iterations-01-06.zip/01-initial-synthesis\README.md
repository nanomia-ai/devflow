---
title: Devflow vNext planning map
status: draft-for-owner-review
purpose: Route readers to the smallest planning document that answers their current question.
read_when: Always open this file before another file under plan/.
canonical_for: Planning navigation only; this directory is not runtime or product canon.
tags: [devflow-vnext, planning, index]
---

# Devflow vNext 기획 지도

이 디렉터리는 실패한 Devflow를 수리하는 설계가 아니라, 확인된 사용자 목적과 실패 장면을 바탕으로
새 체계를 점진적으로 만들기 위한 **승인 전 계획**이다. 기존 저장소의 결정·상태기계·파일 구조는
구현 기준선이 아니다. `legacy/`로 격리한 뒤 참고 증거로만 사용한다.

## 이번 계획이 고정하는 것

- 사람이 실제로 쓰기 쉽고 AI가 자연스럽게 판단할 수 있는 흐름
- 장기 작업에서 현재 진실이 적절한 지식 소유자에게 누적되는 문서 계층
- 개인 작업 기록과 프로젝트 공용 지식의 분리 및 승격 경로
- 모든 스킬의 짧은 목적, 진입 조건, 입력·출력, 다음 스킬 연결
- 문서 시스템을 가장 먼저 작은 수직 흐름으로 검증하는 구현 순서

## 이번 계획이 아직 고정하지 않는 것

- 각 스킬의 상세 질문법, 완성된 프롬프트, 예외 목록
- 범용 상태 엔진, 전이 문법, 자동 오케스트레이터
- 문서 형식 전체를 강제하는 스키마 또는 범용 checker
- 레거시와의 호환성

## 질문별 읽기 경로

| 지금 답할 질문 | 읽을 문서 |
|---|---|
| 왜 다시 설계하며 무엇을 반복하면 안 되는가 | [`01-intent-and-evidence.md`](01-intent-and-evidence.md) |
| 어떤 스킬을 두고 문서·지식·상태를 어떻게 소유하는가 | [`02-skill-and-document-architecture.md`](02-skill-and-document-architecture.md) |
| 사람과 AI가 실제 상황에서 어떻게 사용하는가 | [`03-usage-scenarios.md`](03-usage-scenarios.md) |
| 무엇부터 구현하고 어떤 관찰로 다음 단계 진입을 결정하는가 | [`04-delivery-and-validation.md`](04-delivery-and-validation.md) |
| 레거시, 중개노트, 공식 Claude/Codex 문서가 무엇을 뒷받침하는가 | [`05-research-evidence.md`](05-research-evidence.md) |

## 계획 문서의 수명

이 계획은 승인과 초기 구현을 위한 근거다. 구현이 시작된 뒤 현재 진실은 Devflow의 실제 정본으로
승격하고, 조사 과정과 기각 대안은 계획/연구 기록으로 남는다. 계획 문장을 런타임 스킬 규칙으로
그대로 복사하지 않는다.

