---
title: Artifact lifecycle and owner model
status: owner-corrected-current-plan
purpose: Make ownership, file creation, state transitions, landing, and cleanup visually inspectable.
read_when: Read when asking what each skill creates, how ownership routes, or how progress and completion are detected.
canonical_for: Detailed proposed artifact lifecycle and owner transfer semantics.
tags: [devflow-vnext, lifecycle, owners, sketch, work, verify, resume]
---

# 산출물 수명과 소유자 모델

## 1. 한눈에 보는 두 계층

```mermaid
flowchart LR
    subgraph Temporary[임시 작업 지식]
      SK[sketches/S...]
      AD[adoption/]
      WO[work/W...]
      TM[team/member/W...]
    end
    subgraph Current[장기 현재 지식]
      PR[project/product.md]
      AR[project/architecture*]
      DE[project/design*]
      DO[project/domains/*]
      DR[project/decisions/*]
      SP[project/specs/*]
    end
    SK -->|채택된 제품 결론| PR
    SK -->|채택된 기술·UI 결론| AR
    SK -->|변경 결론| WO
    AD -->|완전 흡수| Current
    WO -->|검증된 현재 지식| Current
    TM -->|공유 사실만 checkpoint에서| WO
```

임시 계층은 현재 일을 끝내기 위한 기억이고, 장기 계층은 다음 일에도 계속 참인 현재 지식이다.
임시 자료를 archive로 쌓아 지식처럼 읽게 하지 않는다. landing 뒤 삭제하고 Git이 과정을 보존한다.

## 2. owner routing은 인계이지 권한 이동이 아니다

```mermaid
sequenceDiagram
    participant U as 사용자
    participant S as Sketch
    participant P as Product/Architecture/Design
    participant D as Direct
    participant W as Work
    participant V as Verify
    participant R as Resume
    U->>S: 아직 결정되지 않은 문제
    S->>P: 프로젝트 전체에 계속 참인 결론
    S->>D: 이번 변경의 선택·제약
    D->>W: ready spec
    W->>V: 구현 + 검증 입력
    alt 구현 결함
      V->>W: 증거 + 바꿀 것
    else spec 결함
      V->>D: 깨진 전제 + target
    else 상위 정본 결함
      V->>P: 질문 유형 + target document
      P->>D: 현재 정본을 갱신한 뒤 spec 재구성
    else proven
      V->>P: promotion candidates
      P->>W: landing 완료
      W-->>U: 임시 work 정리
    end
    R-->>U: 언제든 현재 owner와 다음 행동만 보고
```

중요한 불변식은 다음과 같다.

- 질문이 바뀌면 route가 바뀌지만 기존 skill의 책임이 확장되지는 않는다.
- 소비자는 upstream 문서를 복사하지 않고 자기 목적에 필요한 결론만 흡수한다.
- 하나의 현재 사실은 최종 canonical home 하나에만 남는다.
- Resume은 route를 발견할 뿐 어떤 owner의 판단도 대신하지 않는다.

## 3. Sketch가 실제로 만드는 것

### 생성 전

아이디어 대화, 질문 한두 번, 버릴 수 있는 탐색은 디스크에 쓰지 않는다. 다음 중 하나가 성립할 때만
checkpoint를 만든다.

- 세션이 끊겨도 보존할 지배 질문이 생겼다.
- 결정 또는 결정에 영향을 주는 근거가 생겼다.
- 별도 조사 단위와 다음 행동이 생겼다.
- 어느 의미 소유자가 결론을 받아야 하는지 식별할 수 있다.

### 생성 모양

```text
.devflow/sketches/S003-offline-sync/
  brief.md
  state.md
  findings/                       # 필요할 때만
    01-conflict-policy.md
    02-market-constraint.md
```

`brief.md`는 “왜 탐구하는가”를, `state.md`는 “지금 어디이며 다음 무엇인가”를 소유한다. finding은
한 독자와 한 변경 이유를 가진 독립 단위일 때만 분리한다.

```yaml
# state.md의 개념 예시
phase: exploring
next_action: 오프라인 충돌 시 사용자가 선택할 수 있는 범위를 확인한다.
blocking_unknowns:
  - 자동 병합이 법적 기록 보존과 양립하는가
landing:
  product: pending
  architecture: not-ready
  direct: not-applicable
```

Project sketch는 Product를 만들기 전에도 `.devflow/` 안에 존재한다. 이때 index는 bootstrap marker와
Sketch route만 제공하며 Direct/Work/Verify는 foundation 부재를 보고 쓰기 전에 거절한다.

### 종료

```text
exploring → decision-ready → landing → 폴더 삭제
     │             │
     └─────────────┴→ blocked → 질문/새 증거 뒤 이전 phase
```

채택된 결론은 Product/Architecture/Design 또는 Direct spec에 자기완결 문장으로 흡수한다. 채택하지 않은
탐색은 현재 트리에 남기지 않는다. 다시 제안될 가능성이 높은 기각 이유만 decision에 흡수한다.

## 4. Direct가 만드는 spec과 상태

Tracked 작업은 다음 두 파일로 시작한다.

```text
.devflow/work/W012-bulk-import/
  spec.md       # 무엇을 왜, 어디까지, 어떻게 입증할지
  state.md      # 지금 어느 phase인지
```

Spec은 목표·비범위·acceptance·read-first·write scope·unit을 소유한다. `draft`, `done` 같은 중복 상태를
spec에 적지 않는다. 아래처럼 state만 현재성을 소유한다.

```mermaid
stateDiagram-v2
    [*] --> directing
    directing --> ready: 계약이 실행 가능
    directing --> blocked: 결정 부족
    ready --> working: Work 시작
    working --> verifying: 구현 단위 준비
    working --> directing: spec 전제 오류
    verifying --> repairing: failed
    repairing --> working: 달라진 수정 시작
    verifying --> blocked: unproven이며 재개 조건 대기
    verifying --> promotion_pending: proven
    promotion_pending --> [*]: 모든 landing 후 폴더 삭제
```

따라서 질문별 판정은 단순하다.

| 질문 | 보는 곳 | 판정 |
|---|---|---|
| spec이 실행 가능한가 | `state.md` | `phase: ready` |
| 누가 구현 중인가 | `state.md`의 handoff pointer, 필요 시 team file | actor 맥락일 뿐 의미 owner는 불변 |
| 작업이 진행 중인가 | work 폴더의 `state.phase` | working/verifying/repairing 등 |
| 작업이 완료됐는가 | active work 폴더와 pending | 폴더가 없고 필요한 정본 landing이 존재 |
| 예전 spec은 어디 있나 | Git | 현재 AI의 기본 read set에는 없음 |

## 5. Work가 갱신하는 것

Work는 구현 방법·순서·국소 구조를 자율적으로 판단한다. 다음 checkpoint에서만 `state.md`를 교체한다.

- 다른 actor에게 인계하기 직전
- 세션을 끝내기 직전
- 한 실행 unit이 끝났을 때
- Verify로 보낼 때와 결과를 받았을 때
- spec/상위 owner로 route가 바뀔 때

Work는 진행 서사를 append하지 않는다. 실패한 시도가 다음 시도를 바꿔야 하면 그 교훈을
`verification.md.what_must_change_before_retry` 또는 현재 `next_action`으로 압축한다. 구현 중 발견한
Product/Architecture/Design 판단은 직접 확정하지 않고 state에 target과 질문을 남겨 route한다.

## 6. Verify가 만드는 것과 반복 방지

Verify는 처음 필요할 때 `verification.md`를 만들고 새 검증 입력마다 최신 결과로 갱신한다. criterion별
증거는 보존하되 무한 시도 일지를 만들지 않는다.

```text
criterion: 잘못된 CSV 행은 유효 행의 저장을 막지 않는다.
status: failed
observed: 세 번째 행 오류에서 transaction 전체가 rollback됨.
evidence: <실행 명령과 관측 좌표>
failure_owner: direct
target_doc: .devflow/work/W012-bulk-import/spec.md
what_must_change_before_retry: 부분 성공이 허용되는지 acceptance를 결정한다.
```

실패 route 표:

| 원인 | 돌아갈 owner | 그 owner가 바꾸는 것 |
|---|---|---|
| 구현이 계약과 다름 | Work | 코드·테스트·구현 접근 |
| acceptance가 모순·불가능·불충분 | Direct | spec |
| 사용자·가치·domain 의미가 잘못됨 | Product | product/domain current truth 뒤 spec |
| 기술 경계·검증 채널이 잘못됨 | Architecture | architecture/domain technical truth 뒤 spec |
| UI 원칙·상호작용 판단이 잘못됨 | Design | design/domain UI truth 뒤 spec |
| 관찰 수단 없음 | Verify가 `unproven` 기록 | 재개 조건이 생길 때까지 멈춤 |

같은 criterion에 `what_must_change_before_retry`가 충족되지 않았으면 Work를 다시 부르지 않는다. 이 한
필드가 retry count보다 “배운 것 없는 반복”을 직접 차단한다.

## 7. Resume이 읽고 반환하는 것

Resume은 다음 알고리즘 이상의 책임을 갖지 않는다.

```text
index 확인
  → active state 파일만 열거
  → 0개: 진행 중 없음 보고
  → 1개: 그 item의 brief/spec과 next pointer 읽기
  → 여러 개: 목록과 각각의 owner/next action을 보여 사용자 선택 대기
  → 선택 item의 blocker·disk/Git 불일치 확인
  → 다음 owner + 행동 하나 + 최소 read set 반환
```

Resume은 모든 문서를 미리 읽거나, 오래된 state를 임의로 고치거나, 다음 skill을 자동 실행하지 않는다.
사용자가 “계속해”라고 요청하면 route된 skill이 자기 gate를 다시 확인하고 실행한다.

## 8. 팀 문서의 경계

```text
work/state.md              공유 의도·현재 phase·next action·검증 요약
team/alice/W012.md         Alice의 worktree, 환경 특이점, 시도 직전 맥락
team/bob/W013.md           Bob의 별도 작업 맥락
```

다음 작업자가 반드시 알아야 하는 사실은 member file에만 둘 수 없다. 인계 checkpoint에서 state나
프로젝트 정본으로 옮긴다. member file은 handoff pointer가 있을 때만 읽고 closure 때 work와 함께
삭제한다. 개인 취향·영구 노트 저장소는 Devflow의 책임이 아니다.

## 9. Adopt 전후의 지식 변화

```mermaid
flowchart LR
    X[외부 코드·주석·문서·테스트] --> I[일시 source inventory]
    I --> F[관측 사실]
    I --> N[해석·불확실성]
    I --> C[모순]
    F --> K[.devflow/project 현재 정본]
    N --> K
    C --> O[semantic owner 결정]
    O --> K
    K --> Z[adoption 폴더 삭제]
    X -. 삭제·이동돼도 .-> Y[정본 이해에 영향 없음]
    K --> Y
```

외부 자료의 경로·줄 번호는 Adopt 과정에서 coverage 증거로 쓸 수 있지만 완료된 프로젝트 지식이 그
좌표에 의존하면 Adopt가 끝난 것이 아니다. live code/test/runtime evidence는 현재 구현 확인에 다시
볼 수 있으나, “프로젝트가 왜 이렇고 무엇을 뜻하는가”는 내부 정본이 자기완결적으로 말해야 한다.

## 10. 현재와 과거가 섞이지 않는 규칙

1. 같은 개념이 바뀌면 같은 canonical home을 교체한다.
2. 과거 판본·완료된 work·완료된 sketch는 Git이 보존하며 현재 트리에 archive하지 않는다.
3. 기각 이유가 현재 결정을 지키는 경우에만 decision에 현재형으로 남긴다.
4. 진행 로그를 domain/product/architecture에 승격하지 않는다.
5. 외부 원자료를 현재 정본의 필수 링크로 남기지 않는다.

이 규칙으로 `.devflow/`는 많은 역사를 가진 프로젝트에서도 “지금 무엇이 참인가”를 먼저 보여 주고,
필요할 때만 Git으로 과거를 조사하게 된다.
