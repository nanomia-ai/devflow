---
title: Incremental delivery and validation plan
status: inversion-reviewed-final-plan
purpose: Sequence implementation so the cheapest discriminating observation precedes each new layer of complexity.
read_when: Read before implementing, approving a phase, or claiming a phase complete.
canonical_for: Proposed phase order, gates, falsifiers, and stop rules.
tags: [devflow-vnext, delivery, validation, skill-rails]
---

# 점진 구현·검증 계획

## 1. 실행 계약

각 phase는 하나의 중요한 주장을 공격한다. 파일 생성, build 성공, schema 통과는 delivery evidence일
뿐이다.

| 증거 | 답하는 질문 |
|---|---|
| delivery | canonical source에서 같은 artifact를 결정적으로 만들 수 있는가 |
| behavior | fresh AI가 필요한 owner를 찾고 안전한 다음 행동을 하는가 |
| effect | 실제 변경·인계·검증·지식 승격에서 사람의 부담과 실패가 줄었는가 |

결과는 `proven`, `failed`, `unproven`으로 기록한다. 실행하지 못한 검증을 pass로 쓰지 않는다.
Target 하나를 build하고 fresh-use로 관찰하기 전 다음 target을 구현하지 않는다.

## 2. Phase 0 — 승인 후 housekeeping

레거시를 `legacy/v0.25.1/`로 이동하는 일은 필요하지만 설계 검증의 gate가 아니다. 소유자 승인 뒤
tracked/untracked, cache와 source 차이, 이동 전후 파일 목록·hash, Git recovery path를 확인해 별도
변경으로 수행한다. 새 source/build/test 경로는 legacy를 import하거나 fallback으로 사용하지 않는다.
이 계획 단계에서는 이동하지 않는다.

## 3. Phase 1 — keyed document-system pilot

### 공격할 주장

수동 `docs/README.md`, Product, Architecture, 두 domain tree, ADR, 작은 work state만으로 fresh AI가
전체를 읽지 않고 owner 문서와 다음 행동을 고를 수 있다.

### fixture와 answer key

중개노트 원본은 수정하지 않는다. 별도 fixture에 두 domain과 실제 경계 난점을 대표하는 10~12개
문서만 재구성한다. 작성 전에 질문별로 다음 answer key를 만든다.

- 반드시 읽어야 할 owner 문서
- 읽지 않아야 할 무관 문서
- 허용 가능한 읽기 비용
- 올바른 next action

추가 read는 자동 실패가 아니라 원인 분석 신호다. 정답에 도달한 다른 유효 경로를 exact-set 차이만으로
실패 처리하지 않는다. 한 시간 이내 syntax pre-check로 `summary/read_when`과 Domain README 우선 읽기만
확인하며, 범용 schema·renderer는 만들지 않는다.

### 통과 신호

- owner 문서와 next action이 맞다.
- 조건부 depth는 relevance가 있을 때만 열린다.
- 무관한 Product/Architecture/domain 전체를 관성적으로 읽지 않는다.
- 문서 구조, header, entry 중 실패 owner를 분리할 수 있다.

## 4. Phase 2 — Resume target 하나

새 Skill Rails source package와 `resume` prose target 하나만 만든다. 가장 작은 완전한 entry source를
build하고 generated diff·receipt를 검토한다. Phase gate에서 deterministic delivery, integrity,
currentness를 확인한다.

Standalone target을 fresh Claude/Codex session에 주고 status·continue 질문을 관찰한다. Resume은
Domain 설명이나 배치 결정을 대신하지 않고 active state와 다음 owner 하나만 반환해야 한다. Build
receipt는 behavior pass가 아니다.

## 5. Phase 3 — Direct target

Direct만 추가해 같은 요청을 두 경로로 분류한다.

```text
quick   → current-turn quick contract
tracked → work/<id>/spec.md + 초기 state.md
```

Spec은 goal, non-goal, acceptance, affected owners, read-first, units를 담는다. 사용자 승인은 모든 spec이
아니라 제품 의미, 불가역 변경, 권한 밖 결정처럼 실제 binding choice에만 요구한다. Blocking unknown은
아직 Sketch target 없이 “exploration needed”로 안전하게 멈추는지만 본다.

## 6. Phase 4 — Work target과 중단 복구

Work의 유효 입력은 `durable spec | current-turn quick contract`다. Quick은 같은 turn에서 구현하고
비례 검증한 뒤 durable folder 없이 끝낸다. Tracked work는 한 unit을 구현하고 `state.md`를 갱신한다.

Work 전, commit 후 Verify 전, verification 준비 중에 session을 끊고 Resume으로 재개한다. Git은 실제
bytes·revision, state는 intent·acceptance·next action을 소유한다. base/write scope/acceptance 충돌만
구현을 막고 다른 불일치는 관할별로 조정한다.

## 7. Phase 5 — Verify와 knowledge landing closure

Verify target을 별도로 build하고 독립 fresh-use를 본다. Verify는 code를 수정하지 않고 criterion별
`proven|failed|unproven`, evidence, failure owner, retry 전에 달라져야 할 조건을 남긴다.

Pass 경로:

```text
Verify → promotion candidates와 promotion_pending 기록
       → Work가 기존 규칙 아래 확인된 구현 사실을 반영
       → 새 의미 판단은 Product | Architecture | Design으로 전달
       → promotion_pending이 비면 Work와 member work files 삭제
```

같은 실패 재시도에는 달라진 가설·입력·구현·검증법이 필요하다. 서로 다른 작업에서 같은 이유로
promotion 누락이 반복될 때만 별도 closure skill을 제안한다. 한 번의 누락으로 전역 skill을 만들지
않는다. 장기 cross-domain use-case 계약이 필요한 사례에서는 `docs/specs/<topic>.md` 승격도 시험한다.

## 8. Phase 6 — Product → Architecture → optional Design

각 target을 순서대로 하나씩 build·관찰한다.

1. 명확한 brief → Product
2. Product를 입력으로 Architecture
3. backend-only brief → Design 생략
4. UI project → Design

Product는 프로젝트 목적·사용자·cross-domain 구도를, Domain README는 domain 고유 의미·경계·불변식을
소유한다. Architecture는 기술·검증 채널을, Design은 UI 원칙을 소유한다. 같은 사실이 두 문서에
복제되면 phase를 멈춘다.

## 9. Phase 7 — Sketch target

`sketch`는 project/change scope를 함께 다루고 checkpoint와 finding destination만 보존한다. 특정 질문법,
시장 분석 절차, 사고 순서를 강제하지 않는다.

관찰:

- 모호한 신규 idea가 Product로 이어지는가
- uncertain change가 Direct로 필요한 결정만 반환하는가
- 중단된 sketch가 transcript 없이 재개되는가
- project sketch를 일반 work shape로 합치는 편이 더 단순한지

Sketch가 독립 skill 없이 Direct/Product 안에서 동일하게 checkpoint된다면 통합을 재검토하되, 사용자가
명시한 독립 탐구 경험을 잃지 않는지 먼저 본다.

## 10. Phase 8 — Adopt vertical slice와 target

Adopt 문서 prototype을 먼저 작은 brownfield fixture에서 시험한 뒤 target 하나를 build한다.

성공 조건:

- maintained source가 disposition 없이 사라지지 않는다.
- observed fact, interpretation, unknown, conflict가 구분된다.
- Product/Architecture/Domain owner가 겹치지 않는다.
- 모르는 내용을 문서 완성을 위해 발명하지 않는다.
- `reconstructed`는 관찰 사실 자체가 아니라 그 의미 해석이 잠정임을 나타낸다.
- 사람에게는 source로 결정할 수 없는 경계·모순만 묻는다.
- adoption scratch의 모든 source group이 `landed | resolved | unresolved:<owner>`가 된 뒤에만 삭제된다.

원본 중개노트에는 어떤 변경도 하지 않는다.

## 11. Phase 9 — 팀 handoff

Agent A가 공유 사실을 `state.md`, 개인 환경·중간 추론을 `team/A/W001.md`에 둔다. 이동 checkpoint는
handoff, session 종료, branch 전환, verification 결과 발생 때다. 매 turn마다 기록하지 않는다.

의도적으로 공유 사실 하나를 member file에만 남기고 Agent B가 이를 사실로 실행하지 않는지 본다.
Closure 뒤 W001 member file이 삭제되는지, identity protocol·room·claim 없이 worktree가 다른 agent도
재개하는지 검증한다.

## 12. Phase 10 — index 기계화의 조건부 도입

다음 중 하나가 관찰될 때만 작은 checker/generator를 검토한다.

- maintained doc이 README에서 빠짐
- dangling link가 남음
- 동일 질문에서 잘못된 `read_when`이 반복됨
- 같은 routing 정보를 둘 이상의 index에 중복 작성함

도입하더라도 title, summary, read_when, status와 파일 존재만 결정적으로 검사한다. 의미 owner,
Domain 경계, 좋은 summary를 script가 판단하지 않는다.

## 13. Phase 11 — npm·host adapter와 SessionStart

핵심 behavior가 명시 호출과 프로젝트 문서만으로 통과한 뒤 설치를 검증한다.

```text
plugin.json                         # portable identity + extensions.com.openai
.claude-plugin/plugin.json         # Claude 공식 adapter
skills/                             # Skill Rails built targets
hooks/hooks.json                    # host adapter가 실제 지원할 때
scripts/session-start.*             # marker check + 짧은 Resume pointer
```

프로젝트 AGENTS/CLAUDE pointer는 정적 routing을 맡고, hook은 marker 존재와 현재 continuation만 알리는
동적 보조다. 같은 규칙을 두 곳에 복제하지 않는다. Hook을 제거해도 skill gate와 문서 routing이
작동해야 한다. `.codex-plugin`은 실제 요구 host version이 확인될 때만 fallback으로 추가한다.

같은 npm artifact를 두 marketplace source로 설치하고 clean session, update, uninstall, hook on/off를
비교한다. Hook이 effect를 개선하지 않으면 v1 package에서 빼되 공식 지원 경로는 문서화한다.

## 14. Skill Rails regrowth guard

Skill Rails의 현재 계약을 그대로 따르되 숫자 자체를 새 규칙으로 만들지 않는다.

- 판단 중심 skill은 prose target을 우선한다.
- 실제 공유되는 안정 규칙은 하나의 canonical module owner를 가진다.
- module open condition은 현재 입력으로 판별 가능해야 한다.
- authoring CLI와 build runtime을 project workflow에 복제하지 않는다.
- receipt는 delivery evidence이며 behavior/effect pass criterion이 아니다.
- module·script·field가 반복 사용 실패를 해결하지 않고 ceremony만 늘리면 확장을 멈춘다.

첫 targets에서 authoring과 build 비용을 측정하되 임의 비율을 자동 gate로 쓰지 않는다. 비용이 문서·
행동 실험을 잠식하면 evidence와 함께 사용자에게 완화 결정을 요청한다.

## 15. 최초 fresh-agent 관찰

1. unmanaged repo에서 Work가 쓰기 전에 거절하는가
2. backend-only project가 Design을 만들지 않는가
3. Domain 질문에서 README → 관련 depth만 읽는가
4. 중단된 work를 transcript 없이 재개하는가
5. spec 결함을 Work 반복이 아니라 Direct로 돌리는가
6. 관찰 불가 criterion을 pass가 아니라 unproven으로 닫는가
7. member context의 공유 사실을 state보다 우선하지 않는가
8. closure가 progress narrative를 정본에 넣지 않는가
9. plugin과 hook이 없어도 AGENTS/CLAUDE pointer와 docs로 안전하게 축소 동작하는가

관찰을 통과했다고 시나리오를 무한히 추가하지 않는다. 새 시나리오는 기존 결정을 실제로 바꾸는
실패가 있을 때만 추가한다.
