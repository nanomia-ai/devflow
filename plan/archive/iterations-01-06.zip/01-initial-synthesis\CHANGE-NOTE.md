---
title: Initial synthesis change note
status: frozen
purpose: State what this first closed baseline represents and what had not yet been challenged.
read_when: Read before comparing the initial synthesis with later iterations.
canonical_for: The boundary and evidence state of iteration 01.
tags: [devflow-vnext, planning, iteration-01]
---

# 01 — 최초 종합안

## 포함한 근거

- 사용자가 설명한 실패 장면과 원하는 실제 사용성
- 레거시 Devflow v0.25.1의 구조·배포·상태·문서 관찰
- 중개노트의 문서 라우팅·Product·Architecture·Domain·ADR·handoff 성공 사례
- Claude/Codex의 공식 plugin, npm, skill, SessionStart 문서
- 여러 독립 subagent의 레거시·성공 사례·호스트·아키텍처 분석
- Skill Rails의 최소 source graph, standalone target, delivery/effect 증거 분리 원칙

## 핵심 제안

- 9개 스킬: sketch, product, architecture, design, adopt, direct, work, verify, resume
- 공개 principles와 별도 domain 스킬을 두지 않음
- domain 중심 조건부 문서 트리와 owner별 지식 승격
- manifest는 lifecycle gate만 소유하고 workflow 상태를 소유하지 않음
- 문서 시스템 fixture와 read-only Resume를 첫 수직 pilot으로 사용
- npm 공통 본체 + 얇은 Claude/OpenAI adapter, hook은 선택적 pointer

## 아직 하지 않은 검증

이 반복은 Fable의 독자 설계를 보기 전에 동결했다. 따라서 위 스킬 집합·문서 트리·첫 pilot 순서가
최선이라는 주장은 아직 반증되지 않았다. AI 행동과 실제 사용자 효과도 모두 `unproven`이다.

