---
title: Final planning decision ledger
status: final-reviewed-current-plan
purpose: Preserve decided, provisional, rejected, and corrected claims after independent design, debate, and inversion.
read_when: Read when challenging the architecture or deciding whether new evidence justifies a change.
canonical_for: Planning decisions and their falsifiers, not runtime state.
tags: [devflow-vnext, decisions, evidence, inversion]
---

# 최종 기획 결정 원장

## 1. 검증 과정

1. 레거시 실패, 중개노트 성공 사례, 새 Skill Rails, 공식 Claude/Codex 배포 근거를 독립 조사했다.
2. Coordinator가 최초 종합안을 만들고 `01-initial-synthesis`로 동결했다.
3. 페이블은 그 안을 보지 않고 독립 구조를 먼저 만들었다.
4. 두 안의 전제·사람 사용·AI 사용·지식 결과·가장 값싼 반증을 비교했다.
5. Skill Rails, 팀 폴더, fixture 순서를 두고 상호 반론한 뒤 `02-reconciled`로 동결했다.
6. 02의 모든 전제를 제거하는 역발상 검증과 별도 아키텍처 검토를 다시 수행했다.
7. 더 단순하다는 이유만으로 사용자의 명시 요구를 제거하지 않고, 증거 전 추가된 장치만 걷어냈다.
8. 사용자가 외부 정본 의존과 산출물 수명 공백을 지적한 뒤, 유효 결정 DD-77·98·103·104·108을
   원문 대조하고 이전 최종안을 보존한 채 내부 정본·owner·artifact lifecycle을 다시 수렴했다.
9. 이 교정안을 `04-internal-canon-and-lifecycle`로 동결했다.
10. 동일 Fable high session은 수정안을 보기 전에 교정 의도만으로 독립 내부 구조를 다시 만든 뒤 04와
    비교했고, 별도 Architecture agent는 사용자/AI 동선·소실·중복을 원문 좌표로 감사했다.
11. 두 검토가 수렴한 phase enum·index orientation·상태 중복·handoff pointer 문제를 고쳤고, 서로 다른
    결론(Sketch/Adopt 통합, reconstructed doc marker)은 사용자 의도와 stale-risk를 기준으로 따로 판정했다.
12. 사용자의 병렬·중단·문서 완성도 보완 뒤 같은 Fable high 세션과 같은 Architecture agent를 재사용해
    전체를 다시 역검증했다. 두 검토가 함께 지적한 state 중복, Git 병렬성, index hot spot, Direct/Verify
    checkpoint, Resume checkout 경계, Adopt gate를 루트 현재안에 반영했다.

페이블 세션은 독립안부터 최종 역발상까지 같은 세션을 사용했고 마지막에도 컨텍스트가 약 27%였다.
따라서 사용자가 요구한 초기 이해 비용 재사용과 70% 교체 기준을 지켰다.

## 2. 최종 채택한 결정

1. 프로젝트 정본과 Devflow가 만드는 모든 문서는 `.devflow/` 한 루트가 소유한다.
2. `.devflow/index.md`가 관리 표식과 최상위 routing을 겸한다. 전역 lifecycle·queue·current agent는
   넣지 않고 readiness는 Product·Architecture와 active state에서 파생한다.
3. 공개 skill은 아홉 개다: `sketch`, `product`, `architecture`, `design`, `adopt`, `direct`, `work`,
   `verify`, `resume`.
4. 공개 `principles`, `domain`, `land` skill은 만들지 않는다.
5. Resume은 status/resume 전용이다. Domain 설명은 내부 project routing, 배치는 Architecture가 맡는다.
6. Sketch는 project/change 탐구를 함께 다루되 특정 사고법을 강제하지 않는다.
7. Product는 프로젝트 목적·사용자·cross-domain 구도, Domain README는 domain 고유 의미·경계·불변식,
   Architecture/Design은 각 기술·UI 관점을 소유한다.
8. Quick lane은 `Direct quick contract → Work 구현·비례 검증`이며 durable work와 독립 Verify가 없다.
9. Tracked lane은 `Direct → Work → Verify → canonical-home landing → Work closure`다.
10. Verify는 code를 고치지 않고 failure route, target document, retry 전 달라져야 할 조건을 분리한다.
11. 같은 criterion 재시도에는 다른 가설·입력·구현·검증법이 필요하다.
12. Spec이 공유 의도·acceptance·write boundary를, state가 last safe point·next action을, Git이 실제
    bytes·revision을 소유한다.
13. team member file은 모든 active artifact의 개인 맥락만 가지며 공유 사실은 checkpoint에서 state로 이동한다.
14. 현재 project 문서 header는 `summary`, `read_when`만 필수다. 폐기 문서는 남겨 status를 붙이지 않고
    현재 자리에서 고치거나 삭제하며 Git이 과거를 맡는다.
15. `.devflow/index.md`가 유일한 최상위 수동 routing index이고 하위 index는 자기 subtree만 소유한다.
16. 완료된 change spec은 장기 canon으로 남기지 않는다. Cross-domain 계약은 Product/Domain/Architecture/
    decision의 현재 질문별 home으로 분해한다.
17. Skill Rails는 canonical source와 standalone target을 만드는 저작·배포 경계다. Runtime project
   decision/state engine으로 사용하지 않는다.
18. Skill Rails source package가 index bootstrap template을 소유하고, 생성된 project document law는
   `.devflow/index.md`가 operational owner다. 한 writer 계약은 entry, 여러 writer 계약만 조건부 module에 둔다.
19. Project AGENTS/CLAUDE pointer가 정적 routing을 맡고 SessionStart hook은 동적 보조일 뿐이다.
20. npm package는 portable root `plugin.json`, Claude adapter, 공통 skill artifacts를 담는다.
21. `.codex-plugin` fallback은 실제 요구 host version이 확인되기 전에는 배포하지 않는다.
22. 레거시 이동은 승인 후 housekeeping이며 구현 검증 gate나 migration이 아니다. 실제 구버전 운영
    프로젝트가 없으므로 상태·파일·API compatibility path를 만들지 않는다.
23. owner는 사람·agent·skill·lock이 아니라 현재 진실이 사는 한 canonical home이다.
24. owner 자체는 이동하지 않는다. 열린 finding·결함·결론은 질문 유형에 맞는 decision route로 가고,
    결정된 사실은 current actor가 canonical home에 쓴다.
25. 모든 transient state는 phase enum 없이 `next_route`, `next_action`, `blockers`를 가진다. Sketch는
    unresolved findings, Work만 base revision·last safe point·candidate·pending landing을 필요할 때 추가한다.
    전역 lifecycle도 artifact state machine도 만들지 않는다.
26. spec의 준비·진행·완료는 work 폴더 존재, blocker, next route/action, pending landing에서 파생하고
    완료 뒤 임시 work와 member 파일을 삭제한다.
27. Adopt 원자료 좌표는 일시 coverage 증거다. 최종 내부 정본은 자기완결적이고 외부 문서 삭제에
    영향을 받지 않아야 한다.
28. 루트 AGENTS/CLAUDE 및 hook은 `.devflow/index.md` 발견을 위한 연결부이며 지식을 소유하지 않는다.
29. 최초 bootstrap skill이 index를 만들고 질문→문서 route가 실제로 바뀔 때만 변경 actor가 부모 route를
    갱신한다. Active artifact는 index에 나열하지 않으며 Resume은 index를 쓰지 않는다.
30. Verification verdict는 `verification.md` 한 곳만 소유한다. Verify는 완결 snapshot과 state route를
    한 checkpoint 변경으로 publish하고 임시 파일은 current로 읽지 않는다.
31. Adopt coverage는 명시 include/exclude partition의 uncovered path 0과 별도 의미 시나리오로 판정한다.
32. 보존 외부 문서는 검색면 밖 이동·최소 pointer·명시적 비정본 경계 없이 완료 disposition이 될 수 없다.
33. Plugin 없는 session도 재개할 수 있도록 bounded orientation 절차는 `.devflow/index.md`가 소유하고
    Resume skill은 그 절차를 여는 읽기 전용 door다.
34. Work state가 구현 중 knowledge candidates를 보존하고 Verify가 verification에 증거 기반 후보를
    추가한다. Work closure가 후보를 채택·기각해 열린 질문은 blocker+route, 확인 사실은 fact→path
    pending landing으로 바꾼다.
35. Team member file은 state pointer 없이 선택 artifact ID의 `team/*/<artifact-id>.md` glob으로 찾는다.
36. 문서 전체 `reconstructed` marker는 두지 않는다. 불확실성은 해당 문장 옆의 근거·미지·확인 조건이
    소유해 부분 확인이 문서 전체를 검증한 것처럼 보이지 않게 한다.
37. Artifact ID는 순차 번호나 중앙 발급기 없이 충돌하기 어려운 불투명 token을 기계적으로 만들고
    현재 tree 충돌도 확인한다.
38. 하나의 active artifact state는 한 시점에 한 actor만 쓴다. 병렬 작업은 별도 artifact와 안정적인
    seam을 우선하되 코드·정본 write scope 중첩은 금지하지 않는다. 상충 fact는 Git/PR에서 명시적
    merge·decision 사건으로 드러낸다.
39. 어느 stage든 관리권이 바뀌기 전에 현재 행동을 완결하지 못하면 소유 state를 최신 스냅숏으로
    만든다. Product·Architecture·Design은 장기 판단 중 Sketch를 checkpoint로 사용한다.
40. 모든 Devflow Markdown의 최소 header는 `summary/read_when`이고, 각 본문은 한 독자 질문·자기완결
    배경과 의도·현재형 정보·증거/해석 분리를 지킨다. 세부 절은 문서 목적에 맞게 적응한다.
41. Skill target entry는 배경·의도, 목적, trigger/비범위, gate, 입력, 소유 출력, 완료 증거, 다음 route,
    금지 책임을 가진 가장 작은 독립 계약이다. Checker는 기계적 형식만 판정한다.
42. Project document law는 bootstrap template이 `.devflow/index.md`에 심고 그 instance가 plugin 없는
    actor까지 포함한 operational owner가 된다. 한 writer 계약은 entry, 여러 writer 계약만 module에 둔다.
43. `adoption/`이 존재하는 동안 일반 Direct/Work를 막는다. Coverage-scoped 부분 허용은 큰 프로젝트
    관찰이 전체 gate를 뒤집을 때만 추가한다.
44. Resume은 현재 checkout만 보며 다른 branch/worktree 집계는 Git·외부 orchestrator 책임이다. Active
    artifact가 없는 dirty changes는 unowned work로 보고한다.
45. Contract/spec, state, verification, team, Adopt source/conflict는 같은 사실을 복제하지 않는다. Team은
    local delta·환경·개인 가설만, state는 last safe point와 route만 소유한다.
46. 통합 review가 있다면 transient artifact 삭제 전에 goal·acceptance·verification 요약을 PR 또는
    commit body에 남긴다. 이는 정본이 아니라 review evidence다.

## 3. 구현 관찰로만 바꿀 잠정 결정

| 현재 기본안 | 뒤집을 관찰 |
|---|---|
| 별도 Land 없이 canonical-home landing/Work closure | 서로 다른 작업에서 같은 이유로 durable fact 승격이 반복 누락됨 |
| 독립 Sketch skill | Direct/Product decision work만으로 project/change checkpoint가 항상 자연스럽게 생성·소비됨 |
| 독립 Resume skill | plugin 없이 project pointer만으로 중단 작업 상태·next route를 항상 정확히 복구함 |
| member namespace `team/<member>/<work>.md` | colocated per-work member file이 사용자의 팀원별 공간 의도를 더 잘 만족하고 찾기 비용도 낮음 |
| YAML `summary/read_when` header | prose lede가 두 host에서 같은 relevance 선택률을 보임 |
| 별도 work `spec/state/verification` | 실제 읽기·merge 비용이 분리 이점보다 큼 |
| `.devflow/project/domains/` | 단일-folder project에서 다른 내부 분할이 반복 misread를 줄임 |
| 수동 README | missing doc, dangling link, 반복 misroute가 실제로 발생함 |
| SessionStart adapter 지원 | project pointer만으로 충분하고 hook on/off가 effect 차이를 만들지 않음 |
| Sketch/Adoption/Work의 서로 다른 transient folder | 같은 spec/state shape가 project/change 탐구와 source coverage를 정보 손실 없이 더 적은 read/cleanup 비용으로 처리함 |

잠정은 더 많은 기능을 미리 구현한다는 뜻이 아니다. 현재 더 작은 기본안을 사용하고 관찰이 그것을
뒤집을 때만 구조를 늘린다.

## 4. 거부한 구조

- 레거시 baseline·fallback·compatibility layer
- 선언형 lifecycle, global currentStage, queue, retry count, agent session DB
- 별도 Land skill을 증거 전에 추가하는 것
- generic one-skill entry와 Resume super-router
- per-skill vendored runtime과 runtime Decision engine
- 모든 target이 매번 읽는 장문의 shared principles
- capability 번호, 전역 glossary, capsule, coordinate grammar
- journal, freshness hash, claim, room, join/leave protocol
- team index나 handoff에 shared state를 복제하는 것
- 영구 personal notes 저장소에 승격·폐기 경로 없이 지식을 쌓는 것
- fixed retry count만으로 loop를 끊는 것
- 모든 spec에 사용자 승인을 요구하는 것
- exact read set 차이를 곧바로 실패로 판정하는 것
- Sketch에 Socratic/Dewey 같은 사고 절차를 강제하는 것
- 임의의 줄 수, import 수, 파일 수, 시간 비율을 보편 규칙으로 만드는 것
- 첫날부터 index generator·schema framework를 만드는 것
- build receipt로 AI behavior/effect를 증명했다고 간주하는 것
- hook이 없으면 작동하지 않는 구조
- 모든 transient spec을 무조건 삭제하거나 모두 영구 보존하는 것
- 외부 `docs/`를 Devflow 정본으로 두거나 Adopt 입력 경로를 영구 provenance로 요구하는 것
- 완료된 sketch/work/adoption을 현재 트리의 archive·묘비로 누적하는 것
- 완료 change spec을 `project/specs/`라는 장기 canon으로 승격하는 것
- state에서 member file을 가리키는 handoff pointer
- folder 내용에서 파생 가능한 artifact phase enum
- 문서 전체에 붙는 거친 `reconstructed` status

## 5. 중요한 교정

- 02는 `land`를 확정 skill인 동시에 잠정이라고 적었다. 최종안은 별도 skill을 제거하고 반복 누락이
  관찰될 때만 재도입한다.
- 02의 marker는 lifecycle과 verify channel을 중복 소유했다. 최종안은 상태를 파일에서 파생하고
  verify channel은 Architecture 한 곳에 둔다.
- 02의 Product와 Domain이 경계를 중복 소유했다. 최종안은 cross-domain 구도와 domain 고유 경계를
  분리했다.
- 02는 Git을 state보다 항상 우선시했다. 최종안은 bytes/revision과 intent/next action의 관할을 나눴다.
- 02 이후의 안은 장기 spec folder를 허용했지만, 완료 당시 문맥이 현재 규칙처럼 남는 위험이 더 컸다.
  최종안은 모든 완료 work를 삭제하고 durable fact만 기존 project home으로 분해한다.
- 02의 Skill Rails 숫자 제한은 관찰 근거가 없었다. 최종안은 current Skill Rails 계약과 질적 regrowth
  신호를 사용한다.
- 페이블의 최종 7-skill 대안은 lifecycle/Land 제거와 단일 transient shape에서 유익했지만, 사용자가
  명시한 Sketch·Resume과 팀원별 namespace까지 제거하므로 채택하지 않았다.
- 03은 중개노트의 성공 원리와 물리 경로를 혼동해 `docs/`를 정본으로 두었다. 이는 삭제 가능한 외부
  입력 의존성과 현재/과거 혼재를 만들고 DD-98·108에도 어긋났다. 04는 성공 원리만 가져와 전부
  `.devflow/` 내부로 흡수한다.
- 03의 “owner landing”은 owner를 사람·stage·파일 중 무엇으로 쓰는지 모호했다. 04에서 네 개념을
  분리했고, 최종안은 더 줄여 owner를 canonical home으로만 사용한다. Skill은 열린 질문의 decision route다.
- 04의 Sketch 4개·Adopt 5개·Work 7개 phase는 folder 내용과 verification verdict를 다시 표현했다. 최종안은
  next route/action, blockers, pending landings만 남기고 상태를 파생한다.
- 04의 장기 `project/specs/`는 완료 당시 문맥이 현재 규칙처럼 남는 경로라 제거했다. Durable fact는
  Product/Domain/Architecture/decision의 기존 home으로 분해한다.
- Fable은 Sketch·Adopt까지 하나의 work shape로 합치자고 제안했으나, 사용자가 요구한 리서치 finding과
  source coverage가 서로 다른 읽기·변경 이유를 가진다. 최종안은 별도 수명을 유지하고 Phase 7~8에서
  실제 read/cleanup 비용이 통합을 지지할 때만 뒤집는다.

## 6. 잔여 미검증

- 실제 Skill Rails authoring 비용과 generated support files의 AI noise
- project pointer와 SessionStart hook의 effect 차이
- 팀원별 namespace가 장기적으로 stale room이 되지 않는지
- canonical-home landing이 별도 Land 없이 반복 누락되지 않는지
- `summary/read_when`이 수개월 수동 편집 뒤에도 정확한지
- Adopt가 큰 brownfield에서도 질문 수와 invention을 억제하는지
- 약한 모델과 비설치 팀원도 같은 internal project/work 계약으로 안전하게 축소 동작하는지
- 완료된 Adopt 뒤 외부 입력 문서가 삭제되어도 같은 이해와 routing이 유지되는지

이 항목은 문서로 더 서술해 해결하지 않는다. [04-delivery-and-validation.md](04-delivery-and-validation.md)의
가장 작은 관찰에서 측정한다.
