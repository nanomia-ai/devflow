---
title: Document contracts and authoring boundaries
status: final-reviewed-current-plan
purpose: Define what each Devflow document must help a human or AI decide, without turning prose into a rigid schema.
read_when: Read when designing a writer skill, creating a fixture, or reviewing whether a document is complete and usable.
canonical_for: Proposed document purposes, minimum headers, body contracts, and Skill Rails authoring structure.
tags: [devflow-vnext, documents, templates, skill-rails, ai-usability]
---

# 문서 계약과 작성 경계

## 1. 문서를 만드는 이유

Devflow 문서는 활동을 증명하기 위한 기록이 아니다. 다음 사람이나 AI가 과거 대화를 재구성하지 않고
현재 질문을 판단하거나 다음 행동을 안전하게 시작하게 하는 지식 인터페이스다. 따라서 각 문서는
**한 가지 독자 질문**에 답하고, 그 질문에 필요 없는 과정·대화·다른 문서의 내용을 복제하지 않는다.

```mermaid
flowchart LR
  I[index: 어디를 읽는가] --> C[project: 지금 무엇이 참인가]
  I --> T[temporary: 지금 무엇을 결정·실행하는가]
  T --> H[team: 이 actor가 어디서 넘기는가]
  T -->|검증·판단 후| C
  T -->|종료| G[Git: 과거 과정]
```

## 2. 모든 문서의 공통 계약

1. **질문 하나:** 문서 제목과 첫 문단만으로 이 문서가 답하는 질문을 말할 수 있어야 한다.
2. **자기완결:** 판단에 필수인 배경·의도·제약은 본문에 쓴다. 외부 issue나 Adopt 원문은 출처 표지일
   뿐 현재 의미의 필수 의존성이 아니다.
3. **현재형:** 현재 유효한 사실·결정·상태만 남긴다. 활동 일지와 이전 판본은 Git이 보존한다.
4. **한 소유 경로:** 같은 사실을 여러 문서에 요약하지 않는다. 다른 질문은 링크와 `read_when`으로
   보낸다.
5. **증거와 해석 분리:** 관측 사실, 해석, 미확정 사항, 확인 조건이 섞이지 않게 쓴다.
6. **적응형 본문:** 아래 절은 반드시 전달해야 할 정보 계약이다. 해당 정보가 없으면 빈 절을 만들지
   않고, 프로젝트 언어에 더 자연스러운 제목으로 바꿀 수 있다.
7. **짧은 방향 표지:** AI가 전체 본문을 열기 전에 관련성을 판단할 수 있도록 Devflow가 만든 Markdown은
   다음 최소 header를 갖는다. `id`, `owner`, 날짜, tags, `status: current`는 기본 필드가 아니다.

```yaml
---
summary: 이 문서가 현재 답하는 질문과 결론을 한두 문장으로 설명한다.
read_when:
  - 이 문서를 열어야 하는 구체적 질문이나 조건
---
```

`index.md`는 항상 읽는 문서이므로 `read_when`에 그 사실을 쓸 수 있다. State처럼 기계 판독이 필요한
작업 좌표는 header가 아니라 그 문서가 소유하는 현재 스냅숏 블록에 둔다.

## 3. 장기 현재 지식의 본문 계약

| 문서 | 답해야 하는 질문 | 본문에 필요한 정보 |
|---|---|---|
| `.devflow/index.md` | 지금 어떤 질문이면 어디부터 읽는가 | 프로젝트 한 줄 설명, foundation 경로와 readiness 파생 규칙, 질문→정본 route, active artifact를 찾는 유계 glob, Resume orientation 절차, project document law, 비정본 경계 |
| `project/product.md` | 누구의 어떤 문제를 어떤 경계 안에서 해결하는가 | 문제·사용자/역할·가치, 제품 경계와 비범위, 핵심 언어, cross-domain 구도, 제품 불변식, 열린 제품 질문 |
| `project/architecture.md` | 시스템을 어떤 기술 경계와 방향으로 구성하는가 | 환경·구성요소, 배치와 의존 방향, runtime/data 흐름, 공개 seam, 검증 채널, Design applicability, concern tree route, 열린 기술 질문 |
| `project/architecture/<concern>.md` | 특정 기술 concern에서 무엇이 현재 규칙인가 | 적용 조건, 결정된 구조·계약, 근거와 trade-off, 실패/운영 경계, 관련 domain·검증, 부모 route |
| `project/design.md` | UI가 있을 때 어떤 경험 원칙과 체계를 따르는가 | 사용자 경험 원칙, foundation/token/component/interaction 전략, 접근성·반응형·상태 원칙, 상세 tree route, review surface |
| `project/design/<concern>.md` | 특정 UI concern을 언제 어떻게 판단하는가 | 적용 조건, 현재 패턴·제약, 상태/변형, 접근성·검토 기준, 관련 domain과 부모 route |
| `project/domains/<domain>/index.md` | 이 domain은 무엇을 소유하고 어디까지인가 | 목적·경계, 핵심 용어, 상태·규칙·불변식, 다른 domain과의 계약, 하위 문서 route, 열린 질문 |
| domain 상세 문서 | 한 domain concern의 현재 지식은 무엇인가 | concern의 범위, 현재 규칙·예외, 입력/출력 또는 상태 변화, 근거·검증, 관련 계약과 부모 route |
| `project/decisions/<id>-<slug>.md` | 현재 결정을 지키는 이유와 재검토 조건은 무엇인가 | 결정 질문, 현재 결론, 맥락·제약, 고려한 대안과 기각 이유, 영향, 재검토 조건, 반영된 canonical home |

Decision 문서는 규칙 사본이 아니다. 현재 규칙은 Product·Architecture·Design·Domain에 있고, Decision은
그 방향이 아직 유효한 이유만 소유한다. 같은 결정 질문의 결론이 바뀌면 같은 파일을 교체하며 과거는
Git에서 본다.

## 4. Sketch 문서 계약

| 문서 | 답해야 하는 질문 | 본문 계약 |
|---|---|---|
| `brief.md` | 왜 무엇을 탐구하는가 | project/change scope, 지배 질문, 배경과 의도, 이미 아는 사실, 비범위, 결정 기준 |
| `state.md` | 지금 무엇이 미해결이며 다음 행동은 무엇인가 | `next_route`, `next_action`, `blockers`, unresolved finding 목록과 각 destination |
| `findings/<concern>.md` | 이 조사 단위가 결론에 주는 영향은 무엇인가 | 질문, 관련 증거, 관측과 해석, 선택지/trade-off, 현재 결론 또는 unknown, 확인 조건 |

Finding은 brief를 독립적으로 읽기 어렵게 만들 만큼 커질 때만 분리한다. 대화 transcript, 검색 결과
나열, state의 destination 사본은 만들지 않는다. landing이 끝나면 채택된 결론만 정본이나 spec에
자기완결 문장으로 흡수하고 Sketch 폴더는 삭제한다.

## 5. Adopt 문서 계약

| 문서 | 답해야 하는 질문 | 본문 계약 |
|---|---|---|
| `adoption/state.md` | 흡수 작업의 현재 좌표와 다음 행동은 무엇인가 | `next_route`, `next_action`, blockers; coverage와 conflict 상세는 sibling 문서가 소유 |
| `adoption/sources.md` | 유지 source 전체가 어떻게 처분되는가 | group별 include/exclude 경로, source 성격·권위, 찾을 지식 종류, target home, disposition, uncovered 수 |
| `adoption/conflicts.md` | source만으로 풀 수 없는 모순은 무엇인가 | 충돌 진술, 양쪽 증거, 영향, 이미 배제한 해석, 필요한 결정, decision route와 확인 조건 |

문서·코드·테스트·설정을 무조건 파일별로 나열하지 않는다. 유지 문서는 개별 disposition을 갖고,
동질적인 코드·테스트·설정은 경계가 검증 가능한 source group으로 회계할 수 있다. 경로 coverage와
의미 completeness는 서로 다른 검사다. Adopt는 예전 Devflow를 업그레이드하는 migration이 아니라
임의의 비관리 프로젝트를 내부 정본으로 흡수하는 진입이다.

## 6. Direct·Work·Verify 문서 계약

### `work/<artifact-id>/spec.md` — 무엇을 왜 구현하고 무엇으로 끝을 판정하는가

- 배경과 사용자 의도, 해결할 문제와 기대 결과
- goal과 non-goal
- 현재 맥락과 `read_first`
- 제품·기술·운영 제약 및 이미 내려진 결정
- 구현 범위와 deliverable: **무엇**을 바꿔야 하는지 쓰되 Worker의 국소 구현 판단을 대신하지 않는다.
- acceptance criteria와 관찰 가능한 완료 신호
- 허용 write boundary, 그리고 실제 병렬 dispatch가 필요할 때만 실행 unit과 안전한 seam
- 열린 결정·위험·차단 조건

Origin은 lineage 표지일 뿐 의존성이 아니다. `next_route: work`인 spec은 원문 없이도 목적·경계·acceptance를
판단할 수 있어야 한다. 준비/진행/완료 상태는 spec에 복제하지 않는다.

### `work/<artifact-id>/state.md` — 지금 안전한 지점과 다음 한 행동은 무엇인가

```yaml
base_revision: <작업이 출발한 revision>
last_safe_point: <디스크에서 확인 가능한 마지막 완결 지점>
next_route: sketch | direct | work | verify | product | architecture | design | user
next_action: <한 문장>
blockers: []
knowledge_candidates: [] # 구현 중 실제로 발견했을 때만
pending_landings: []
```

이는 append log가 아니라 교체되는 현재 스냅숏이다. 작업 관리권이 다른 세션·actor·branch로 넘어갈 수
있기 전에 마지막 안전 지점과 다음 행동을 반영한다. Acceptance와 write boundary는 spec, verdict는
verification이 소유한다. 진행률 퍼센트, 시도 일지, sibling 경로 pointer나 verdict 사본은 쓰지 않는다.
Tracked 선택 직후 최소 state를 첫 checkpoint로 만들며, spec이 아직 없으면 실행 가능 작업이 아니라
Direct가 복구할 불완전 artifact다. Snapshot은 임시 파일을 완결한 뒤 atomic replace한다.

### `work/<artifact-id>/verification.md` — acceptance가 실제로 입증됐는가

- 검증 대상 revision·환경·channel
- criterion별 expected / observed / evidence / `proven | failed | unproven`
- 전체 판정은 criterion에서 파생하며 관찰하지 못한 것은 pass로 쓰지 않는다.
- 실패 시 `failure_route`, `target`, 깨진 전제, `what_must_change_before_retry`
- unproven이면 재개 조건
- 검증 중 발견한 durable knowledge candidate·근거·예상 canonical path

검증 파일이 verdict의 유일한 소유자다. State에는 다음 route만 둔다. 검증 snapshot과 state route는
한 checkpoint 변경으로 publish한다. 임시 파일은 current로 읽지 않고
필수 sibling이 없으면 Resume이 불완전 artifact와 복구 writer를 보고한다.

## 7. 팀 인계 문서 계약

`team/<member>/<artifact-id>.md`는 Sketch·Adopt·Work 중 활성 산출물 하나에 대한 개인 작업면이다.

- artifact ID와 branch/worktree
- state의 last safe point 이후 생긴 실제 local delta
- 실행에 필요한 환경 특이점
- 아직 공유 사실로 확정하지 못한 의심·미해결 질문

다음 actor가 반드시 알아야 하는 공유 사실과 다음 행동은 먼저 artifact state나 정본에 반영한다. 팀 문서는 공유
진실, 전체 spec, state 사본, 장기 개인 노트가 아니며 artifact closure 때 함께 삭제한다. State에서 이 파일을
가리키는 포인터를 유지하지 않고 선택한 artifact ID로 `team/*/<artifact-id>.md`만 유계 탐색한다.
`<member>`는 repository team identifier이며 기본값은 `git config user.name`의 안정된 slug다. 같은 사용자의
여러 agent를 실제로 구분해야 할 때만 짧은 label을 덧붙인다.

## 8. 병렬 작업과 중단을 지탱하는 자연 규칙

1. 활성 산출물 하나의 state snapshot은 한 시점에 한 actor만 쓴다. 이는 코드 범위의 독점권이 아니다.
2. 병렬 작업은 서로 다른 artifact ID와 안정적인 seam을 우선하되 코드·정본 write scope 중첩 자체는
   금지하지 않는다. 공유 가변 state나 중앙 lock, room, claim, 전역 번호 발급기는 만들지 않는다.
3. Artifact ID는 순차 번호가 아닌 충돌하기 어려운 불투명 token이다. 예:
   `W-auth-import-<token>`, `S-offline-policy-<token>`. 기계적으로 생성하고 현재 tree 충돌도 확인하며 ID
   자체에 의미를 의존하지 않는다.
   고정 단일 경로인 `adoption/`은 team lookup에서 `adoption`을 artifact key로 쓴다.
4. 통합은 Git branch/PR merge가 맡는다. 같은 canonical home의 상충 변경은 자동 상태 병합이 아니라
   명시적 merge·decision 사건이다.
5. 관리권이 바뀔 수 있는데 현재 행동을 안전하게 끝내지 못했다면 떠나기 전에 state를 최신 스냅숏으로
   만든다. Product·Architecture·Design의 장기 탐색은 Sketch, Adopt는 adoption state, Direct·Work·Verify는
   work state를 checkpoint로 사용한다.
6. Closure 때 임시 artifact와 team file을 정리한다. PR/commit review가 있으면 먼저 goal·acceptance·
   verification 요약을 그 review surface에 남긴다. 이는 장기 정본이 아니라 변경 검토 증거다.

이 규칙은 터미널·agent·host별 경우의 수를 열거하지 않는다. 새 실행 환경도 관리권, write scope,
현재 스냅숏, Git 통합이라는 같은 질문으로 처리한다.

## 9. Skill Rails에 반영하는 작성 구조

Skill Rails source package 하나가 아홉 target을 만든다. 각 target의 always-read entry는 다음만으로도
독립 실행 가능한 최소 계약이어야 한다.

- 배경과 의도, 한 가지 목적
- trigger와 명시적 비범위, `.devflow` gate
- 선언된 입력과 이 skill이 소유하는 출력
- 완료 증거와 가능한 다음 route
- 이 skill이 판단하거나 수정하지 않는 책임
- 현재 입력만으로 판별 가능한 optional module open condition

Source package의 bootstrap template이 이 문서 2절에 해당하는 작은 project law를 `.devflow/index.md`에
심는다. 생성 뒤에는 그 project instance가 plugin 없는 actor까지 포함한 operational owner이고 skill은
이를 가리킨다. 한 writer만 쓰는 산출물 계약은 entry에 두고, Domain/Work처럼 여러 writer가 실제로
공유할 때만 canonical conditional module을 둔다. Resume 같은 read-only target은 writer module을 열지
않는다. 조건을 module을 열어 봐야 알 수 있거나 절약보다 탐색 비용이 크면 분리하지 않는다.

Renderer/checker는 header 존재, 허용 경로, 유효한 state 필드, dangling route처럼 기계적으로 판정 가능한
것만 다룬다. 좋은 요약, 충분한 배경, 올바른 domain 경계, 근거의 타당성은 AI와 사용자의 판단으로 남긴다.
Eligibility/gate와 route vocabulary는 source graph 한 곳에서 host description과 entry로 투영한다.
충돌 저항 artifact ID와 atomic snapshot publication은 의미 판단이 아닌 작은 mechanism이 맡는다.
구현은 target 하나를 먼저 author/build하고 receipt·diff·currentness를 확인한 뒤, fresh agent가 실제 fixture에서
올바르게 읽고 쓰는지 관찰한다. Build 성공은 배포 증거이지 사용성 증거가 아니다.

## 10. 문서 완성도 검토 질문

- 처음 읽는 AI가 이 문서의 질문과 다음 행동을 설명할 수 있는가?
- 필수 배경과 의도가 외부 대화 없이도 보이는가?
- 현재 사실, 미확정 해석, 실행 상태, 과거 과정이 서로 섞이지 않았는가?
- 같은 정보가 다른 문서에도 현재 진실처럼 남는가?
- 본문의 각 절이 실제 판단을 바꾸는가, 아니면 형식을 채우기 위한 것인가?
- 이 문서가 사라질 때 어떤 장기 지식이 유실되는가? 답이 “없음”인 임시 문서는 closure 때 삭제되는가?
