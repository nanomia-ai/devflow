---
title: Human and AI usage scenarios
status: owner-corrected-current-plan
purpose: Test whether the proposed system remains natural across real human, AI, interruption, and team situations.
read_when: Read when evaluating practical usability or deciding how a request should enter the graph.
canonical_for: Proposed runtime scenarios and failure handling.
tags: [devflow-vnext, scenarios, ai-usability, teams]
---

# 사람·AI 사용 시나리오

## 1. 사용성 기준

사람은 내부 stage 이름을 기억하지 않아도 된다. 아이디어를 말하거나, 변경을 요청하거나, “어디까지
했지?”라고 물으면 된다. AI는 현재 프로젝트 표식과 질문 성격을 보고 한 owner만 선택한다.

AI 관점의 핵심은 규칙을 많이 아는 것이 아니라 다음 네 가지를 잃지 않는 것이다.

1. 지금 판단해야 하는 질문과 그 owner.
2. 이번 요청에 필요한 최소 read set.
3. 현재 사실과 아직 검증되지 않은 가설의 구분.
4. 중단되어도 다음 agent가 재구성하지 않아도 되는 next action.

## 2. 핵심 시나리오 행렬

| 상황 | 진입 | durable 결과 | 만들지 않는 것 |
|---|---|---|---|
| 모호한 신규 아이디어 | `sketch(project)` | `.devflow/sketches/<id>`의 결정된 finding이 내부 Product로 흡수 | 매 대화 transcript |
| 명확한 신규 brief | `product` | Product → Architecture → optional Design | 불필요한 sketch |
| 기존 프로젝트 | `adopt` | `.devflow/project/`의 자기완결 정본과 source로 풀 수 없는 conflict | 외부 문서를 영구 정본으로 남김 |
| 작은 동일-session 수정 | quick lane | 코드·검증·Git 이력 | work folder |
| 일반 기능·유지보수 | `direct` | work spec/state → verify → owner landing/closure | 전역 task DB |
| 불확실한 기능 | `direct` → `sketch(change)` | spec을 막던 결정만 반환 | 프로젝트 Product 복제 |
| 중단된 작업 | `resume` | 최소 read set과 next route | transcript 복원 |
| 팀원 인계 | `resume` + state + member context | 사실과 개인 맥락을 분리한 재개 | identity room/claim |
| 검증 실패 | `verify` return packet | owner별 수정과 달라진 재시도 가설 | 같은 실패의 무한 반복 |

## 3. 신규 프로젝트와 Sketch 생성 시점

아이디어 대화가 아직 방향 탐색이라면 문서를 즉시 만들지 않는다. 다음 중 하나가 처음 성립할 때
active sketch를 만든다.

- 문제와 사용자를 한 문장으로 구분할 수 있다.
- 중요한 결정이 내려졌거나 이전 결정이 바뀌었다.
- 대화가 중단되어도 이어야 할 조사·가설이 생겼다.
- 조사 결과가 Product, Architecture, Design 중 어느 owner로 갈지 판단 가능하다.

생성물은 `.devflow/sketches/SNNN-<slug>/brief.md`와 `state.md`다. 조사 단위가 brief를 흐릴 만큼
커질 때만 `findings/`로 분리한다. `state.md`는 `exploring → decision-ready → landing`의 현재 phase와
다음 행동 하나를 소유한다. landing 뒤 폴더를 삭제하므로 완료된 탐구가 현재 지식처럼 남지 않는다.

Sketch는 Socratic, Dewey 같은 특정 사고법을 강제하지 않는다. 필요하면 강한 모델이 질문법·시장 조사·
기술 탐색을 선택한다. 문서에는 결론에 영향을 준 증거, 결정, unresolved, 각 finding의 destination만
남긴다. 상업성 검증도 제품 성격상 필요할 때만 한다.

## 4. 명확한 기획과 Product 직행

사용자가 이미 충분한 기획서나 명확한 설명을 주면 `product`가 바로 Product 정본을 만든다.
Product는 기술 스택이나 작업 순서를 소유하지 않는다. Architecture가 이어 받아 구조·검증 채널을
정하고, UI가 없으면 Design은 건너뛴다. AI는 “모든 단계를 통과해야 한다”가 아니라 “다음 결정이
실제로 필요한가”를 판단한다.

## 5. 점진 Adopt

Adopt는 모든 파일을 읽고 완전한 문서 세트를 한 번에 만드는 작업이 아니다.

1. 유지되는 source를 코드, 문서, 테스트, 설정, 운영 증거로 분류하고 일시 `adoption/sources.md`에서 회계한다.
2. Product·Architecture·Design·Domain owner별로 확인된 사실, 해석, 충돌, unknown을 분리한다.
3. 최소 routing과 한두 domain vertical slice부터 `.devflow/project/`에 자기완결 문장으로 쓴다.
4. 사람에게는 source로 해결되지 않는 제품 경계·모순만 묻는다.
5. 모든 입력을 내부 landing·명시 conflict·사용자 소유 비정본 산출물 중 하나로 처분한 뒤 adoption scratch를 삭제한다.

Adopt 완료는 “모든 것을 안다”가 아니라 “유지 source의 의미가 버려지지 않았고, 외부 문서가 사라져도
내부 정본만으로 다음 변경의 목적·경계·검증 대상을 이해할 수 있다”는 상태다. 외부 source 경로는
완료된 지식의 필수 포인터가 아니다.

## 6. Direct와 change Sketch의 경계

Direct는 요청을 목표, 비범위, acceptance, affected domains, read-first, 실행 단위로 만든다. 다음 중
하나가 spec을 막을 때만 `sketch(change)`로 보낸다.

- 사용자가 해결하려는 실제 문제가 여러 해석으로 갈린다.
- 제품/도메인 경계가 바뀔 수 있다.
- 선택지의 비용·리스크를 조사하지 않고 acceptance를 쓸 수 없다.
- 구현 전에 사람의 결정을 받아야 한다.

Sketch 결과 전체를 spec에 복사하지 않는다. 프로젝트 전체에 계속 참인 사실은 먼저 해당 project
owner에 흡수하고, 이번 변경의 결정과 acceptance에 영향을 준 근거만 Direct가 spec에 반영한다.
나머지는 해결 전에는 sketch에, landing 뒤에는 Git 이력에만 남는다.

## 7. Quick lane과 durable work

같은 session 안에서 끝나고, 되돌리기 쉽고, 병렬·인계 가능성이 없으며, acceptance가 단순한 수정은
Direct가 현재 turn의 짧은 quick contract로 남기고 Work가 구현·비례 검증한다. durable work folder나
독립 Verify는 만들지 않는다. 다음 중 하나라도 있으면 `WNNN-<slug>`를 만든다.

- session 중단 또는 다른 agent 인계 가능성
- 여러 acceptance나 여러 파일 owner
- 병렬 작업
- 비싼 검증 또는 높은 위험
- 구현 전에 합의해야 할 scope

Quick lane도 현재 정본과 프로젝트 검증 명령을 따른다. “작으므로 검증하지 않는다”는 뜻이 아니다.

## 8. Work 중 spec 결함 발견

Work는 구현 순서와 국소 구조를 자율적으로 바꿀 수 있지만 목표·비범위·acceptance를 조용히 바꾸지
않는다. 불가능하거나 비효율적인 spec을 발견하면 다음을 `state.md`에 남기고 Direct로 돌려보낸다.

- 어떤 전제가 실제 코드·실행과 달랐는가
- 가능한 최소 수정은 무엇인가
- acceptance와 product 경계가 바뀌는가
- 수정 전 안전하게 보존된 구현 상태는 무엇인가

이렇게 해야 다음 agent가 실패한 계획을 처음부터 반복하지 않는다.

## 9. Verify 실패 loop

Verify는 code를 고치지 않고 criterion별 observed/expected/evidence를 남긴다. failure owner가 Work면
구현으로, Direct면 spec으로, Product/Architecture/Design이면 해당 정본 owner로 보낸다.

재시도에는 반드시 “직전과 무엇이 달라졌는가”가 있어야 한다. 새 가설·입력·구현·검증 방법이 없다면
다시 Work를 호출하지 않는다. 관찰 수단이 없으면 `unproven`으로 닫고 어떤 조건이 생기면 재개할지를
쓴다. 이는 고정 횟수보다 실제 학습 여부를 기준으로 loop를 끊는다.

## 10. 지식 승격과 closure

검증 통과 뒤 Verify가 promotion candidates를 남기고, Work 또는 해당 정본 owner가 다음 작업자에게
필요한 사실만 승격한다.

- 제품 언어·경계 → Product
- 배치·의존·검증 규칙 → Architecture
- domain 개념·계약·함정 → Domain tree
- UI 원칙 → Design
- 오래 남을 결정 이유 → ADR, 현재 규칙은 해당 정본

진행 과정, 누가 무엇을 했는지, 실패한 시도 전체, 확인되지 않은 추측은 승격하지 않는다. 필요한
unknown은 Domain의 open question으로 명시한다. 장기 cross-domain use-case 계약이 필요한 경우에만
`.devflow/project/specs/`로 승격한다. `promotion_pending`이 비면 work와 member work file을 삭제하고 Git이 이력을
보존한다.

## 11. Resume와 중단 복구

Resume은 `.devflow/index.md`, active sketch/adoption/work의 immediate `state.md`, 사용자가 고른 item의
brief/spec, 필요할 때 현재 handoff pointer만 읽는다.
Git은 실제 bytes·revision을, state는 의도·acceptance·next action을 소유한다. base revision, write scope,
acceptance를 바꾸는 충돌은 구현을 막고, 나머지는 각 관할에 따라 조정한다.

Resume은 모든 domain을 읽거나 다음 skill의 판단을 대신하지 않는다. 결과는 다음 네 가지면 충분하다.

- 관리 여부와 active work
- 발견한 불일치·blocker
- 다음 행동 하나와 그 owner
- 그 행동 전에 읽을 최소 문서 목록

상태 질문에는 읽기 전용으로 답하고 불필요한 작업을 시작하지 않는다. Domain 설명은
`.devflow/index.md → project/domains/<domain>/index.md`, 배치 질문은 Architecture가 맡는다.

## 12. 팀·worktree·외부 orchestration

공유 사실은 work `state.md`, 개인 맥락은 `team/<member>/<work-id>.md`에 둔다. 인계 시 member file에는
worktree/branch, 환경 특이점, 시도 직전 맥락과 미해결 질문을 적고 공유 사실은 state로 이동한다.
새 agent는 state를 먼저 읽고 member file을 보조 맥락으로만 읽는다.

병렬 작업은 같은 state 파일을 공유하지 않고 각각 work ID를 가진다. Orca terminal, Codex subagent,
Claude, 단일 agent 중 무엇을 쓰는지는 orchestrator가 정한다. Devflow spec은 host-neutral한 목표,
read-first, write scope, acceptance만 전달한다. worker에게 플러그인이 없어도 spec과 정본만으로 작업할
수 있어야 한다.

## 13. 설치 전·오발동·버전 차이

표식이 없는 저장소에서 managed-only skill이 호출되면 어떤 파일도 쓰기 전에 중단하고 `sketch`,
`product`, `adopt` 중 가능한 진입만 안내한다. Adopt와 Product는 관리 상태를 만들 수 있으므로 두
호스트 모두 명시 호출 전용으로 둔다. Hook은 편의 기능이며 없어도 gate가 동작한다.

팀원의 plugin 버전이 달라도 프로젝트 행동의 핵심은 `.devflow/project/`, work folder, 짧은 skill 계약에 있다.
버전 차이가 정본 해석을 바꾸면 그 자체가 packaging 실패로 기록되어야 하며 프로젝트에 별도 호환
state를 만들지 않는다.
