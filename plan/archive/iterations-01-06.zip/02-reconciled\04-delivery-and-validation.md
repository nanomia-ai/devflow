---
title: Incremental delivery and validation plan
status: reconciled-working-copy
purpose: Sequence implementation so the cheapest discriminating observation precedes each new layer of complexity.
read_when: Read before implementing, approving a phase, or claiming a phase complete.
canonical_for: Proposed phase order, gates, falsifiers, and stop rules.
tags: [devflow-vnext, delivery, validation, skill-rails]
---

# 점진 구현·검증 계획

## 1. 실행 계약

각 phase는 하나의 중요한 주장을 공격한다. 파일 생성, build 성공, schema 통과는 delivery evidence일
뿐이다. 완료에는 다음 세 증거가 구분되어야 한다.

| 증거 | 답하는 질문 |
|---|---|
| delivery | canonical source에서 같은 artifact를 결정적으로 만들 수 있는가 |
| behavior | fresh AI가 필요한 문서만 읽고 올바른 다음 행동을 하는가 |
| effect | 실제 변경·인계·검증·지식 승격에서 사람의 부담과 실패가 줄었는가 |

결과는 `proven`, `failed`, `unproven`으로 기록한다. 실행하지 못한 검증을 pass로 쓰지 않는다.

## 2. Phase 0 — 승인 후 housekeeping

레거시를 `legacy/v0.25.1/`로 이동하는 일은 필요하지만 설계 검증의 gate가 아니다. 소유자 승인 뒤
별도 변경으로 수행한다.

실행 전 tracked/untracked 파일, plugin cache와 source repository 차이, 이동 전후 파일 목록·hash,
Git recovery path를 확인한다. 새 source/build/test 경로는 legacy를 import하거나 fallback으로 사용하지
않는다. 이 계획 단계에서는 이동하지 않는다.

## 3. Phase 1 — keyed document-system pilot

### 공격할 주장

`docs/README.md`, Product, Architecture, 두 domain tree, ADR, 작은 work state만으로 fresh AI가 전체를
읽지 않고 정답 문서와 다음 행동을 고를 수 있다.

### fixture

중개노트 원본은 수정하지 않는다. 별도 fixture에 성공 사례의 구조와 실제 난점을 대표하는 열두 개
안팎의 문서만 재구성한다.

```text
<project-knowledge>/README.md
<project-knowledge>/PRODUCT.md
<project-knowledge>/ARCHITECTURE.md
<project-knowledge>/domains/customer/README.md
<project-knowledge>/domains/customer/<depth>.md
<project-knowledge>/domains/contract/README.md
<project-knowledge>/domains/contract/<depth>.md
<project-knowledge>/adr/0001-<decision>.md
.devflow/devflow.md
.devflow/work/W001-<slug>/{spec,state,verification}.md
```

fixture를 만들기 전에 10개 질문별 정확한 expected read set과 next action을 answer key로 쓴다.
domain 질문, placement 질문, product 질문, status/resume 질문을 섞고 opened−expected,
expected−opened, next-action match를 측정한다.

한 시간 이내의 더 작은 syntax pre-check로 AI가 `summary/read_when`과 domain README 우선 읽기를
해석하는지만 본다. 이것은 독립 phase나 gate가 아니며 범용 schema·renderer를 만들지 않는다.

### 통과 신호

- 모든 질문에서 owner 문서를 찾는다.
- 조건부 depth 문서는 `read_when`이 맞을 때만 연다.
- Product/Architecture와 두 domain 전체를 무조건 읽지 않는다.
- state와 Git 불일치가 있으면 구현을 시작하지 않고 보고한다.
- answer key와 다른 read가 생기면 문서 구조, header, skill entry 중 어느 owner의 결함인지 분리한다.

## 4. Phase 2 — 첫 Skill Rails target: Resume

문서 작성보다 읽기 실패가 더 싸게 드러나므로 `resume` prose target 하나만 먼저 만든다.

1. 새 Skill Rails source package와 `resume` target을 만든다.
2. `imports: []`로 build한다.
3. generated diff와 receipt를 검토한다.
4. phase gate에서 double-build hash, integrity, source currentness를 확인한다.
5. standalone target만 fresh Claude/Codex session에 주고 Phase 1 질문을 반복한다.
6. emitted runtime 파일을 AI가 불필요하게 읽거나 실행하는지도 관찰한다.

Build receipt는 behavior pass가 아니다. Resume이 과잉 읽거나 super-router처럼 다음 skill 판단을 대신하면
entry source를 고치며 shared module이나 script를 추가하지 않는다.

## 5. Phase 3 — 일상 loop의 첫 vertical slice

Bootstrap skill보다 매일 반복되는 `direct → work → verify → land`를 먼저 검증한다. 같은 keyed fixture에
실제 작은 변경 하나를 만들되, 완료 시 domain 정본에 승격할 사실이 반드시 생기게 한다.

### 범위

1. Direct가 goal/non-goal/acceptance/read-first/unit을 쓰고 사용자 승인 지점을 명확히 한다.
2. Work가 한 unit만 구현하고 `state.md`를 갱신한다.
3. Verify가 criterion 하나를 의도적으로 실패시키고 owner를 판정한다.
4. 달라진 가설 없이 같은 실패를 반복하지 않는지 본다.
5. pass 뒤 Land가 durable fact만 domain owner에 승격하고 work를 삭제한다.
6. 동일-session quick lane은 folder 없이 완료해 대비한다.

### 중단 probe

Work 전, commit 후 Verify 전, Verify 중 세 지점에서 session을 끊고 fresh Resume으로 재개한다.
잘못된 unit을 실행하거나 완료된 일을 반복하거나 근거 없이 done으로 판단하면 state 구조가 실패한
것이지 더 많은 Resume 규칙이 필요한 것이 아니다.

### Land 유지 판정

첫 다섯 completed change에서 owner skill만으로 닫는 대조 경로를 포함해 durable fact 누락을 센다.
하나라도 누락되면 `land`를 독립 skill로 확정한다. 누락이 전혀 없고 Verify pass 경로가 더 단순하면
통합을 재검토한다.

## 6. Phase 4 — Adopt vertical slice

유지되는 문서가 일부 있고 코드와 충돌하는 작은 brownfield fixture의 domain 하나만 adopt한다.

성공 조건:

- maintained source가 disposition 없이 사라지지 않는다.
- fact, interpretation, unknown, conflict가 구분된다.
- Product/Architecture/Domain owner가 겹치지 않는다.
- AI가 모르는 내용을 문서 완성을 위해 발명하지 않는다.
- `reconstructed` 문서를 다음 Work가 가설로 취급하고 코드에서 확인한다.
- 사람에게 묻는 질문은 source로 결정할 수 없는 경계·모순뿐이다.
- activation 때 adoption scratch가 삭제되고 정본만 남는다.

원본 중개노트에는 어떤 변경도 하지 않는다. 실제 구조를 쓸 필요가 있으면 별도 복제 fixture에서만
관찰한다.

## 7. Phase 5 — 나머지 bootstrap skill

`sketch`, `product`, `architecture`, `design`, `adopt`를 한 target씩 build하고 fresh-use를 관찰한다.

순서:

1. 명확한 brief → Product → Architecture
2. backend-only brief → Design 생략
3. 모호한 idea → Sketch checkpoint → Product
4. project/change Sketch의 서로 다른 destination
5. Adopt가 owner별 reconstructed slice를 만드는 흐름

각 target은 약 40줄의 계약을 목표로 한다. target 하나가 통과하기 전 다음 target이나 shared module을
추가하지 않는다.

## 8. Phase 6 — 팀 handoff

Agent A가 work 중단 전 공유 사실을 `state.md`에, 개인 맥락을 `team/A/W001.md`에 남긴다. Agent B는
transcript 없이 재개한다.

의도적 실패 probe로 공유 사실 하나를 member file에만 남긴다. B가 그것을 사실로 실행하지 않고
`state.md`로 이동되지 않은 불일치로 표시해야 partition이 통과한다. Land 뒤 W001 member files가
삭제되고 `notes.md`가 정본처럼 읽히지 않는지도 확인한다.

Orca terminal, Codex subagent, 단일 agent에서 같은 spec이 동작하는지 비교하되 Devflow에 orchestrator
상태를 복제하지 않는다.

## 9. Phase 7 — index 기계화의 조건부 도입

다음 중 하나가 실제로 관찰될 때만 작은 index checker/generator를 검토한다.

- 유지되는 문서가 `docs/README.md`에서 빠짐
- 사라진 파일 링크가 남음
- 동일 질문에서 잘못된 `read_when` 선택이 반복됨
- 사람이 같은 routing 정보를 둘 이상의 index에 중복 작성함

도입하더라도 title, summary, read_when, status와 파일 존재만 결정적으로 검사한다. 의미 owner,
domain 경계, 좋은 summary를 script가 판단하지 않는다. 처음에는 일반 project script이며 별도
Skill Rails renderer로 승격하지 않는다.

## 10. Phase 8 — npm·host adapter

핵심 behavior가 명시 호출만으로 통과한 뒤 설치와 hook을 검증한다.

```text
plugin.json                         # portable identity + extensions.com.openai
.claude-plugin/plugin.json         # Claude adapter
skills/                             # Skill Rails built standalone targets
hooks/hooks.json
scripts/session-start.*             # marker check + short Resume pointer only
```

`.codex-plugin/plugin.json`은 실제 지원해야 할 특정 host version이 확인될 때만 fallback으로 추가한다.

설치 실험:

1. 같은 npm artifact를 두 host marketplace source로 설치한다.
2. clean session에서 skill 목록·명시 호출·묵시 호출 경계를 본다.
3. marker가 있을 때만 SessionStart pointer가 나오는지 본다.
4. hook을 제거해도 명시 호출과 gate가 그대로 동작하는지 비교한다.
5. update/uninstall 뒤 stale skill·hook이 남지 않는지 본다.

## 11. Skill Rails 비용·regrowth stop rule

첫 세 target(`resume`, `direct`, `work`)에서 순수 authoring 시간과 build/diff/receipt 시간을 분리해 잰다.
빌드 루프가 authoring 시간의 1/3을 넘으면 비용을 `unproven risk`로 기록하고 사용자에게 phase-gate
build로 완화할지 결정 받는다.

다음 중 하나면 구현을 즉시 확장하지 않는다.

- target 하나의 `imports`가 1개를 넘음
- 모든 target이 동일 module을 무조건 읽음
- prose target 출력이 현재 일곱 파일보다 늘어남
- build artifact를 AI 행동 증거로 보고 fresh-use를 생략함
- 한 실패 사례 때문에 모든 target에 새 규칙을 추가하려 함

## 12. 최초 fresh-agent 관찰 세트

1. unmanaged repo에서 Work가 쓰기 전에 거절하는가
2. backend-only project가 Design artifact를 만들지 않는가
3. domain 질문에서 README → 관련 depth만 읽는가
4. 중단된 work를 transcript 없이 재개하는가
5. spec 결함을 Work 반복이 아니라 Direct로 돌리는가
6. 관찰 불가 criterion을 pass가 아니라 unproven으로 닫는가
7. member context의 공유 사실을 state보다 우선하지 않는가
8. Land가 progress narrative를 정본에 넣지 않는가

관찰을 통과한다고 시나리오를 무한히 추가하지 않는다. 새 시나리오는 기존 결정을 실제로 바꾸는
실패가 있을 때만 추가한다.
