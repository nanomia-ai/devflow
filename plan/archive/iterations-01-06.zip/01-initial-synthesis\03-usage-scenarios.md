---
title: Human and AI usage scenarios
status: draft-for-owner-review
purpose: Test the proposed system against realistic human, AI, team, interruption, and failure paths.
read_when: Read when evaluating usability, adding a workflow rule, or designing a fresh-agent observation.
canonical_for: Planning scenarios and expected observable behavior.
tags: [devflow-vnext, scenarios, usability, ai-behavior, team, recovery]
---

# 사람·AI 사용 시나리오

이 문서는 모든 실행에 읽힐 규칙이 아니라 설계를 공격하는 시나리오 집합이다. 한 시나리오의 실패를
곧바로 전역 규칙으로 만들지 않고, 실패 owner와 최소 개입을 먼저 찾는다.

## 1. 사용 관점

### 사람에게 자연스러운가

- 사용자는 자기 요청을 Devflow 용어로 번역하지 않아도 된다.
- 아이디어가 명확하면 불필요한 인터뷰나 sketch를 건너뛴다.
- 큰 결정만 사용자에게 돌리고, 되돌릴 수 있는 구현 판단은 AI가 진행한다.
- 산출물 수보다 다음에 다시 시작할 수 있는가를 중시한다.
- 문서 작성 자체가 개발보다 더 큰 일이 되지 않는다.

### AI에게 자연스러운가

- 짧은 metadata만으로 현재 사용할 스킬과 첫 read set을 판정한다.
- 현재 질문과 무관한 문서를 “혹시 몰라서” 전부 읽지 않는다.
- 사실·해석·미확인과 정본·작업 기록을 구분한다.
- 모호한 의미 판단은 AI가 근거를 모아 제안하되 사용자 권한을 침범하지 않는다.
- 스크립트의 상태 결정을 맹목적으로 따르지 않고, 스크립트는 존재·참조·정확한 형식만 판정한다.
- 중단·compaction·새 agent에서도 transcript가 아니라 durable artifact로 이어간다.

## 2. 핵심 시나리오 행렬

| # | 상황 | 기대 경로 | 관찰할 결과 |
|---|---|---|---|
| S1 | Devflow가 없는 저장소에서 사용자가 구현을 바로 요청 | managed-only skill은 쓰기 전에 거부하고 `adopt`, `product`, `sketch` 중 맞는 진입만 제시 | `.devflow` 임의 생성과 `work` 오발동 0 |
| S2 | 신규 프로젝트 아이디어가 모호함 | `sketch(project)`가 질문·리서치를 유계 진행하고 의미 있는 checkpoint부터 저장 → `product` | 모든 대화 기록이 아니라 결정·근거·미결만 남음 |
| S3 | 이미 명확한 기획서가 있음 | sketch 없이 `product`가 입력을 정본 구조로 흡수 → `architecture` | 불필요한 인터뷰·중복 문서 없음 |
| S4 | 백엔드 전용 프로젝트 | product → architecture → active, design 생략 | 빈 design 문서/폴더 없음 |
| S5 | 기존 대형 프로젝트 도입 | `adopt`가 source disposition과 conflict/coverage를 만들고 domain별로 product/architecture에 점진 착지 | “모든 것을 먼저 완성” gate 없이 불확실성 표시 |
| S6 | 작은 가역 버그 수정 | direct quick lane → work → 관련 검사, durable work folder 없음 | 문서 부산물 없이 완료, scope 변화 없음 |
| S7 | 큰 기능 요청 중 제품·기술 미지가 큼 | direct → `sketch(change)` → owner별 지식 승격 → direct spec | 연구가 spec 내부 장문으로 섞이지 않음 |
| S8 | 구현 중 spec이 비효율적이거나 불가능함 | work가 의미를 조용히 바꾸지 않고 proposal → direct가 spec amendment | 승인 계약과 구현 편의가 구분됨 |
| S9 | verify가 실패함 | failure owner 분류: code→work, spec→direct, canon→owner, 관찰 불가→unproven | 같은 근거로 work loop 반복 없음 |
| S10 | 세션 중단 후 다른 AI가 재개 | resume이 manifest/index/work state/member handoff로 제한된 read set과 다음 하나를 반환 | transcript 없이 실제 다음 행동 수행 가능 |
| S11 | 여러 agent/worktree가 병렬 작업 | Direct가 독립 work ID를 만들고 각 member path만 갱신, 공용 정본 변경은 owner 단위로 착지 | 같은 상태 파일을 병렬 편집하지 않음 |
| S12 | 작업에서 장기 domain 사실 발견 | verify 후 Product/Architecture/Design owner가 domain 문서에 현재형 사실 승격 | 개인 handoff/spec에만 남지 않고 중복 복사도 없음 |
| S13 | session hook이 설치되지 않거나 실패 | 사용자가 명시 호출하거나 skill description으로 진입, manifest/index에서 동일 흐름 | hook 부재가 correctness failure가 아님 |
| S14 | 문서가 장기적으로 많아짐 | root index → domain index → 현재 concern만 읽음 | 문서 총량과 현재 read set 증가가 선형이 아님 |

## 3. 신규 프로젝트: 모호한 아이디어

### 사람의 경험

사용자는 처음부터 완성된 PRD 질문지를 채우지 않는다. AI와 대화·리서치를 진행하다 다음 중 하나가
생기면 첫 checkpoint를 만든다.

- 문제 상황과 대상 사용자가 한 문장으로 구분된다.
- 경쟁하는 두 방향 중 하나를 선택하거나 판별할 관찰이 생긴다.
- 외부 리서치 결과가 다음 결정을 실제로 바꾼다.
- 세션을 중단해도 복구해야 할 만큼 대화가 진행됐다.

checkpoint에는 대화 전문이 아니라 배경, 현재 문제 주장, 확인된 사실, 사용자 결정, 미결정,
다음 질문만 둔다. 긴 조사 자료는 sketch 아래 별도 concern 문서로 나누고 index에서 정확한
`read_when`을 준다.

### AI의 행동

1. 해결안을 빨리 확정하지 않고 문제 상황과 성공 관찰을 분명히 한다.
2. 소크라테스 질문은 용어·전제·반례를 밝히는 데만 사용한다.
3. 듀이식 탐구는 모호한 상황을 결정 가능한 문제로 좁히는 데 사용한다.
4. 상업성 검증은 상업 프로젝트이고 해당 결정이 제품 진행을 바꿀 때만 연다.
5. Product로 보낼 때 `결정`, `근거`, `미결정`, `버린 방향과 이유`를 구분한다.

## 4. 기존 프로젝트: 점진 Adopt

Adopt의 목표는 첫 실행에 “완전한 문서화”가 아니라, 기존 자료가 어떤 owner로 가야 하는지와 현재
모르는 범위를 투명하게 만드는 것이다.

```text
1. 유지 대상 source group 식별
2. 제품 의미 / 기술 구조 / UI 계약 / domain 지식 / 현재 동작 / 임시 기록으로 disposition
3. 대표 사용자 흐름 하나로 product·architecture·domain tree의 최소 수직 단면 작성
4. conflict와 unknown을 owner 결정으로 전달
5. 필요 domain을 다음 pass에서 확장
```

Coverage는 `covered`, `partial`, `unknown`, `not-applicable`을 구분한다. “모든 파일을 읽었다”는
완료 신호가 아니다. 대표 흐름에서 새 AI가 현재 동작과 소유 문서를 찾아 실제 변경을 안전하게
수행하는지가 첫 효과 관찰이다.

## 5. 기능 요청: Direct와 Sketch의 경계

Direct는 요청마다 research를 흡수하지 않는다. 다음 중 하나가 현재 spec을 크게 바꿀 때만
`sketch(change)`로 보낸다.

- 해결하려는 사용자 문제가 불명확하다.
- 기술 후보의 가능성·비용·안전성이 판정되지 않았다.
- 시장/상업성 판단이 기능 자체의 채택 여부를 바꾼다.
- 제품/domain/architecture owner의 결정이 선행되어야 한다.

Sketch 결과가 돌아오면 Direct는 필요한 결론만 spec에 반영하고 원시 조사 전체를 복사하지 않는다.
전역 지식은 spec을 경유하지 않고 해당 정본에 먼저 승격한다.

## 6. Spec 변경과 구현 자율성

Work가 자율적으로 바꿀 수 있는 것:

- 함수/파일 내부 구현 방식
- 되돌릴 수 있는 작업 순서
- acceptance를 보존하는 국소 refactor
- 더 작은 검증 probe

Direct로 반환해야 하는 것:

- 목표·비범위·사용자-visible behavior 변경
- acceptance 삭제·완화·새 조건 추가
- 다른 Product/Domain/Architecture owner로 scope 확장
- 기존 spec이 실현 불가하거나 서로 모순됨

반환 시 “새 spec을 대신 작성”하지 않고 관찰, 영향을 받는 criterion, 가능한 선택지, 권고와
결정 비용을 적는다. Direct가 amendment를 승인하면 Work는 새 revision을 기준으로 재개한다.

## 7. Verify 실패 루프

예시:

```text
criterion: 중단 후 새 agent가 다음 작업을 이어간다
observed: handoff가 spec path는 주지만 기준 commit을 주지 않아 다른 diff를 읽음
expected: 정확한 기준 revision과 current write scope를 찾음
evidence: fresh session transcript + git state
failure_owner: work
what_must_change_before_retry: handoff에 base revision을 기록하고 다른 변경과 구분
```

수정 후 같은 검증을 다시 실행한다. 다시 실패하면 이전 가설과 다른 원인을 제시해야 한다. 같은
criterion과 같은 원인으로 두 번 돌아오면 구현 반복을 멈추고 Direct에서 spec/전달 계약 자체를
재검토한다. 횟수는 보편 법칙이 아니라 loop 증식 신호다.

## 8. 팀·worktree·handoff

### 단일 agent

같은 agent가 Direct→Work→Verify를 수행할 수 있다. 독립 검토가 결과를 바꿀 위험이 큰 경우에만
clean-context verifier를 붙인다.

### subagent 또는 외부 terminal

Direct의 work unit은 실행 host와 무관하다. coordinator는 spec ID, 정확한 write scope, 선행 조건,
acceptance, 정본 read set을 worker에게 전달한다. Devflow 문서 의미는 Codex subagent, Claude,
Orca terminal에 따라 바뀌지 않는다.

### 병렬 실행

두 작업이 같은 canonical owner나 같은 파일을 수정하면 기본적으로 병렬화하지 않는다. 독립 work
ID가 있어도 마지막 승격이 같은 domain index라면 승격은 owner가 순차 통합한다.

### handoff 내용

```text
member / worktree / branch:
work id and spec:
base revision:
observed current state:
files changed and write scope:
last verification:
next one action:
blocker or decision needed:
knowledge promotion pending:
```

개인 작업 취향, 긴 사고 과정, 전체 shell log를 handoff에 넣지 않는다. 프로젝트 공용 사실이
확인되면 해당 정본에 승격하고 handoff에는 링크만 남긴다.

## 9. Resume의 실제 경계

Resume은 다음 순서만 수행한다.

1. project root와 manifest를 찾는다.
2. lifecycle과 index currentness를 확인한다.
3. 명시된 work/member가 있으면 그 state와 handoff만 연다.
4. Git의 열린 변경과 기준 revision이 충돌하는지 확인한다.
5. 다음 하나의 owner, 정확한 read set, 막힌 결정 또는 실행 가능한 next action을 반환한다.

Resume은 모든 domain 문서를 읽거나, 누락된 상태를 추측하거나, 다른 스킬의 판단을 대신하지 않는다.
진행 중 work가 없으면 사용자의 현재 의도에 맞는 Direct/Product/Architecture 등을 안내한다.

## 10. 장기 지식 누적

한 기능 완료 시 다음 질문만 한다.

```text
이번 작업에서 이후 판단을 바꿀 현재 사실이 생겼는가?
그 사실의 단 하나의 owner는 어디인가?
코드·테스트만으로 충분히 발견 가능한가, 문서가 필요한가?
기존 문장을 교체해야 하는가, 독립 concern으로 분리할 가치가 있는가?
```

답이 없으면 문서를 추가하지 않는다. 답이 있으면 현재 owner 문장을 고치고 work 문서에서 중복을
제거한다. 이 흐름이 “작업 기록을 모두 영구 보존”하지 않으면서도 장기 지식을 누적하는 핵심이다.

## 11. 스킬 오발동과 설치 전 상태

- Skill description 자체에 managed/unmanaged 경계를 구체적으로 적는다.
- `work`, `verify`, `resume`은 `.devflow/manifest.json`과 필요한 work input을 entry 초기에 확인한다.
- `.devflow`가 없으면 hidden fallback이나 자동 init을 하지 않는다.
- `sketch`, `product`, `adopt`만 bootstrap 의도에서 호출될 수 있다.
- 명시적으로 잘못 호출된 경우에도 가능한 다음 진입만 알려 주고 장문 policy를 출력하지 않는다.

