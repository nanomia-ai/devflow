---
title: Devflow vNext planning map
status: reconciled-working-copy
purpose: Route readers through the current whole-system plan and its preserved design iterations.
read_when: Start here when reviewing, implementing, or challenging Devflow vNext.
canonical_for: Current planning state only; runtime behavior does not exist yet.
tags: [devflow-vnext, planning, index]
---

# Devflow vNext 기획 지도

이 기획의 목표는 스킬을 많이 만드는 것이 아니라, 사람이 요청하고 AI가 판단·구현하는 흐름에서
필요한 지식만 읽히고 검증된 지식이 장기간 자연스럽게 축적되는 최소 체계를 만드는 것이다.
레거시는 실패 증거이며 호환 대상이 아니다. 중개노트는 성공 원리를 관찰하는 읽기 전용 사례이며
복제 대상이 아니다.

## 현재 수렴안

- 프로젝트 정본은 사람이 자연스럽게 찾는 `docs/`에 둔다.
- `.devflow/`는 설치 표식, 진행 중 탐구·작업·검증·팀 맥락만 맡는다.
- 공개 스킬은 `sketch`, `product`, `architecture`, `design`, `adopt`, `direct`, `work`,
  `verify`, `land`, `resume`의 열 개다.
- 공개 `principles`와 `domain` 스킬은 만들지 않는다.
- Domain은 스킬 단계가 아니라 `docs/domains/<domain>/`이라는 지식 소유 축이다.
- `resume`은 상태·재개·문서 방향을 알려 주는 하나의 읽기 전용 진입문이다.
- `land`는 통과한 작업에서 다음 작업자가 알아야 할 사실만 정본으로 승격하고 임시 산출물을 닫는다.
- Skill Rails는 하나의 canonical source package와 얇은 prose target을 만드는 저작·배포 계층으로만 쓴다.
  런타임 의사결정 엔진이나 프로젝트 상태 기계로 사용하지 않는다.
- 구현은 작은 문서 fixture와 fresh-agent 관찰에서 시작하며, 한 phase의 가정이 통과하기 전 다음
  복잡성을 추가하지 않는다.

## 문서별 읽기 경로

| 알고 싶은 것 | 읽을 문서 |
|---|---|
| 왜 다시 설계하며 무엇을 성공으로 보는가 | [01-intent-and-evidence.md](01-intent-and-evidence.md) |
| 스킬 관계, gate, 문서 트리, 지식 승격 | [02-skill-and-document-architecture.md](02-skill-and-document-architecture.md) |
| 사람·AI·팀이 실제로 어떻게 사용하는가 | [03-usage-scenarios.md](03-usage-scenarios.md) |
| 무엇부터 구현하고 어떤 관찰로 다음 단계에 가는가 | [04-delivery-and-validation.md](04-delivery-and-validation.md) |
| 레거시·중개노트·공식 호스트 조사 근거 | [05-research-evidence.md](05-research-evidence.md) |
| 합의·잠정·거부 결정과 재검토 조건 | [06-decision-ledger.md](06-decision-ledger.md) |

## 이 계획이 하지 않는 것

- 아직 레거시 파일을 이동하지 않는다.
- 아직 스킬, 훅, 설치 패키지, renderer를 구현하지 않는다.
- 아직 문서 schema를 범용 프레임워크로 만들지 않는다.
- 빌드 성공을 AI 사용성의 증거로 간주하지 않는다.
- 미래 가능성만으로 규칙·필드·스크립트를 추가하지 않는다.

## 설계 반복 기록

각 닫힌 시점은 [상위 iterations/](../)에 전체 문서와 변경 이유를 함께 보존한다.

1. `01-initial-synthesis` — 조사 결과를 합친 최초안. 동결됨.
2. `02-reconciled` — 독립 페이블안과 상호 반론을 거친 수렴안. 이 작업본을 기준으로 동결 예정.
3. `03-inversion-review` — 02 전체를 더 적은 스킬·문서·상태로 대체할 수 있는지 역발상으로 검증할 최종안.

각 반복은 이전 문서를 덮어쓰지 않는다. `proven`, `failed`, `unproven`을 구분하고, 잠정 결정에는
반드시 그것을 뒤집을 가장 값싼 관찰을 적는다.
