---
title: Skill graph and document architecture
status: draft-for-owner-review
purpose: Define the minimal skill set, chaining rules, document ownership, and knowledge promotion model.
read_when: Read when deciding which skill owns a judgment or where durable knowledge belongs.
canonical_for: Proposed Devflow vNext system structure.
tags: [devflow-vnext, skills, documents, domains, routing, knowledge]
---

# 스킬 관계와 문서 시스템

## 1. 설계 원리

Devflow vNext는 전역 단계 상태 기계가 아니다. 독립적인 작은 스킬이 서로 다른 판단을 소유하고,
프로젝트 문서는 질문별 현재 진실을 소유한다. 각 스킬은 자기 결과와 가능한 다음 진입점을
명시하지만 다른 스킬을 대행하지 않는다.

```text
사용자 의도
  → 현재 프로젝트 상태와 질문 종류를 판단
  → 정확히 한 스킬이 한 의미 결정을 소유
  → 결과를 정본 또는 작업 문서 한 곳에 착지
  → 다음 스킬이 필요할 때만 명시적으로 연결
```

스킬은 **판단 작업의 종류**, 문서는 **지식의 소유자**다. Domain이 지식 체계의 중심이어도
`domain`이라는 별도 실행 단계가 필요한 것은 아니다.

## 2. 확정할 스킬 집합

| 스킬 | 하나의 책임 | 주요 출력 | 다음 선택지 | 하지 않는 일 |
|---|---|---|---|---|
| `sketch` | 불명확한 문제·아이디어·리서치를 결정 가능한 지점까지 좁힌다 | project/change sketch와 finding landing 표 | project → product, change → direct, 관할 변경 → 해당 owner | 정본이나 spec을 대신하지 않음 |
| `product` | 프로젝트 목적, 사용자, 가치, 경계, 전역 제품 불변식과 domain 의미를 정한다 | `product.md`, 필요한 domain index | architecture, 필요 시 design | 기술 구조·작업 순서·진행 상태를 소유하지 않음 |
| `architecture` | 기술 구조, 의존·런타임·데이터 경계, 검증 채널과 조건부 문서 트리를 정한다 | `architecture.md`와 필요한 상세/domain 기술 문서 | design 또는 direct | 미래 구조를 미리 만들지 않음 |
| `design` | 필요한 프로젝트의 시각·상호작용 원칙과 조건부 상세 트리를 정한다 | `design.md`와 필요한 상세/domain design 문서 | direct | UI가 없는 프로젝트에 빈 체계를 만들지 않음 |
| `adopt` | 기존 자료를 증거로 분류하고 새 정본 체계로 점진 진입시킨다 | source disposition, conflict/coverage, owner별 전이 묶음 | product → architecture → optional design | 레거시 구조를 복사하거나 한 번에 완전 재구성하지 않음 |
| `direct` | 현재 요청을 실행 가능한 계약으로 만들고 작업 단위를 정한다 | quick contract 또는 durable work spec | work, 불확실하면 sketch | 장기 탐구와 agent runtime을 내부에 삼키지 않음 |
| `work` | 승인된 한 작업 단위를 구현하고 인계 가능한 현재 상태를 유지한다 | 구현, state, verify 입력 | verify 또는 direct에 변경 제안 | 목표·비범위·acceptance를 조용히 바꾸지 않음 |
| `verify` | acceptance와 실제 효과를 실행으로 공격하고 판정한다 | proven/failed/unproven evidence와 return packet | work/direct/정본 owner/종료 | 실패를 즉시 전역 규칙으로 일반화하지 않음 |
| `resume` | manifest, index, active work/member handoff를 읽고 다음 하나의 owner를 고른다 | 제한된 read set과 다음 스킬 | 위 스킬 중 하나 | 전역 복구 엔진이나 다른 스킬 대행 |

### `principles`를 공개 스킬로 두지 않는 이유

공통 규약이 사용자 진입점이 되면 실제 의도보다 절차가 먼저 실행되고 다시 슈퍼 라우터가 된다.
대신 여러 스킬이 실제로 공유하는 최소 불변식만 Skill Rails의 한 canonical shared module로 둔다.
각 standalone target은 그 모듈이 필요한 경우 명시적으로 포함한다.

### 별도 `domain` 스킬을 두지 않는 이유

Domain 중심성은 `.devflow/domains/<domain>/`의 정본 소유권과 승격 흐름으로 구현한다. 별도 스킬은
Product의 업무 의미, Architecture의 기술 경계, Direct의 현재 계약을 다시 겹치게 하거나 단순
라우터가 된다.

```text
“상담 이력은 customer와 contract 중 누가 소유하는가?”
  업무·데이터 의미 결정       → product
  코드·저장·의존 배치 반영    → architecture
  현재 변경의 scope/acceptance → direct
```

다음이 pilot에서 반복 관찰될 때만 `domain` 스킬을 다시 검토한다.

1. Product와 Architecture 사이에서 같은 domain 사실이 두 번 이상 소실된다.
2. fresh AI가 domain 문서 수정 owner를 반복해서 잘못 고른다.
3. 새 스킬이 기존 라우팅을 줄일 수 있고 완료 결과가 다른 스킬과 겹치지 않는다.

## 3. 전체 chaining

```text
불명확한 신규 아이디어 → sketch(project) → product → architecture → [design] → active
명확한 신규 기획 ─────────────────→ product → architecture → [design] → active
기존 프로젝트 ─────────→ adopt → product → architecture → [design] → active

active 프로젝트의 요청
  → direct
      ├─ 문제/해법의 큰 미지가 있음 → sketch(change) → direct
      ├─ 제품/domain 의미 변경      → product → architecture 파급 → direct
      ├─ 기술 경계 변경             → architecture → direct
      ├─ 시각/상호작용 원칙 변경     → design → direct
      └─ 실행 계약 준비됨            → work → verify
                                              ├─ 구현 결함 → work
                                              ├─ spec 결함 → direct
                                              ├─ 정본 결함 → 해당 owner
                                              └─ 관찰 불가 → unproven으로 닫고 재개 조건 기록
```

`sketch`는 프로젝트용과 변경용으로 나누지 않는다. 탐구 방법은 같고 결과가 착지하는 owner만 다르다.
한 sketch의 각 finding은 `destination`, `landed|unresolved`를 가지며, 채택되지 않은 조사 내용을
정본으로 승격하지 않는다.

## 4. 프로젝트 gate

폴더 존재만으로는 sketch 중인 프로젝트가 active로 오인될 수 있으므로 작은 manifest가 필요하다.

| 상태 | 허용 진입 |
|---|---|
| `.devflow/` 없음 | `sketch`, `product`, `adopt` |
| `lifecycle: planning` | `sketch`, `product`, `architecture`, optional `design`, `resume` |
| `lifecycle: adopting` | `adopt`, `product`, `architecture`, optional `design`, `resume` |
| `lifecycle: active` | 전체. 단, `work`/`verify`는 유효한 work item이 필요하고 Product/Architecture/Design은 자기 관할 변경일 때만 |

managed-only 스킬은 조건이 맞지 않으면 어떤 파일도 쓰기 전에 중단하고 가능한 bootstrap 스킬만
짧게 안내한다. manifest에는 다음만 둔다.

```json
{
  "schemaVersion": 1,
  "lifecycle": "planning",
  "index": ".devflow/index.md"
}
```

`currentStage`, global queue, retry count, agent session과 같은 workflow 상태는 넣지 않는다.

## 5. 목표 문서 트리

```text
.devflow/
  manifest.json
  index.md                         # 파생 routing view; 상세 지식의 정본이 아님
  product.md                       # 목적·사용자·제품 경계·전역 domain 의미
  architecture.md                  # 전역 기술 구조와 상세 읽기 지도
  architecture/                    # 실제 독립 질문이 생길 때만
  design.md                        # UI/interaction이 있을 때만
  design/                          # 실제 독립 질문이 생길 때만
  domains/
    <domain>/
      index.md                     # 목적·경계·불변식·핵심 언어·자식 읽기 지도
      architecture.md              # domain 기술 경계가 독립 읽기 가치가 있을 때
      design.md                    # domain 고유 UI 계약이 있을 때
      <concern>.md                 # 현재 질문이 아니면 안전하게 건너뛸 수 있을 때만
  decisions/
    NNNN-<slug>.md                 # 큰 결정 이유·기각 대안·재검토 조건
  sketches/
    <sketch-id>/                   # 진행 중인 탐구만
  adoption/
    sources.md                     # 도입 중 source disposition/coverage
    conflicts.md                   # 아직 owner 결정을 못 받은 충돌
  work/
    <work-id>/
      spec.md                      # Direct 소유: 목표·비범위·acceptance
      state.md                     # Work 소유: 기준 revision·현재 owner·next action·bounded attempts
      verification.md              # Verify 소유: 최신 proven/failed/unproven과 증거
  team/
    <member-id>/
      index.md                     # identity/worktree/active work 링크
      handoffs/
        <work-id>.md               # 개인·branch·실행에 한정된 인계
```

모든 폴더와 파일을 미리 만들지 않는다. 현재 프로젝트에 필요한 owner와 상세 문서만 생성한다.
전역 glossary는 기본 구조에서 제외한다. 여러 domain이 같은 용어를 다르게 사용해 실제 충돌이
생긴 경우에만 Product 관할의 cross-domain language 문서를 추가한다. Capability는 전역 지식 계층이
아니라 domain 안의 사용자 능력 또는 현재 work spec으로 표현한다.

## 6. 문서 헤더와 조건부 읽기

모든 유지 문서의 공통 헤더는 다섯 필드로 제한한다.

```yaml
---
id: domain:contract
kind: domain-index
summary: 계약 업무의 의미·경계·불변식과 상세 문서 지도
tags: [domain/contract, product]
read_when:
  - 요청이 계약의 업무 의미, 소유 경계 또는 불변식을 바꾸거나 의존할 때
---
```

- `read_when`은 현재 요청과 이미 선언된 입력으로 열기 전에 판정할 수 있어야 한다.
- `status`, `owner`, `next`는 sketch/work/handoff처럼 실제 상태가 필요한 문서에만 추가한다.
- 날짜, 모든 관련 문서 목록, 전역 dependency graph를 공통 필드로 강제하지 않는다. Git이 이력을 소유한다.
- `tags`는 발견 보조이며 authority나 chaining을 결정하지 않는다.

`index.md`는 manifest와 헤더에서 생성 가능한 비권위 routing view를 목표로 한다. 초기 pilot은 작은
수작업 fixture로 의미를 검증하고, index drift가 실제 부담임이 확인되면 결정적 renderer/checker를
추가한다. 생성 index에는 핵심 문서의 read condition, domain 목록, active sketch/work, ADR summary만
두고 각 member handoff 내용을 펼치지 않는다.

## 7. 문서 소유권

| 현재 사실 | canonical owner |
|---|---|
| 프로젝트 목적·사용자·전역 제품 의미 | `product.md` |
| domain 목적·포함/제외·업무 불변식·핵심 언어 | `domains/<domain>/index.md`, Product 판단 |
| 전역 기술 구조·runtime·data·검증 방식 | `architecture.md`와 조건부 상세 |
| domain의 코드·데이터·의존 경계 | domain 상세 문서, Architecture 판단 |
| 전역/도메인 UI·상호작용 원칙 | `design.md` 또는 domain design, Design 판단 |
| 고비용 결정·기각 대안·재검토 조건 | `decisions/` |
| 현재 변경의 승인된 목표·비범위·acceptance | active work `spec.md` |
| 현재 실행·branch·다음 행동 | work `state.md`와 member handoff |
| 실제 판정과 증거 | work `verification.md`, 코드·테스트·CI |
| 원시 로그·일시 수치 | Git/CI/외부 task artifact |

ADR은 현재 규칙을 숨기는 장소가 아니다. 승인된 현재형 규칙은 같은 변경에서 해당 Product,
Architecture, Design 또는 Domain 문서에 흡수하고 ADR은 이유와 대안을 보존한다.

## 8. 지식 승격

작업 기록이 자동으로 지식이 되지 않는다. 개인 또는 work 사실은 다음을 모두 만족할 때만 공용
정본으로 승격한다.

1. 이후 다른 작업의 판단을 실제로 바꾼다.
2. 현재 증거와 실제 좌표가 있다.
3. 하나의 canonical owner를 지정할 수 있다.
4. 단순 실행 로그가 아니라 현재 유지할 사실이다.

```text
sketch finding / member observation / verify result
  → 사실·해석·미확인을 분리
  → Product | Architecture | Design | Domain | ADR 중 owner 결정
  → owner 스킬이 현재형 사실만 반영
  → 원래 기록은 링크 또는 resolved 표식만 남기고 내용을 복제하지 않음
```

완료된 sketch와 work 문서는 durable 사실을 모두 승격한 뒤 기본적으로 working tree에서 제거하고
Git 이력으로 보존한다. 규제·감사 등 별도 제품 요구가 있을 때만 보존 profile을 추가한다.

## 9. Direct·Work·Verify 권한

Direct만 목표, 비범위, acceptance의 의미를 바꾼다. Work는 구현 순서와 국소 수단을 자율적으로
바꿀 수 있지만 의미 변경은 proposal로 Direct에 반환한다. Verify는 둘을 수정하지 않고 판정한다.

Verify 실패 반환의 최소 계약:

```text
criterion:
observed:
expected:
evidence:
failure_owner: work | direct | product | architecture | design
what_must_change_before_retry:
unproven:
```

- 구현이 spec과 다름 → `work`
- spec이 모순·누락·실현 불가 → `direct`
- 제품/domain 의미 또는 기술/UI 정본이 틀림 → 해당 owner
- 검증 채널이 없음 → `unproven`으로 닫고 재개 조건 기록

같은 criterion이 새 증거나 다른 가설 없이 반복 실패하면 Work를 다시 호출하지 않고 Direct 또는
상위 owner로 돌아간다. `state.md`는 전체 로그가 아니라 현재 실패 원인, 직전 판별, 다음 차별화된
행동만 보존한다.

## 10. 작업 깊이와 팀 운용

사소하고 되돌릴 수 있으며 같은 세션에서 끝나는 수정은 durable spec을 만들지 않는 quick lane을
사용한다. 다음 중 하나가 있으면 work folder를 만든다.

- 세션 중단 또는 handoff 가능성
- 병렬 작업
- 여러 acceptance 또는 파일/owner 경계
- 높은 위험 또는 비싼 검증
- 구현 전에 사용자 승인해야 하는 scope

Direct는 host-neutral한 작업 단위, 선행 조건, write scope, acceptance까지만 소유한다. Codex
subagent, Orca terminal, Claude, 단일 agent 실행은 외부 orchestration 계층의 책임이다.

- 기본은 단일 agent다.
- 공용 spec의 작업 단위와 파일/정본 owner가 독립일 때만 병렬화한다.
- 각 worker는 자신의 `team/<member-id>/`만 갱신한다.
- 병렬 subtask는 같은 state 파일을 공유하지 않고 별도 work ID를 갖는다.
- Git이 이력·branch·동시성 증거를 소유하며 Devflow가 별도 lock/task database를 만들지 않는다.
- 자동 commit은 Work의 보편 동작이 아니라 프로젝트 정책 또는 사용자 요청에 따른다.

## 11. Skill Rails 저작 구조

- 하나의 작은 canonical source package가 목적·공통 불변식·각 target entry와 선택 모듈을 소유한다.
- 각 스킬은 standalone target으로 빌드하고 생성된 `SKILL.md`를 직접 수정하지 않는다.
- entry는 배경/목적, trigger와 gate, current input, completion evidence, 다음 선택지, optional module의 정확한 open condition만 갖는다.
- 공통 규칙은 한 canonical module이 소유하고 실제 소비 target만 포함한다.
- 초기 target은 의미 판단이 중심이므로 prose 형태를 우선한다.
- renderer/core는 header/index처럼 결과가 결정적인 작업에만, 실제 필요가 관찰된 뒤 사용한다.
- 한 target을 먼저 build하고 receipt/diff/double-build/currentness/standalone fresh-use를 확인한 뒤 다음 target으로 간다.

