---
title: Devflow vNext planning map
status: final-reviewed-current-plan
purpose: Route readers through the current whole-system plan and its preserved design iterations.
read_when: Start here when reviewing, implementing, or challenging Devflow vNext.
canonical_for: Current planning state only; runtime behavior does not exist yet.
tags: [devflow-vnext, planning, index]
---

# Devflow vNext 기획 지도

이 기획의 목표는 스킬을 많이 만드는 것이 아니라, 사람이 요청하고 AI가 판단·구현하는 흐름에서
필요한 지식만 읽히고 검증된 지식이 장기간 자연스럽게 축적되는 최소 체계를 만드는 것이다.
레거시는 실패 증거이며 호환 대상이 아니다. 중개노트는 성공 원리를 관찰하는 읽기 전용 사례이며
복제 대상이 아니다.

## 현재 수렴안

- 프로젝트 정본과 Devflow가 만드는 모든 문서는 `.devflow/` 하나에 둔다.
- 루트의 AGENTS/CLAUDE 파일과 host hook은 `.devflow/index.md`를 가리키는 연결부일 뿐 지식을 소유하지 않는다.
- 공개 스킬은 `sketch`, `product`, `architecture`, `design`, `adopt`, `direct`, `work`,
  `verify`, `resume`의 아홉 개다.
- 공개 `principles`와 `domain` 스킬은 만들지 않는다.
- Domain은 스킬 단계가 아니라 `.devflow/project/domains/<domain>/`이라는 지식 분할 축이다.
- `resume`은 상태·재개·문서 방향을 알려 주는 하나의 읽기 전용 진입문이다.
- Verify 뒤 candidate는 Work closure가 열린 blocker와 확인된 `fact → path` landing으로 분류하고 Work actor만 비우며, 반복 누락이 관찰되기
  전에는 별도 closure skill을 추가하지 않는다.
- Skill Rails는 하나의 canonical source package와 얇은 prose target을 만드는 저작·배포 계층으로만 쓴다.
  런타임 의사결정 엔진이나 프로젝트 상태 기계로 사용하지 않는다.
- 활성 artifact의 state snapshot은 한 시점에 한 actor만 쓰고, 병렬 작업은 별도 지역 고유 ID와 안정적인
  seam을 우선해 나눈 뒤 Git/PR로 통합한다. 코드·정본 경계의 중첩 자체는 금지하지 않는다.
- 어느 단계든 관리권이 바뀌기 전에 끝내지 못하면 진행 로그가 아닌 현재 state 스냅숏을 남긴다.
- 각 문서는 한 질문에 답하며, 자기완결 배경·의도·현재 결론을 가진다. 세부 계약은 문서 종류별로
  분리하되 빈 형식을 채우게 만들지 않는다.
- 큰 문서는 길이로 자르지 않는다. 올바른 owner·수명, 본문 전 선택 가능성, 독립 질문·변경 이유,
  총 읽기·판단·편집 비용의 이익을 모두 확인하고, 늘 함께 읽히는 자식은 다시 합친다.
- 구현은 작은 문서 fixture와 fresh-agent 관찰에서 시작하며, 한 phase의 가정이 통과하기 전 다음
  복잡성을 추가하지 않는다.

## 문서별 읽기 경로

| 알고 싶은 것 | 읽을 문서 |
|---|---|
| 왜 다시 설계하며 무엇을 성공으로 보는가 | [01-intent-and-evidence.md](01-intent-and-evidence.md) |
| 스킬 관계, gate, 문서 트리, 지식 승격 | [02-skill-and-document-architecture.md](02-skill-and-document-architecture.md) |
| 사람·AI·팀이 실제로 어떻게 사용하는가 | [03-usage-scenarios.md](03-usage-scenarios.md) |
| 무엇부터 구현하고 어떤 관찰로 다음 단계에 가는가 | [04-delivery-and-validation.md](04-delivery-and-validation.md) |
| 레거시·중개노트·공식 호스트 조사 근거 | [05-research-evidence.md](05-research-evidence.md) |
| 합의·잠정·거부 결정과 재검토 조건 | [06-decision-ledger.md](06-decision-ledger.md) |
| Sketch·spec·state·Verify·Resume가 만드는 파일과 decision route를 시각적으로 보기 | [07-artifact-lifecycle-and-owner-model.md](07-artifact-lifecycle-and-owner-model.md) |
| 각 문서가 답할 질문, 본문 형식, 병렬·중단 계약과 Skill Rails 작성 구조 | [08-document-contracts.md](08-document-contracts.md) |
| 중개노트·레거시·신규 도출의 경계와 K 없는 조건부 분해의 근거 | [09-reference-boundaries-and-document-decomposition.md](09-reference-boundaries-and-document-decomposition.md) |

## 이 계획이 하지 않는 것

- 아직 레거시 파일을 이동하지 않는다.
- 아직 스킬, 훅, 설치 패키지, renderer를 구현하지 않는다.
- 아직 문서 schema를 범용 프레임워크로 만들지 않는다.
- 빌드 성공을 AI 사용성의 증거로 간주하지 않는다.
- 미래 가능성만으로 규칙·필드·스크립트를 추가하지 않는다.

## 설계 반복 기록

각 닫힌 시점은 [iterations/](../)에 전체 문서와 변경 이유를 함께 보존한다.

1. `01-initial-synthesis` — 조사 결과를 합친 최초안. 동결됨.
2. `02-reconciled` — 독립 페이블안과 상호 반론을 거친 수렴안. 동결됨.
3. `03-inversion-review` — 02 전체를 더 적은 스킬·문서·상태로 대체할 수 있는지 역발상으로 검증한 최종안. 동결됨.
4. `04-internal-canon-and-lifecycle` — 외부 `docs/` 정본 모순을 교정하고 `.devflow/` 완전 흡수, owner 의미, 산출물 수명을 구체화한 동결 기준선.
5. `05-practical-durability-and-document-contracts` — 병렬 Git 작업, 전 단계 checkpoint, 문서별 본문 계약,
   Skill Rails source graph를 보완하고 최종 독립 역검증을 반영한 동결 최종안.
6. `06-benchmark-boundaries-and-decomposition` — 중개노트 benchmark·레거시 교훈·신규 경계를 분리하고,
   owner·수명과 조건부 읽기에 기반한 K 없는 split/fold 계약을 독립 역검증한 동결 최종안.

이 폴더의 `README`와 `01`~`09`는 06이 닫힌 시점의 동결본이다. 이후 root 현재안이 바뀌어도 이
iteration은 당시 판단을 보존한다.

각 반복은 이전 문서를 덮어쓰지 않는다. `proven`, `failed`, `unproven`을 구분하고, 잠정 결정에는
반드시 그것을 뒤집을 가장 값싼 관찰을 적는다.
