---
title: Devflow vNext design iterations
status: active-history
purpose: Preserve each closed design baseline before the next independent challenge changes it.
read_when: Read when comparing alternatives or tracing why the final plan changed.
canonical_for: Planning evolution only; not runtime behavior.
tags: [devflow-vnext, planning, iterations, decisions]
---

# 설계 반복 기록

각 폴더는 닫힌 시점의 전체 계획을 그대로 보존한다. 다음 반복은 이전 파일을 제자리에서 고치지
않고 root 작업본에서 진행한 뒤 새 폴더로 동결한다.

1. `01-initial-synthesis`: coordinator가 원문 근거와 여러 독립 조사 결과를 통합한 최초안. 동결됨.
2. `02-reconciled`: Fable이 최초안을 보지 않고 만든 독자 설계와 01을 대립시키고 상호 반론으로 수렴한 안. 동결됨.
3. `03-inversion-review`: 02 전체를 대상으로 “더 적은 스킬·문서·상태로 같은 효과를 낼 수 있는가”를 다시 검증하고 별도 아키텍처 검토와 조정한 최종안. 동결됨.
4. `04-internal-canon-and-lifecycle`: 외부 `docs/` 정본 모순을 교정하고 `.devflow/` 완전 흡수, owner 의미, skill 산출물 수명을 구체화한 재검토 전 기준선. 동결됨.
5. `05-practical-durability-and-document-contracts`: 병렬 branch/worktree, 전 단계 중단 복구, 문서별 본문
   계약, Skill Rails source graph를 반영하고 같은 Fable 세션과 Architecture agent의 최종 역검증을
   수렴한 최종 계획. 동결됨.
6. `06-benchmark-boundaries-and-decomposition`: 중개노트 benchmark·레거시 retained lesson·vNext의
   유지·강화 경계를 구분하고, owner·수명·조건부 읽기·fold를 기준으로 K 없는 문서 분해를 수렴한
   최종 계획. 동결됨.

각 반복에는 전체 문서와 함께 이전 반복에서 바뀐 결정, 남은 이견, 새 검증 항목을 설명하는
`CHANGE-NOTE.md`를 둔다. `proven`, `failed`, `unproven`은 계속 분리한다.
