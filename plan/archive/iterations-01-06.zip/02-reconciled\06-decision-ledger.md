---
title: Reconciled decision ledger
status: reconciled-working-copy
purpose: Preserve decided, provisional, rejected, and corrected claims after independent design and debate.
read_when: Read when challenging the current architecture or deciding whether new evidence justifies a change.
canonical_for: Planning decisions and their falsifiers, not runtime state.
tags: [devflow-vnext, decisions, evidence, reconciliation]
---

# 수렴 결정 원장

## 1. 수렴 방법

Coordinator의 최초안을 보지 않은 페이블 세션이 레거시, 중개노트, 공식 호스트 문서를 바탕으로
독립 구조를 먼저 만들었다. 그 뒤 `01-initial-synthesis`를 공개해 두 안의 전제와 사용 결과를 비교했고,
Coordinator가 수용·반대 근거를 다시 전달하여 같은 세션에서 재반론과 수렴을 수행했다.

이 과정은 한 안의 문구를 검수한 것이 아니다. 특히 정본 위치, Skill Rails 경계, 팀원별 공간,
fixture 순서에서 실제 대립이 있었고 각 주장에 사람이 쓰는 결과, AI가 읽는 결과, 장기 지식 결과,
가장 값싼 반증 관찰을 요구했다. 페이블 컨텍스트는 약 22%에서 수렴되어 초기 이해 비용을 버리지
않고 같은 세션을 재사용했다.

## 2. 확정한 결정

1. 정본은 `docs/`, 진행 중 상태는 `.devflow/`가 소유한다.
2. marker는 `.devflow/devflow.md`이며 lifecycle, knowledge root, 언어, 검증 채널만 가진다.
3. 공개 skill은 열 개다: sketch, product, architecture, design, adopt, direct, work, verify, land,
   resume.
4. 공개 principles와 domain skill은 없다.
5. Resume은 status·continue·domain orientation을 다루는 읽기 전용 단일 entry다.
6. Sketch는 project/change scope를 함께 다루되 특정 사고법을 강제하지 않는다.
7. work `state.md`가 유일한 공유 상태다.
8. `team/<member>/<work-id>.md`는 개인 맥락만 가지며 공유 사실은 state로 이동한다.
9. Verify는 code를 고치지 않고 failure owner와 달라져야 할 조건을 반환한다.
10. 같은 criterion 재시도에는 달라진 가설·입력·구현·검증법이 필요하다.
11. 정본 header는 `summary`, `read_when`이 필수이고 `status`만 의미가 있을 때 선택적이다.
12. v1에는 id, kind, tags, owner, updated, verified-at을 넣지 않는다.
13. `docs/README.md`가 유일한 수동 routing index다.
14. SessionStart hook은 marker가 있을 때 Resume 포인터만 주며 correctness 조건이 아니다.
15. Adopt와 Product는 명시 호출 전용이고 unmanaged 상태의 write 진입은 Sketch/Product/Adopt뿐이다.
16. Skill Rails는 저작·배포 경계이며 project runtime 의사결정 엔진이 아니다.
17. 하나의 source package와 prose target을 쓰고 v1에는 record-only/prepare-record target을 만들지 않는다.
18. npm artifact 하나에 portable OpenAI manifest와 Claude adapter를 둔다.
19. `.codex-plugin` fallback은 실제로 요구하는 host version이 확인되기 전에는 배포하지 않는다.
20. 레거시 이동은 승인 후 housekeeping이며 구현 검증을 막는 Phase gate가 아니다.

## 3. 관찰 전까지 잠정인 결정

| 잠정 결정 | 유지/변경을 정할 관찰 |
|---|---|
| `land`를 별도 skill로 유지 | 첫 다섯 completed change 중 durable fact 누락이 하나라도 있으면 유지; owner/Verify 경로에서 항상 정확히 닫히면 통합 재검토 |
| Skill Rails authoring 비용 | 첫 세 target에서 build loop가 순수 authoring 시간의 1/3을 넘는지 |
| emitted runtime 파일의 AI noise | fresh AI가 prose target 폴더의 `scripts/run.mjs`를 불필요하게 읽거나 실행하는지 |
| keyed two-domain fixture | answer key가 routing defect를 구분하고 현실적 ambiguity도 노출하는지 |
| `planning`과 `adopting` 분리 | skill routing이 두 lifecycle에서 실제로 달라지는지 |
| project Sketch의 독립 폴더 | 중단된 project sketch가 transcript 없이 정확히 재개되는지 |
| member fact/context partition | member file에만 남은 사실을 다음 agent가 실행하지 않고 불일치로 표시하는지 |
| index generator | missing doc, dangling link, 반복 misroute 중 하나가 실제로 발생하는지 |

잠정은 구현 유보가 아니다. 가장 단순한 현재안을 실행하되 관찰이 나오면 해당 owner가 다시 결정한다.

## 4. 거부한 구조

- 레거시를 baseline·fallback·호환 계층으로 사용하는 것
- per-skill vendored runtime과 runtime Decision engine
- 모든 target이 무조건 읽는 shared principles module
- capability 번호, 전역 glossary, knowledge capsule, coordinate grammar
- journal 문법, freshness hash, claim, room, join/leave state
- 전역 currentStage, queue, retry count, agent session database
- 모든 요청의 sketch/spec/ADR/handoff 생성
- 검증되지 않은 claim을 문서 완성을 위해 사실처럼 쓰기
- team member index에 공유 작업 상태를 복제하기
- fixed retry count만으로 loop를 끊기
- Sketch에 Socratic/Dewey 같은 사고 절차를 강제하기
- future tooling을 이유로 header 필드를 미리 늘리기
- 첫날부터 index generator·schema framework를 만드는 것
- build receipt로 AI 행동과 사용자 효과를 증명했다고 간주하기
- hook이 없으면 동작하지 않는 설치 구조

## 5. 교정된 주장

- 독립안은 처음에 새 Skill Rails를 레거시 runtime과 동일시했으나 실제 설치된 새 계약과 prose target
  출력을 확인한 뒤 철회했다. 새 Skill Rails CLI는 authoring skill 안에 있고 target은 제한된 일곱 파일을
  생성한다. 다만 저작 비용과 AI noise는 아직 `unproven`이다.
- 독립안은 팀원 공간을 gitignored scratch로만 제안했으나 사용자의 명시 요구를 반영해 committed
  member context를 수용했다. 대신 공유 사실을 금지하고 Land에서 삭제한다.
- 독립안의 Codex manifest·npm 조사 일부는 공식 문서 재확인으로 교정되었다. portable root
  `plugin.json`과 npm marketplace source를 기준으로 하고 `.codex-plugin`은 조건부 fallback으로 둔다.

## 6. 다음 반복에서 반드시 뒤집어 볼 질문

`02-reconciled`를 최종안으로 간주하기 전에 다음 역발상에 답해야 한다.

1. 열 개 skill보다 적은 수로 동일한 owner 분리를 잃지 않고 작동할 수 있는가?
2. `land`가 누락을 막는가, 아니면 닫기 ceremony를 하나 더 만드는가?
3. `docs/README.md`와 header만으로 충분한가, 혹은 header조차 더 줄일 수 있는가?
4. lifecycle이 실제 routing을 바꾸지 않는다면 marker 한 줄로 줄일 수 있는가?
5. team folder가 명시 요구를 만족하면서도 legacy room의 작은 복제품이 되지 않는가?
6. Skill Rails의 provenance 가치가 저작·인지 비용보다 실제로 큰가?
7. 가장 강한 AI가 규칙 때문에 수동적으로 변하는 지점이 남아 있는가?
8. 비설치 팀원, 약한 모델, 긴 중단, 수동 문서 수정에서도 문서 정본이 살아남는가?

이 질문의 결과는 현재 문서를 덮어쓰지 않고 `03-inversion-review`에 별도 보존한다.
